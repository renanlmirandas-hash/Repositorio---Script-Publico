# -*- coding: utf-8 -*-
import base64
import logging
import sqlite3
import os
import platform
import shutil
import time
from datetime import datetime, timedelta
import xml.etree.ElementTree as ET
from sqlite_update import *
from fix_apply import *
from decode_base64 import *
from time_hora import *
from order_picture import *
from fix_protocolo_cupons import FixingCstatCupons
from corrigir_protocolo import corrigir_protocolo
from inutilizar_numeros_orfaos import inutilizar_nota_orfa, nota_ja_processada
# Conexão com o SDK do e-deploy (msgbus/cfgtools) é reaproveitada durante toda a execução do
# main.py em vez de ser reaberta a cada venda em contingência - ver _obter_fixing_cstat_cupons().
_fixing_cstat_cupons = None
_fixing_cstat_cupons_indisponivel = False


def _obter_fixing_cstat_cupons():
    """
    Retorna uma instância única de FixingCstatCupons, reaproveitada durante toda a execução do
    main.py, para evitar reabrir a conexão com o barramento (MBEasyContext) a cada venda em
    contingência.

    Se o ambiente não for NFCE (loader_NFCE.cfg ausente - FixingCstatCupons faz sys.exit(1)
    nesse caso) ou a conexão com o SDK do e-deploy falhar por qualquer outro motivo, marca como
    indisponível e não tenta de novo pelo resto desta execução.
    """
    global _fixing_cstat_cupons, _fixing_cstat_cupons_indisponivel

    if _fixing_cstat_cupons_indisponivel:
        return None
    if _fixing_cstat_cupons is not None:
        return _fixing_cstat_cupons

    cwd_original = os.getcwd()
    try:
        # Usa o mesmo caminho de instalação que o main.py já detecta pra tudo mais (acesso_fiscal,
        # path_orders, etc.), em vez do get_application_path() fixo que a classe tinha antes -
        # aquele só reconhecia "C:/edeployPOS"/"/home/administrador/edeployPOS" e ficava errado em
        # instalações mwpos ou edeploy-pos-structure.
        app_path = get_system_version()
        _fixing_cstat_cupons = FixingCstatCupons(app_path)
        # IMPORTANTE: NÃO restaurar cwd_original aqui em caso de sucesso - ver incidente de campo
        # de 31/08/2026 (6) no CLAUDE.md. FixingCstatCupons.application_conn() faz os.chdir(BINPATH)
        # de propósito, e o SDK (old_helper/persistence.py) carrega a DLL nativa (libaprutil-1)
        # de forma LAZY - só na primeira escrita de verdade (update_fiscal_persist), não na hora
        # de conectar. Se a gente restaurasse o cwd original logo aqui (como fazíamos antes, num
        # finally que rodava sempre), essa DLL passava a ser procurada relativo ao cwd errado (o
        # find_fiscal_id, em sqlite_update.py, também deixa o cwd mudado como efeito colateral, e
        # nunca restaura) e o carregamento da DLL falhava com "ImportError: Could not find library
        # 'libaprutil-1'" assim que uma nota em contingência tentava ser corrigida de verdade -
        # mesmo com a DLL existindo no lugar certo. Deixar o cwd em BINPATH depois daqui é seguro:
        # nenhuma outra função usada no restante do time_direction (update_xml_APED23848,
        # FiscalData, validate_status) depende de caminho relativo - todas recebem o caminho
        # absoluto do banco. Só find_fiscal_id/not_order_picture dependem de cwd, e as duas já
        # fazem o próprio os.chdir antes de usar glob.glob(), então funcionam de qualquer cwd.
        return _fixing_cstat_cupons
    except SystemExit:
        # FixingCstatCupons.__init__ faz sys.exit(1) quando o ambiente não é NFCE.
        logging.info("Ambiente não é NFCE - correção de protocolo (FixingCstatCupons) indisponível nesta execução")
        os.chdir(cwd_original)
    except Exception as ex:
        logging.info("Não foi possível conectar ao FixingCstatCupons para correção de protocolo: {}".format(ex))
        os.chdir(cwd_original)

    _fixing_cstat_cupons_indisponivel = True
    return None


def _tentar_corrigir_protocolo_cupom(order_id):
    """
    Tenta corrigir o protocolo da nota via FixingCstatCupons.find_key_pattern quando a venda
    está em contingência (status "Problemas de conexao com a SEFAZ" ou "Notas anteriores em
    contingencia"). find_key_pattern procura nos logs do FiscalWrapper um cStat já resolvido
    para esse orderid e, se encontrar, corrige o protocolo sozinho (fix_cstat).

    Retorna True se a correção foi aplicada, False se não havia nada para corrigir ou se a
    correção não está disponível neste ambiente/execução.
    """
    fixer = _obter_fixing_cstat_cupons()
    if fixer is None:
        return False

    try:
        return bool(fixer.find_key_pattern(order_id))
    except Exception as ex:
        logging.info("Erro ao tentar corrigir protocolo (FixingCstatCupons) para orderid {}: {}".format(order_id, ex))
        return False


def _tentar_inutilizar_nota_orfa(numero_nota):
    """
    Pergunta ao operador (raw_input) se quer inutilizar junto à SEFAZ um número de nota que não
    foi encontrado em nenhum order.db<N> corrente NEM recuperado do backup (restaurar_nota) -
    numero "órfão", o mesmo cenário que inutilizar_numeros_orfaos.py já foi feito para tratar
    manualmente (números "queimados" sem venda nenhuma por trás).

    Diferente de restaurar_nota (que só mexe no banco local e roda sem perguntar),
    inutilização é uma ação IRREVERSÍVEL junto à SEFAZ - por isso (decisão do usuário,
    09/09/2026) sempre pede confirmação manual antes de prosseguir. Isso faz o main.py bloquear
    esperando resposta se aparecer uma nota órfã - aceitável porque isso deveria ser raro (só
    acontece quando nem o banco corrente nem nenhum backup têm a nota).

    A série é sempre lida dinamicamente do loader_NFCE.cfg da loja por inutilizar_nota_orfa()
    (nunca fixa) - ver CLAUDE.md.

    Qualquer exceção (recusa ao pedir confirmação, falha ao importar o SDK do fiscalwrapper,
    config ausente, etc.) é capturada e logada - não derruba o processamento das outras notas
    do CSV.

    IMPORTANTE - execução sem terminal interativo (ex: agendada/silenciosa via update.bat sem
    console anexado): raw_input() levanta EOFError se não houver stdin pra ler. Esse caso cai no
    except acima (loga e retorna sem inutilizar nada) - ou seja, rodando assim, a inutilização
    automática vira efetivamente um no-op (a nota só fica "não identificada" no log, igual ao
    comportamento de antes desta mudança). Só funciona de fato quando alguém está de fato na
    frente do terminal pra responder ao prompt.

    IDEMPOTÊNCIA (09/09/2026): antes de perguntar qualquer coisa, checa
    nota_ja_processada(numero_nota) - se essa nota já tem um desfecho terminal gravado (uma
    execução anterior do main.py já inutilizou com sucesso, ou a SEFAZ já confirmou que o número
    estava tratado/usado, ou já foi um erro permanente), nem pergunta de novo nem tenta de novo -
    só loga e sai. Isso evita ficar perguntando pro operador (e batendo na SEFAZ) pela mesma nota
    órfã toda vez que o main.py roda, já que ela nunca vai deixar de aparecer como "não
    identificada" (não existe venda nenhuma por trás dela pra ela parar de cair aqui). Ver
    nota_ja_processada/inutilizar_nota_orfa em inutilizar_numeros_orfaos.py para onde esse estado
    é gravado (arquivo JSON, não em fiscal_persistcomp.db/order.db - não há order nenhuma pra
    essas tabelas associarem a um número órfão).

    MODO DRY-RUN, "só print" (adicionado em 10/09/2026): setando a variável de ambiente
    INUTILIZACAO_DRY_RUN=1 (ou "true"/"sim"/"s") antes de rodar main.py, esta função NUNCA
    pergunta nada ao operador nem manda nada de verdade pra SEFAZ - só monta a requisição que
    SERIA enviada (via inutilizar_nota_orfa(..., confirm=False), a mesma peça já usada pelo
    --dry-run do CLI em lote) e loga o XML completo que seria mandado, junto com a série lida de
    verdade do loader_NFCE.cfg da loja. Pensado pra rodar main.py numa loja de
    homologação/produção e ver exatamente o que o fluxo automático faria com as notas órfãs
    reais dessa loja - sem risco nenhum - antes de decidir confiar nele em modo totalmente
    automático (com a confirmação manual via raw_input, o padrão sem essa variável). Nada é
    gravado no arquivo de estado nesse modo (dry-run nunca é um desfecho terminal) - a mesma nota
    aparece de novo em toda execução enquanto INUTILIZACAO_DRY_RUN estiver ativo, o que é
    esperado (é só um preview, repetível).
    """
    if nota_ja_processada(numero_nota):
        logging.info(
            "Nota {} já foi processada (inutilizada/tratada) numa execução anterior - não "
            "perguntando nem tentando de novo".format(numero_nota))
        return

    dry_run = os.environ.get("INUTILIZACAO_DRY_RUN", "").strip().lower() in ("1", "true", "sim", "s", "yes")

    if dry_run:
        logging.info(
            "[DRY-RUN] INUTILIZACAO_DRY_RUN ativo - simulando a inutilização da nota {} sem "
            "perguntar nada e sem mandar nada de verdade pra SEFAZ".format(numero_nota))
    else:
        try:
            resposta = raw_input(  # noqa: F821 (Python 2)
                "Nota {} não encontrada em nenhum backup. Deseja inutilizar esse número junto à "
                "SEFAZ? [s/N] ".format(numero_nota))
        except Exception as ex:
            logging.info("Não foi possível pedir confirmação para inutilizar a nota {}: {}".format(numero_nota, ex))
            return

        if resposta.strip().lower() not in ("s", "sim", "y", "yes"):
            logging.info("Inutilização da nota {} não confirmada pelo operador - segue não identificada".format(numero_nota))
            return

    try:
        # NÃO usar um "caminho_databases" vindo de main.py aqui - essa variável é global só no
        # módulo main.py (onde foi atribuída), não em consulte_csv.py (onde esta função está
        # definida) - Python resolve globais pelo módulo de definição da função, não pelo de
        # quem chama. Mesmo padrão já usado em _obter_fixing_cstat_cupons(): recalcula via
        # get_system_version() (barato - só confere alguns os.path.exists).
        app_path = get_system_version()
        sucesso, mensagem = inutilizar_nota_orfa(numero_nota, app_path=app_path, confirm=not dry_run)
        logging.info("Inutilização da nota {} - sucesso: {}, mensagem: {}".format(numero_nota, sucesso, mensagem))
    except Exception as ex:
        logging.info("Erro ao tentar inutilizar a nota órfã {}: {}".format(numero_nota, ex))


def ler_arquivo_csv(caminho_arquivo):
    dados = []
    with open(caminho_arquivo, 'r') as arquivo_csv:
        leitor_csv = arquivo_csv.readlines()
        for linha in leitor_csv:
            dados.append(linha)
    return dados

def get_system_version():
    if is_that_system_windows() and os.path.exists(r"C:\mwpos"):
        return r"C:\mwpos"
    elif is_that_system_windows() and os.path.exists(r"C:\edeployPOS"):
        return r"C:\edeployPOS"
    elif is_that_system_windows() and os.path.exists(r"C:\edeploy-pos-structure"):
        return r"C:\edeploy-pos-structure"
    elif not is_that_system_windows() and os.path.exists("/home/administrador/edeployPOS"):
        return "/home/administrador/edeployPOS"
    else:
        return r"/home/administrador/mwpos_server"

def is_that_system_windows():
    return platform.system().lower() == "windows"


def mover_arquvi_xml(diretorio, local):
    arquivo_diretorio_fiscalrepository = (
        "{}/fiscalrepository.py".format(diretorio))
    arquivo_local_fiscalrepository = ("{}/fiscalrepository.py".format(local))
    shutil.copy(arquivo_diretorio_fiscalrepository,
                arquivo_local_fiscalrepository)

def open_store_cfg(caminho_bkoffice):
    codido_centro = "{}".format(caminho_bkoffice)
    tree = ET.parse(codido_centro)
    root = tree.getroot()
    persistcomp_normal = root.find(".//key[@name='Id']/string").text
    return str(persistcomp_normal)

def file_valor_sentto(file_csv):
    valida_dic = []
    for file in file_csv:
        file_csv_le = file.replace("\n", "").split(";")
        file_valida = {
            "numeronota": file_csv_le[0]
        }
        valida_dic.append(file_valida)
    return valida_dic




def time_direction(venda, order_id, file_connect, nota, posid, fiscal_banco):
    void_time = None
    paid_time = None
    state_id_paid = None
    state_id_void = None
    no_ident_status = None
    type_posid = None
    state_recalled = None
    if posid == 0:
        type_posid = "Delivery"
    for order in venda:
        time_order = order.get("Timestamp")
        status_order = int(order.get("status_order"))
        date = datetime.strptime(time_order, "%Y-%m-%dT%H:%M:%S.%f")
        no_ident_status = status_order
        if status_order == 4:
            void_time = date
            state_id_void = status_order
        elif status_order == 5:
            paid_time = date
            state_id_paid = status_order
            date_protoco = date
            date_inicial = date_protoco.strftime("%Y%m%d")
            date_outro_dia = date_protoco + timedelta(days=1)
            date_outro_dia = date_outro_dia.strftime("%Y%m%d")
        elif status_order == 6:
            state_recalled = status_order
    if state_recalled:
        return 6

    if void_time and paid_time and state_id_void == 4 and state_id_paid == 5:
        #diferenca = paid_time - void_time
        minutos = abs((paid_time - void_time).total_seconds() / 60)
        if minutos >= 30:
            logging.info(
                "Cancelada após 30: Order:{}, Nota:{}, Dia:{}, Tempo:{}, Pos:{}".format(order_id, nota, date,
                                                                                                  minutos, type_posid,                                                                                                  ))
            updater_aped_20805(file_connect, order_id, nota, "cancelada")
            return
        else:
            updater_aped_20805(file_connect, order_id, nota)
            return
    if state_id_paid is not None and state_id_void is None:
        time.sleep(7)
        sale_custom = orders_customproperties(file_connect, order_id)
        order_disabled = False
        xml_fiscal_disabled = None
        for sale in sale_custom:
            # if sale.get("key") == "ORDER_DISABLED":
            #     order_disabled = True
            # if sale.get("key") == "DISABLED_FISCAL_XML":
            #     xml_fiscal_disabled = sale.get("value")
            if sale.get("key") == "FISCAL_XML":
                base = sale.get("value")
                decoder = DecodeBase64(base)
                status = decoder.decode()
                if status in ("100", "150"):
                    logging.info("Validar cstat no fiscal_persistcomp".format(order_id, status))
                    xml_request = validate_status(fiscal_banco, order_id)
                    decoder_xml = DecodeBase64(xml_request[0])
                    status_xml = decoder_xml.decode()
                    if status != status_xml:
                        logging.info(
                            "Order:{}, Nota:{}, Cstat: {} | Fiscal Status_xml:{} Atualizando informações no fiscal".format(
                                order_id, nota, status, status_xml))
                        update_xml_APED23848(fiscal_banco, base, order_id, 1, nota)
                        logging.info(
                            "Nota em contigencia , vamos alterar o status no banco {}, {}".format(order_id, nota)
                        )
                        return 5
                    else:
                        logging.info("Venda possui o mesmo status entre fiscal/order {}, {}".format(order_id, nota))
                        return 5
                if status in ("Problemas de conexao com a SEFAZ", "Notas anteriores em contingencia"):
                    protocolo_corrigido = _tentar_corrigir_protocolo_cupom(order_id)
                    if protocolo_corrigido:
                        logging.info(
                            "Protocolo corrigido via "
                            "FixingCstatCupons - orderid {}, nota {}"
                            "Acesse o menu gerente e clique na tecla corrigir protocolo e valide o log".format(order_id, nota))
                        sucesso, mensagem = corrigir_protocolo("{}", "{}".format(date_inicial, date_outro_dia))
                        logging.info("Sucesso: {}, Mensagem: {}".format(sucesso, mensagem))
                        return
                    sale_order_picture = 1 #rder_picture.encode()
                    date_time = order.get("Timestamp").replace("T", " ")
                    date_fiscal = datetime_to_float(date_time)
                    validate_sale = FiscalData(fiscal_banco, posid, order_id, base, nota, sale_order_picture, date_fiscal)
                    insert_fiscal = validate_sale.sales_inquiry()
                    if insert_fiscal:
                        update_xml_APED23848(fiscal_banco, base, order_id, 0, nota)
                        logging.info(
                            "Nota em contigencia , vamos alterar o status no banco {}, {}".format(order_id, nota))
                        return
                    else:
                        validate_sale.insert_fiscal_faltante()
                        return


        if order_disabled and xml_fiscal_disabled is not None:
            xml_encoded = base64.b64decode(xml_fiscal_disabled)
            ns = {"nfe": "http://www.portalfiscal.inf.br/nfe"}
            root = ET.fromstring(xml_encoded)
            cstat = root.find(".//nfe:cStat", ns)
            if cstat.text in ('206', '256', '102'):
                logging.info("Inutizada incorretamente {} APED-23983 nota:{}".format(order_id, nota))
                fiscal = seq_fiscal(fiscal_banco)
                seq = fiscal[0]["fiscal_id"]
                seq += 1
                seq_update(fiscal_banco, seq)
                update_fiscal_order(file_connect, order_id, seq)
                update_xml_APED23848(fiscal_banco, xml_fiscal_disabled, order_id, 555, seq)
                return
            else:
                logging.info("Não identificado inutilização {}, {}".format(order_id, nota))


    if state_id_void and state_id_paid is None:
        sale_custom = orders_customproperties(file_connect, order_id)
        cstat = None
        order_disabled = None
        for sale in sale_custom:
            if sale.get("key") == "DISABLED_FISCAL_XML":
                base = sale.get("value")
                decoder = DecodeBase64(base)
                status = decoder.decode()
                cstat = status
                break
            if sale.get("key") == "ORDER_DISABLED":
                order_disabled = sale.get("value")
        if cstat == "563":
            logging.info(
                "Order foi Void sem status de paid {}, {}, cstat {} : APED-20811 - Erro 563 ".format(order_id, nota,                                                                                                         cstat))
            return
        elif cstat == "102":
                logging.info("Order foi Void sem status de paid {}, {}, cstat {}".format(order_id, nota, cstat))
                return
        elif order_disabled is not  None:
            logging.info("Order foi Void sem status de paid {}, {}, ORDER_DISABLED {} possivel quebra de sequencia".format(order_id, nota, order_disabled))
            return
        else:
            logging.info(
                "Não existe tratamendo ainda, status atual da venda {}, order {} ".format(no_ident_status,
                                                                                             order_id,sale.get("key")))
            return

    elif state_id_paid is None and state_id_void is None:
        updated_state = consulte_orderid(file_connect, order_id)
        for updated in updated_state:
            no_ident_status = updated.get("status_order")
            type_venda = updated.get("ordersubtype")
            if no_ident_status == 2:
                logging.info("Venda com o status {}, {}, {} ".format(no_ident_status, order_id, type_venda))
            elif no_ident_status == 6:
                break
    else:
        if state_id_paid is None and state_id_void is None:
            logging.info("Não existe tratamendo ainda, status atual da venda {}, order {}".format(no_ident_status, order_id))
