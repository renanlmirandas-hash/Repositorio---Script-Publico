#!/usr/bin/env python3
"""Busca numero(s) de nota fiscal (FISCAL_ID) nas bases correntes e restaura do backup quando necessario.

O numero de nota nao e o OrderId (chave interna da tabela Orders) - ele fica guardado em
OrderCustomProperties, na linha onde Key='FISCAL_ID'. O script resolve o FISCAL_ID para o
OrderId correspondente e so entao localiza/copia o pedido completo (Orders + tabelas filhas).

Ordem de busca/restauracao para o PEDIDO (order.db<N>):
    1. Bases correntes (order.db<N>).
    2. Backup mensal de pedidos (orders_*.db) - copia o pedido completo (Orders + tabelas filhas).
    3. FiscalData (fiscal_persistcomp.db ou fiscal_*.db), pela coluna NumeroNota - quando nem a
       base corrente nem o backup de pedidos tem o pedido, mas o registro fiscal ainda existe, o
       pedido e RECONSTRUIDO em order.db<N> a partir do OrderPicture (XML em base64) gravado ali.
       Essa reconstrucao e best-effort: e derivada de um snapshot ja renderizado, entao
       OrderVoidHistory e taxas de delivery fee (OrderFee/OrderItemFeeValue) nao sao recuperadas
       por essa via.

Depois de garantir o pedido em order.db<N>, o script tambem valida se o registro fiscal
(tabela FiscalData, em fiscal_persistcomp.db - XML assinado, resposta da SEFAZ e o
order_picture da venda em base64) esta presente. Se nao estiver, procura em fiscal_*.db no
diretorio de backup e restaura de la. Dados fiscais sao legalmente imutaveis, entao o script
NUNCA fabrica um registro fiscal do zero - se nao existir em nenhum backup, apenas avisa.

Uso:
    python restore_order_from_backup.py 11879 20344
    python restore_order_from_backup.py 11879 --dry-run
    python restore_order_from_backup.py 11879 --pos 2 --yes
    python restore_order_from_backup.py 11879 --backup-file orders_202507.db

Sem --backup-file / --fiscal-backup-file, todos os orders_*.db / fiscal_*.db do diretorio de
backup sao varridos automaticamente (do mes mais recente para o mais antigo) ate achar a nota.
"""
import argparse
import base64
import glob
import json
import os
import re
import shutil
import sqlite3
import sys
from datetime import datetime
from xml.etree import ElementTree as ET

ORDER_DB_PATTERN = re.compile(r"^order\.db(\d+)$")

CHILD_TABLES = [
    "OrderCustomProperties",
    "OrderItemCustomProperties",
    "OrderStateHistory",
    "OrderItem",
    "OrderTax",
    "OrderDiscount",
    "OrderVoidHistory",
    "OrderTender",
    "OrderComment",
    "OrderProduct",
    "OrderPrice",
]

DEFAULT_DB_DIR = r"C:\edeployPOS\data\server\databases"
DEFAULT_BACKUP_DIR = r"C:\edeployPOS\data\server\backups_maintenance\databases"
FISCAL_DB_NAME = "fiscal_persistcomp.db"


def _int(value, default=None):
    if value in (None, ""):
        return default
    return int(round(float(value)))


def find_pos_order_databases(database_dir):
    databases = {}
    for name in os.listdir(database_dir):
        match = ORDER_DB_PATTERN.match(name)
        if match:
            databases[int(match.group(1))] = os.path.join(database_dir, name)
    return databases


def find_order_ids_by_fiscal_id(db_path, fiscal_id):
    conn = sqlite3.connect(db_path)
    try:
        cursor = conn.execute(
            "SELECT OrderId FROM OrderCustomProperties WHERE Key = 'FISCAL_ID' AND Value = ?",
            (fiscal_id,),
        )
        return [row[0] for row in cursor.fetchall()]
    finally:
        conn.close()


def fetch_originator_id(db_path, order_id):
    conn = sqlite3.connect(db_path)
    try:
        cursor = conn.execute("SELECT OriginatorId FROM Orders WHERE OrderId = ?", (order_id,))
        row = cursor.fetchone()
        return row[0] if row else None
    finally:
        conn.close()


def resolve_target_pos_id(originator_id, pos_databases):
    if not originator_id:
        return None
    match = re.search(r"(\d+)$", originator_id)
    if not match:
        return None
    pos_id = int(match.group(1))
    return pos_id if pos_id in pos_databases else None


def find_in_live_databases(pos_databases, fiscal_id):
    matches = []
    for pos_id, path in pos_databases.items():
        for order_id in find_order_ids_by_fiscal_id(path, fiscal_id):
            matches.append((pos_id, order_id))
    return matches


def find_in_backup_databases(backup_dir, preferred_backup_file, fiscal_id):
    candidates = []
    if preferred_backup_file:
        preferred_path = os.path.join(backup_dir, preferred_backup_file)
        if os.path.isfile(preferred_path):
            candidates.append(preferred_path)

    # orders_YYYYMM.db sorts chronologically as a string, so this checks the most recent month first.
    for path in sorted(glob.glob(os.path.join(backup_dir, "orders_*.db")), reverse=True):
        if path not in candidates:
            candidates.append(path)

    for path in candidates:
        order_ids = find_order_ids_by_fiscal_id(path, fiscal_id)
        if order_ids:
            return path, order_ids
    return None, []


def backup_file_before_write(db_path):
    timestamp = datetime.now().strftime("%Y%m%dT%H%M")
    backup_path = "{}_{}.bkp".format(db_path, timestamp)
    shutil.copy2(db_path, backup_path)
    return backup_path


def import_order_from_backup(backup_db_path, target_db_path, order_id):
    conn = sqlite3.connect(target_db_path)
    conn.execute("ATTACH DATABASE ? AS bkp", (backup_db_path,))
    try:
        conn.execute(
            "INSERT OR REPLACE INTO Orders SELECT * FROM bkp.Orders WHERE OrderId = ?",
            (order_id,),
        )
        for table in CHILD_TABLES:
            conn.execute(
                "INSERT OR REPLACE INTO {0} SELECT * FROM bkp.{0} WHERE OrderId = ?".format(table),
                (order_id,),
            )
        conn.commit()
    finally:
        conn.execute("DETACH DATABASE bkp")
        conn.close()


def fiscal_data_exists(db_path, order_id):
    conn = sqlite3.connect(db_path)
    try:
        cursor = conn.execute("SELECT COUNT(*) FROM FiscalData WHERE OrderId = ?", (order_id,))
        return cursor.fetchone()[0] > 0
    finally:
        conn.close()


def fiscal_record_by_numero_nota(db_path, fiscal_id):
    conn = sqlite3.connect(db_path)
    try:
        cursor = conn.execute(
            "SELECT OrderId, PosId, OrderPicture FROM FiscalData WHERE NumeroNota = ?",
            (fiscal_id,),
        )
        return cursor.fetchone()
    finally:
        conn.close()


def find_order_picture_in_fiscal_databases(db_dir, backup_dir, preferred_fiscal_backup_file, fiscal_id):
    live_fiscal_db = os.path.join(db_dir, FISCAL_DB_NAME)
    if os.path.isfile(live_fiscal_db):
        row = fiscal_record_by_numero_nota(live_fiscal_db, fiscal_id)
        if row:
            return live_fiscal_db, row[0], row[1], row[2]

    candidates = []
    if preferred_fiscal_backup_file:
        preferred_path = os.path.join(backup_dir, preferred_fiscal_backup_file)
        if os.path.isfile(preferred_path):
            candidates.append(preferred_path)
    for path in sorted(glob.glob(os.path.join(backup_dir, "fiscal_*.db")), reverse=True):
        if path not in candidates:
            candidates.append(path)

    for path in candidates:
        row = fiscal_record_by_numero_nota(path, fiscal_id)
        if row:
            return path, row[0], row[1], row[2]

    return None, None, None, None


def decode_order_picture(raw_value):
    padded = raw_value + "=" * (-len(raw_value) % 4)
    return base64.b64decode(padded).decode("utf-8")


def find_fiscal_backup_with_order(backup_dir, preferred_backup_file, order_id):
    candidates = []
    if preferred_backup_file:
        preferred_path = os.path.join(backup_dir, preferred_backup_file)
        if os.path.isfile(preferred_path):
            candidates.append(preferred_path)

    for path in sorted(glob.glob(os.path.join(backup_dir, "fiscal_*.db")), reverse=True):
        if path not in candidates:
            candidates.append(path)

    for path in candidates:
        if fiscal_data_exists(path, order_id):
            return path
    return None


def import_fiscal_data_from_backup(backup_db_path, target_db_path, order_id):
    conn = sqlite3.connect(target_db_path)
    conn.execute("ATTACH DATABASE ? AS bkp", (backup_db_path,))
    try:
        conn.execute(
            "INSERT OR REPLACE INTO FiscalData SELECT * FROM bkp.FiscalData WHERE OrderId = ?",
            (order_id,),
        )
        conn.commit()
    finally:
        conn.execute("DETACH DATABASE bkp")
        conn.close()


def process_fiscal_data(order_id, args):
    fiscal_db_path = os.path.join(args.db_dir, FISCAL_DB_NAME)
    if not os.path.isfile(fiscal_db_path):
        print("Aviso: {} nao encontrado em {}, pulando checagem fiscal.".format(FISCAL_DB_NAME, args.db_dir))
        return

    if fiscal_data_exists(fiscal_db_path, order_id):
        print("Dados fiscais (FiscalData) ja presentes em {} para OrderId={}.".format(FISCAL_DB_NAME, order_id))
        return

    print("FiscalData ausente em {} para OrderId={}. Buscando no backup fiscal...".format(FISCAL_DB_NAME, order_id))
    fiscal_backup_path = find_fiscal_backup_with_order(args.backup_dir, args.fiscal_backup_file, order_id)
    if not fiscal_backup_path:
        print(
            "Aviso: OrderId={} nao tem registro fiscal (FiscalData - XML assinado, protocolo SEFAZ "
            "e order_picture) em nenhum backup fiscal. O pedido foi restaurado em order.db, mas a "
            "nota pode nao ter dados fiscais disponiveis para reimpressao/consulta.".format(order_id)
        )
        return

    print("FiscalData encontrado em {}.".format(os.path.basename(fiscal_backup_path)))

    if args.dry_run:
        print("[dry-run] Nenhuma alteracao aplicada em {}.".format(FISCAL_DB_NAME))
        return

    if not args.yes:
        answer = input("Confirma a importacao do registro fiscal para {}? [s/N] ".format(FISCAL_DB_NAME))
        if answer.strip().lower() not in ("s", "sim", "y", "yes"):
            print("Importacao do registro fiscal cancelada pelo usuario.")
            return

    backup_copy = backup_file_before_write(fiscal_db_path)
    print("Backup de seguranca criado: {}".format(backup_copy))

    import_fiscal_data_from_backup(fiscal_backup_path, fiscal_db_path, order_id)
    print("Registro fiscal (FiscalData) do OrderId={} importado com sucesso para {}.".format(
        order_id, FISCAL_DB_NAME
    ))


def parse_order_picture(xml_text):
    root = ET.fromstring(xml_text)
    order_elem = root if root.tag == "Order" else root.find(".//Order")
    if order_elem is None:
        raise ValueError("XML do order_picture nao contem um elemento <Order>")

    order_id = _int(order_elem.get("orderId"))

    custom_properties = [
        (prop.get("key"), prop.get("value"))
        for prop in order_elem.findall("./CustomOrderProperties/OrderProperty")
    ]
    is_fiscal = any(key in ("FISCAL_ID", "FISCAL_XML") for key, _ in custom_properties)

    orders_row = {
        "OrderId": order_id,
        "StateId": _int(order_elem.get("stateId")),
        "OrderType": _int(order_elem.get("typeId")),
        "OrderSubType": order_elem.get("subType"),
        "OriginatorId": order_elem.get("originatorId"),
        "SaleType": _int(order_elem.get("saleType"), default=0),
        "ExemptionCode": order_elem.get("exemptionCode"),
        "LineCounter": _int(order_elem.get("lineCounter"), default=0),
        "CreatedAt": order_elem.get("createdAtGMT"),
        "LastNewLineAt": order_elem.get("lastNewLineAtGMT"),
        "LastModifiedLine": _int(order_elem.get("lastModifiedLine"), default=0),
        "BusinessPeriod": _int(order_elem.get("businessPeriod")),
        "DistributionPoint": order_elem.get("podType"),
        "SessionId": order_elem.get("sessionId"),
        "PriceListId1": order_elem.get("priceList"),
        "AdditionalInfo": order_elem.findtext("AdditionalInfo"),
        "TotalNet": order_elem.get("totalAmount"),
        "TotalGross": order_elem.get("totalGross"),
        "DiscountAmount": order_elem.get("discountAmount"),
        "TotalTaxAmountAD": order_elem.get("taxTotal"),
        "Tip": order_elem.get("tip"),
        "Fiscal": "1" if is_fiscal else "0",
    }

    state_history = [
        {"StateId": _int(state.get("stateId")), "Timestamp": state.get("timestampGMT")}
        for state in order_elem.findall("./StateHistory/State")
    ]

    tenders = [
        {
            "OrderTenderId": _int(tender.get("tenderId")),
            "TenderId": _int(tender.get("tenderType")),
            "Timestamp": tender.get("timestampGMT"),
            "TenderAmount": tender.get("tenderAmount") or "0.00",
            "TenderDetail": tender.get("tenderDetail"),
            "TipAmount": tender.get("tip"),
            "ChangeAmount": tender.get("change"),
            "TenderDescr": tender.get("tenderDescr"),
            "ElectronicType": _int(tender.get("eletronicType")),
        }
        for tender in order_elem.findall("./TenderHistory/Tender")
    ]

    discounts = [
        {
            "LineNumber": _int(discount.get("lineNumber")),
            "ItemId": discount.get("itemId"),
            "Level": discount.get("level"),
            "PartCode": _int(discount.get("partCode")),
            "DiscountId": _int(discount.get("discountId")),
            "DiscountAmount": discount.get("discountAmount"),
        }
        for discount in order_elem.findall("./OrderDiscounts/Discount")
    ]

    sale_lines = [_parse_sale_line(line) for line in order_elem.findall("./SaleLine")]

    return {
        "order_id": order_id,
        "orders_row": orders_row,
        "custom_properties": custom_properties,
        "state_history": state_history,
        "tenders": tenders,
        "discounts": discounts,
        "sale_lines": sale_lines,
    }


def _parse_sale_line(line):
    item_id = line.get("itemId")
    part_code = _int(line.get("partCode"))

    custom_properties = {}
    raw_custom_properties = line.get("customProperties")
    if raw_custom_properties:
        try:
            custom_properties = json.loads(raw_custom_properties)
        except ValueError:
            custom_properties = {}

    product_code = None
    if item_id:
        last_segment = item_id.split(".")[-1]
        if last_segment.isdigit():
            product_code = int(last_segment)

    tax_items = [
        {
            "TaxName": tax.get("taxName"),
            "TaxFiscalIndex": tax.get("taxIndex"),
            "TaxRuleId": _int(tax.get("taxRuleId")),
            "TaxIncluded": _int(tax.get("taxIncluded"), default=1),
            "TaxRate": tax.get("taxRate"),
            "BaseAmountBD": tax.get("baseAmountBD"),
            "BaseAmountAD": tax.get("baseAmountAD"),
            "BaseReducedAmount": tax.get("baseReducedAmount"),
            "TaxAmountBD": tax.get("taxAmountBD"),
            "TaxAmountAD": tax.get("taxAmountAD"),
        }
        for tax in line.findall("./TaxItem")
    ]

    comments = [
        {"CommentId": _int(comment.get("commentId"), default=0), "Comment": comment.get("comment")}
        for comment in line.findall("./Comment")
    ]

    return {
        "line_number": _int(line.get("lineNumber")),
        "item_id": item_id,
        "level": line.get("level"),
        "part_code": part_code,
        "product_code": product_code,
        "product_name": line.get("productName"),
        "item_type": line.get("itemType"),
        "measure_unit": line.get("measureUnit"),
        "qty": line.get("qty"),
        "last_ordered_qty": _int(line.get("lastOrderedQty")),
        "inc_qty": _int(line.get("incQty"), default=0),
        "dec_qty": _int(line.get("decQty"), default=0),
        "price_key": _int(line.get("priceKey")),
        "overwritten_unit_price": line.get("overwrittenUnitPrice"),
        "default_qty": _int(line.get("defaultQty")),
        "min_qty": _int(line.get("minQty")),
        "max_qty": _int(line.get("maxQty")),
        "product_priority": _int(line.get("productPriority"), default=100),
        "unit_price": line.get("unitPrice"),
        "added_unit_price": line.get("addedUnitPrice"),
        "sub_unit_price": line.get("subUnitPrice"),
        "json_array_tags": line.get("jsonArrayTags"),
        "created_at": line.get("createdAt"),
        "last_updated": line.get("lastUpdated"),
        "custom_properties": custom_properties,
        "tax_items": tax_items,
        "comments": comments,
    }


def insert_order_from_picture(target_db_path, parsed):
    conn = sqlite3.connect(target_db_path)
    try:
        orders_row = parsed["orders_row"]
        columns = list(orders_row.keys())
        conn.execute(
            "INSERT OR REPLACE INTO Orders ({}) VALUES ({})".format(
                ", ".join(columns), ", ".join("?" for _ in columns)
            ),
            [orders_row[column] for column in columns],
        )

        order_id = parsed["order_id"]

        for key, value in parsed["custom_properties"]:
            conn.execute(
                "INSERT OR REPLACE INTO OrderCustomProperties (OrderId, Key, Value) VALUES (?, ?, ?)",
                (order_id, key, value),
            )

        for state in parsed["state_history"]:
            conn.execute(
                "INSERT OR REPLACE INTO OrderStateHistory (OrderId, StateId, Timestamp) VALUES (?, ?, ?)",
                (order_id, state["StateId"], state["Timestamp"]),
            )

        for tender in parsed["tenders"]:
            conn.execute(
                "INSERT OR REPLACE INTO OrderTender "
                "(OrderTenderId, OrderId, TenderId, Timestamp, TenderAmount, TenderDetail, TipAmount, "
                "ChangeAmount, TenderDescr, ElectronicType) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)",
                (
                    tender["OrderTenderId"],
                    order_id,
                    tender["TenderId"],
                    tender["Timestamp"],
                    tender["TenderAmount"],
                    tender["TenderDetail"],
                    tender["TipAmount"],
                    tender["ChangeAmount"],
                    tender["TenderDescr"],
                    tender["ElectronicType"],
                ),
            )

        for discount in parsed["discounts"]:
            conn.execute(
                "INSERT OR REPLACE INTO OrderDiscount "
                "(OrderId, LineNumber, ItemId, Level, PartCode, DiscountId, DiscountAmount) "
                "VALUES (?, ?, ?, ?, ?, ?, ?)",
                (
                    order_id,
                    discount["LineNumber"],
                    discount["ItemId"],
                    discount["Level"],
                    discount["PartCode"],
                    discount["DiscountId"],
                    discount["DiscountAmount"],
                ),
            )

        for line in parsed["sale_lines"]:
            _insert_sale_line(conn, order_id, line)

        conn.commit()
    finally:
        conn.close()


def _insert_sale_line(conn, order_id, line):
    conn.execute(
        "INSERT OR REPLACE INTO OrderItem "
        "(OrderId, LineNumber, ItemId, Level, PartCode, OrderedQty, LastOrderedQty, IncQty, DecQty, "
        "PriceKey, OverwrittenUnitPrice, DefaultQty, LastUpdate, CreatedAt) "
        "VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)",
        (
            order_id,
            line["line_number"],
            line["item_id"],
            line["level"],
            line["part_code"],
            line["qty"],
            line["last_ordered_qty"],
            line["inc_qty"],
            line["dec_qty"],
            line["price_key"],
            line["overwritten_unit_price"],
            line["default_qty"],
            line["last_updated"],
            line["created_at"],
        ),
    )

    if line["product_code"] is not None:
        conn.execute(
            "INSERT OR REPLACE INTO OrderProduct "
            "(OrderId, ProductCode, PartCode, ProductName, ProductType, DefaultQty, MinQty, MaxQty, "
            "MeasureUnit, ProductPriority, JsonArrayTags) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)",
            (
                order_id,
                line["product_code"],
                line["part_code"],
                line["product_name"],
                line["item_type"],
                line["default_qty"],
                line["min_qty"],
                line["max_qty"],
                line["measure_unit"],
                line["product_priority"],
                line["json_array_tags"],
            ),
        )

    if line["price_key"] is not None:
        conn.execute(
            "INSERT OR REPLACE INTO OrderPrice "
            "(OrderId, PriceKey, DefaultUnitPrice, AddedUnitPrice, SubtractedUnitPrice) "
            "VALUES (?, ?, ?, ?, ?)",
            (order_id, line["price_key"], line["unit_price"], line["added_unit_price"], line["sub_unit_price"]),
        )

    for key, value in line["custom_properties"].items():
        conn.execute(
            "INSERT OR REPLACE INTO OrderItemCustomProperties "
            "(OrderId, LineNumber, ItemId, Level, PartCode, Key, Value) VALUES (?, ?, ?, ?, ?, ?, ?)",
            (order_id, line["line_number"], line["item_id"], line["level"], line["part_code"], key, str(value)),
        )

    for tax in line["tax_items"]:
        conn.execute(
            "INSERT OR REPLACE INTO OrderTax "
            "(OrderId, LineNumber, ItemId, Level, PartCode, TaxName, TaxFiscalIndex, TaxRuleId, "
            "TaxIncluded, TaxRate, BaseAmountBD, BaseAmountAD, BaseReducedAmount, TaxAmountBD, TaxAmountAD) "
            "VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)",
            (
                order_id,
                line["line_number"],
                line["item_id"],
                line["level"],
                line["part_code"],
                tax["TaxName"],
                tax["TaxFiscalIndex"],
                tax["TaxRuleId"],
                tax["TaxIncluded"],
                tax["TaxRate"],
                tax["BaseAmountBD"],
                tax["BaseAmountAD"],
                tax["BaseReducedAmount"],
                tax["TaxAmountBD"],
                tax["TaxAmountAD"],
            ),
        )

    for comment in line["comments"]:
        conn.execute(
            "INSERT OR REPLACE INTO OrderComment "
            "(CommentId, OrderId, LineNumber, ItemId, Level, PartCode, Comment) VALUES (?, ?, ?, ?, ?, ?, ?)",
            (
                comment["CommentId"],
                order_id,
                line["line_number"],
                line["item_id"],
                line["level"],
                line["part_code"],
                comment["Comment"],
            ),
        )


def _restore_from_fiscal_order_picture(fiscal_id, pos_databases, args):
    source_db, order_id, pos_id, raw_picture = find_order_picture_in_fiscal_databases(
        args.db_dir, args.backup_dir, args.fiscal_backup_file, fiscal_id
    )
    if source_db is None:
        print("Nota {} nao encontrada em order.db, backup de pedidos ou FiscalData.".format(fiscal_id))
        return None

    if not raw_picture:
        print(
            "Nota {} encontrada em {} (OrderId={}), mas sem OrderPicture gravado - nao e possivel "
            "reconstruir o pedido.".format(fiscal_id, os.path.basename(source_db), order_id)
        )
        return None

    target_pos_id = args.pos if args.pos is not None else pos_id
    if target_pos_id is None:
        print(
            "Nota {} encontrada em {} (OrderId={}), mas nao foi possivel determinar o PosId de "
            "destino. Use --pos <N> para indicar manualmente.".format(
                fiscal_id, os.path.basename(source_db), order_id
            )
        )
        return None

    if target_pos_id not in pos_databases:
        print(
            "Nota {} encontrada em {} (OrderId={}, PosId={}), mas order.db{} nao existe em {}.".format(
                fiscal_id, os.path.basename(source_db), order_id, pos_id, target_pos_id, args.db_dir
            )
        )
        return None

    try:
        parsed = parse_order_picture(decode_order_picture(raw_picture))
    except Exception as ex:
        print("Erro ao decodificar/interpretar o OrderPicture da nota {}: {}".format(fiscal_id, ex))
        return None

    target_path = pos_databases[target_pos_id]
    print(
        "Nota {} nao encontrada em nenhum backup de pedidos, mas o registro fiscal existe em {} "
        "(OrderId={}). Reconstruindo o pedido em order.db{} a partir do OrderPicture.\n"
        "Aviso: reconstrucao best-effort a partir de um snapshot renderizado - OrderVoidHistory e "
        "taxas de delivery fee (OrderFee/OrderItemFeeValue) nao sao recuperadas por essa via.".format(
            fiscal_id, os.path.basename(source_db), order_id, target_pos_id
        )
    )

    if args.dry_run:
        print("[dry-run] Nenhuma alteracao aplicada.")
        return order_id

    if not args.yes:
        answer = input("Confirma a reconstrucao do pedido em order.db{}? [s/N] ".format(target_pos_id))
        if answer.strip().lower() not in ("s", "sim", "y", "yes"):
            print("Reconstrucao cancelada pelo usuario.")
            return None

    backup_copy = backup_file_before_write(target_path)
    print("Backup de seguranca criado: {}".format(backup_copy))

    insert_order_from_picture(target_path, parsed)
    print("Nota {} (OrderId={}) reconstruida com sucesso em order.db{} a partir do OrderPicture.".format(
        fiscal_id, order_id, target_pos_id
    ))
    return order_id


def process_note(fiscal_id, pos_databases, args):
    print("\n=== Nota fiscal {} ===".format(fiscal_id))

    resolved_order_ids = []

    live_matches = find_in_live_databases(pos_databases, fiscal_id)
    if live_matches:
        for pos_id, order_id in live_matches:
            print("Ja presente em order.db{} (OrderId={})".format(pos_id, order_id))
            resolved_order_ids.append(order_id)
    else:
        print("Nao encontrada nas bases correntes. Buscando no backup de pedidos...")
        backup_path, order_ids = find_in_backup_databases(args.backup_dir, args.backup_file, fiscal_id)

        if not backup_path:
            order_id = _restore_from_fiscal_order_picture(fiscal_id, pos_databases, args)
            if order_id is not None:
                resolved_order_ids.append(order_id)
        else:
            if len(order_ids) > 1:
                print("Aviso: mais de um OrderId encontrado para essa nota em {}: {}. Usando o primeiro.".format(
                    os.path.basename(backup_path), order_ids
                ))
            order_id = order_ids[0]

            originator_id = fetch_originator_id(backup_path, order_id)
            target_pos_id = args.pos if args.pos is not None else resolve_target_pos_id(originator_id, pos_databases)

            if target_pos_id is None:
                print(
                    "Encontrada em {} (OrderId={}, OriginatorId={}), mas nao foi possivel determinar a "
                    "base de destino automaticamente. Use --pos <N> para indicar manualmente.".format(
                        os.path.basename(backup_path), order_id, originator_id
                    )
                )
                return

            target_path = pos_databases[target_pos_id]
            print(
                "Encontrada em {} (OrderId={}, OriginatorId={}). Destino: order.db{}".format(
                    os.path.basename(backup_path), order_id, originator_id, target_pos_id
                )
            )

            if args.dry_run:
                print("[dry-run] Nenhuma alteracao aplicada.")
                resolved_order_ids.append(order_id)
            else:
                if not args.yes:
                    answer = input("Confirma a importacao para order.db{}? [s/N] ".format(target_pos_id))
                    if answer.strip().lower() not in ("s", "sim", "y", "yes"):
                        print("Importacao cancelada pelo usuario.")
                        return

                backup_copy = backup_file_before_write(target_path)
                print("Backup de seguranca criado: {}".format(backup_copy))

                import_order_from_backup(backup_path, target_path, order_id)
                print("Nota {} (OrderId={}) importada com sucesso para order.db{}.".format(
                    fiscal_id, order_id, target_pos_id
                ))
                resolved_order_ids.append(order_id)

    for order_id in resolved_order_ids:
        process_fiscal_data(order_id, args)


def main():
    parser = argparse.ArgumentParser(
        description=(
            "Busca numero(s) de nota fiscal (FISCAL_ID) nas bases order.db<N> correntes e, se nao "
            "encontrada, restaura o pedido a partir do backup de manutencao ou, em ultimo caso, "
            "reconstroi a partir do OrderPicture gravado em FiscalData. Tambem valida/restaura o "
            "registro fiscal correspondente (FiscalData) em fiscal_persistcomp.db."
        )
    )
    parser.add_argument("notas", nargs="+", help="Numero(s) de nota fiscal (FISCAL_ID) a buscar")
    parser.add_argument("--db-dir", default=DEFAULT_DB_DIR, help="Diretorio das bases correntes")
    parser.add_argument("--backup-dir", default=DEFAULT_BACKUP_DIR, help="Diretorio de backups de manutencao")
    parser.add_argument(
        "--backup-file",
        default=None,
        help=(
            "Nome de um backup de pedidos especifico a checar primeiro (ex: orders_202606.db). "
            "Opcional: sem isso, todos os orders_*.db do diretorio de backup sao varridos, do mes "
            "mais recente para o mais antigo."
        ),
    )
    parser.add_argument(
        "--fiscal-backup-file",
        default=None,
        help=(
            "Nome de um backup fiscal especifico a checar primeiro (ex: fiscal_202606.db). Opcional: "
            "sem isso, todos os fiscal_*.db do diretorio de backup sao varridos."
        ),
    )
    parser.add_argument("--pos", type=int, default=None, help="Forca a base de destino (order.db<POS>) ao restaurar")
    parser.add_argument("--dry-run", action="store_true", help="Apenas busca/relata, nao restaura nada")
    parser.add_argument("-y", "--yes", action="store_true", help="Nao pede confirmacao antes de restaurar")
    args = parser.parse_args()

    if not os.path.isdir(args.db_dir):
        print("Diretorio de bases correntes nao encontrado: {}".format(args.db_dir))
        sys.exit(1)

    pos_databases = find_pos_order_databases(args.db_dir)
    if not pos_databases:
        print("Nenhuma base order.db<N> encontrada em {}".format(args.db_dir))
        sys.exit(1)

    if not os.path.isdir(args.backup_dir):
        print("Aviso: diretorio de backup nao encontrado: {}".format(args.backup_dir))

    for fiscal_id in args.notas:
        process_note(fiscal_id, pos_databases, args)


if __name__ == "__main__":
    main()
