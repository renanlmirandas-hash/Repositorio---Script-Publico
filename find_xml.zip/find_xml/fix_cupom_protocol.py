import os
import re
import sys
import glob
import logging
import time
import base64

from datetime import datetime, timedelta
from xml.etree import cElementTree as ET


class FixingCstatCupons:
    def __init__(self, app_path):
        # type: (str) -> None
        # app_path vem de get_system_version() (consulte_csv.py) - o mesmo caminho que o main.py
        # já detecta e usa pra tudo mais (acesso_fiscal, path_orders, etc.). Antes essa classe
        # tinha seu próprio get_application_path() com um caminho fixo (só "C:/edeployPOS" ou
        # "/home/administrador/edeployPOS"), que ficava errado sempre que a instalação real fosse
        # mwpos ou edeploy-pos-structure - daí o resto da classe (bin, common3.pypkg, o
        # loader_NFCE.cfg) apontava pra pasta errada.
        self.app_path = app_path
        self.app_bin = os.path.join(self.app_path, 'bin')
        self.start_date = datetime.strftime(datetime.today() - timedelta(days=60), "%Y-%m-%d")
        self.current_date = datetime.now().strftime("%Y-%m-%d")
        self.orders_to_fix = []
        self.orders_to_verify_protocol = []

        # Usa o mesmo log já configurado pelo main.py (logging.basicConfig no system_script.log),
        # em vez de um arquivo de log separado - getLogger com esse nome só serve pra identificar
        # a origem das linhas ("FixingCstatCupons") no log único, as mensagens propagam
        # normalmente pro handler que o main.py já configurou.
        self.logger = logging.getLogger("FixingCstatCupons")
        self.logger.setLevel(logging.INFO)

        self.nfce_loader = os.path.join(self.app_path, "data/server/bundles/fiscalwrapper/loader_NFCE.cfg")
        if not os.path.exists(self.nfce_loader):
            self.logger.warning("Enviroment is not NFCE. This process is not supported")
            sys.exit(1)

        self.application_conn()

    def application_conn(self):
        self.mbcontext = None
        pump_path = os.path.join("src", "edpbohpump", "src")
        sys.path.append(os.path.join(self.app_bin, 'common3.pypkg'))
        sys.path.append(os.path.join(self.app_bin, 'edpcommon3.pypkg'))
        sys.path.append(os.path.join(self.app_path, pump_path))


        os.environ["BINPATH"] = os.path.join(self.app_path, self.app_bin)
        os.environ["HVPORT"] = "14000"
        os.environ["HVIP"] = "127.0.0.1"
        os.environ["HVCOMPPORT"] = "35689"
        os.environ["HVPID"] = "-1"

        os.chdir(os.environ["BINPATH"])
        from msgbus import MBEasyContext, FM_PARAM, TK_SLCTRL_OMGR_ORDERPICT, TK_SYS_ACK, TK_EVT_EVENT, TK_SLCTRL_OMGR_ORDERPICT
        from old_helper import BaseRepository, remove_xml_namespace
        from bustoken import TK_FISCALWRAPPER_SITUATION, TK_FISCALWRAPPER_CHANGE_CONTINGENCY_STATUS
        import cfgtools

        self.mbcontext = MBEasyContext("STANDALONE_SCRIPT")
        self.base_repository = BaseRepository
        self.FM_PARAM = FM_PARAM
        self.TK_EVT_EVENT = TK_EVT_EVENT
        self.TK_SLCTRL_OMGR_ORDERPICT = TK_SLCTRL_OMGR_ORDERPICT
        self.TK_FISCALWRAPPER_SITUATION = TK_FISCALWRAPPER_SITUATION
        self.TK_FISCALWRAPPER_CHANGE_CONTINGENCY_STATUS = TK_FISCALWRAPPER_CHANGE_CONTINGENCY_STATUS
        self.TK_SYS_ACK = TK_SYS_ACK
        self.cfgtools = cfgtools
        self.remove_xml_namespace = remove_xml_namespace

    def find_key_pattern(self, orderid):
        # type: (int) -> bool
        """
        Procura no FiscalWrapperThread.log a linha que o nfce.py grava quando detecta cStat 539
        (duplicidade de NF-e) e tenta tratar via _handle_duplicated_diff_key, por exemplo:

            "... nfce.py:2349:_handle_duplicated_diff_key - Tratando 539 da order 000123413.
             xMotivo SEFAZ: Rejeição: Duplicidade de NF-e, com diferença na Chave de Acesso
             52260817261661005566650010001226111137067129"

        e usa a "Chave de Acesso" indicada ali (a chave que o SEFAZ já reconhece pra essa nota)
        pra corrigir o protocolo via fix_cstat - mesmo quando o próprio nfce.py também tenta uma
        segunda chave ("XML remontado") e não consegue resolver sozinho.

        Substitui o padrão antigo (buscava "OrderId: [...] - Response processamento", que não
        existe mais no formato de log atual do FiscalWrapperThread e por isso nunca encontrava
        nada em produção).
        """
        self.logger.info("Procurando cStat corrigível nos logs do FiscalWrapper - orderid: {}".format(orderid))
        fiscal_component_directory = os.path.join(self.app_path, "data/server/bundles/fiscalwrapper")
        logs = glob.glob(os.path.join(fiscal_component_directory, "FiscalWrapperThread.log*"))
        order_padded = str(orderid).zfill(9)
        re_pattern = r"Tratando (\d{{3}}) da order {}\..*?Chave de Acesso ([0-9]{{44}})".format(
            re.escape(order_padded))

        for file in logs:
            try:
                with open(file, encoding="utf-8", errors="replace") as f:
                    log = f.read()
            except OSError as ex:
                self.logger.warning("Não foi possível ler o log {}: {}".format(file, ex))
                continue

            for cstat, key in re.findall(re_pattern, log):
                if cstat in ("539", "100", "150"):
                    self.fix_cstat(orderid, key, cstat)
                    return True
                elif cstat == "204":
                    return bool(self.key_pattern_fiscallog(orderid, key, cstat))
                else:
                    self.logger.info("Found cStat: {} for orderid: {} ".format(cstat, orderid))

        self.logger.info("Nenhum cStat corrigível encontrado nos logs do FiscalWrapper - orderid: {}".format(orderid))
        return False

    def key_pattern_fiscallog(self, orderid, key, cstat):
        fiscal_component_directory = os.path.join(self.app_path, "data/server/bundles/fiscalwrapper")
        logs = reversed(glob.glob(os.path.join(fiscal_component_directory, "FiscalWrapper.log*")))
        re_pattern = "OrderId {} final [0-9]*".format(str(orderid).zfill(9))

        for file in logs:
            with open(file) as f:
                log = f.read()

            if re.search(re_pattern, log):
                for found_pattern in re.findall(re_pattern, log):
                    if not found_pattern.split('final ')[1] in key[30:]:
                        key = key[:30] + found_pattern.split('final ')[1]
                        self.fix_cstat(orderid, key, cstat)
                        return True

    def not_send_orders(self,):
        def inner_func(conn):
         # type: (Connection) -> dict
            query = """
            select orderid from fiscaldata where 
            senttonfce <> 1 and datetime(datanota,'unixepoch','localtime') 
            BETWEEN "{}" and "{}" """.format(self.start_date, self.current_date)

            return [(x.get_entry(0)) for x in conn.select(query)]

        orders_not_send = \
            self.base_repository(self.mbcontext).execute_with_connection(inner_func, service_name="FiscalPersistence")
        if len(orders_not_send) > 0:
            return orders_not_send

        self.logger.info("Nenhuma nota pendente de envio no período: {} a {}".format(self.start_date, self.current_date))

    def force_orders(self,):
        def inner_func(conn):
         # type: (Connection) -> dict
            query = \
                """update fiscaldata set senttonfce = 555 where orderid in ({})""".format(','.join(self.orders_to_fix))

            conn.select(query)

        self.base_repository(self.mbcontext).execute_with_connection(inner_func, service_name="FiscalPersistence")

    def send_fiscalwrapper_event(self, content, token=None):
        if not token:
            token = self.TK_EVT_EVENT
            content = '\0{}'.format(content)

        self.mbcontext.MB_EasySendMessage(
            "FiscalWrapper",
            token,
            format=self.FM_PARAM,
            data=content
        )

    def get_order_picture(self, orderid):
        msg = self.mbcontext.MB_EasySendMessage(
            "ORDERMGR0",
            self.TK_SLCTRL_OMGR_ORDERPICT,
            format=self.FM_PARAM,
            data='\00{}'.format(orderid)
        )

        if msg.token == self.TK_SYS_ACK:
            parsed_data = msg.data.split("\0")
            if parsed_data[2] != "":
                return ET.fromstring(parsed_data[2]).find('./')

    def get_xml_request(self, orderid):
        def inner_func(conn):
         # type: (Connection) -> dict
            query = """select xmlrequest from fiscaldata where orderid = {}""".format(orderid)

            return [(x.get_entry(0)) for x in conn.select(query)]

        return self.base_repository(self.mbcontext).execute_with_connection(inner_func, service_name="FiscalPersistence")

    def get_cupons(self,):
        def inner_func(conn):
         # type: (Connection) -> dict
            query = """select numeronota from fiscaldata where orderid in ({})""".format(",".join(self.orders_to_fix))

            return [(x.get_entry(0)) for x in conn.select(query)]

        return self.base_repository(self.mbcontext).execute_with_connection(inner_func, service_name="FiscalPersistence")

    def get_pos_list(self):
        def inner_func(conn):
            query = """select posid from posstate"""

            return [(x.get_entry(0)) for x in conn.select(query)]

        return self.base_repository(self.mbcontext).execute_with_connection(inner_func, db_name="posctrl")

    def get_orders_unused(self):
        pos_list = self.get_pos_list()

        def inner_func(conn):
            query = """select orderid from orders where orderid in (select orderid from 
            OrderCustomProperties where key = 'ORDER_DISABLED' and value = 'false')"""

            return [(x.get_entry(0)) for x in conn.select(query)]

        return self.base_repository(self.mbcontext).execute_parallel_in_all_databases_returning_flat_list(inner_func, pos_list)

    def delete_failed_inutilization(self, orderid):
        pos_list = self.get_pos_list()
        conn = None
        def inner_func(conn):
            query = """delete from ordercustomproperties where key = 'ORDER_DISABLED' and orderid = {}""".format(orderid)

            conn.select(query)

        try:
            self.base_repository(self.mbcontext).execute_parallel_in_all_databases_returning_flat_list(inner_func, pos_list)
        except Exception:
            self.logger.exception("Erro ao deletar ORDER_DISABLED - orderid: {}".format(orderid))
        finally:
            if conn:
                conn.close()

    def process_resign(self):
        self.logger.info("Iniciando process_resign - período: {} a {}".format(self.start_date, self.current_date))
        self.orders_not_send = self.not_send_orders()

        if self.orders_not_send:
            for orderid in self.orders_not_send:
                order_picture = self.get_order_picture(orderid)
                if order_picture:
                    stateid = order_picture.find('.').attrib["stateId"]

                    if not stateid == "4" and not (self.find_key_pattern(orderid)):
                        self.orders_to_fix.append(orderid)
                else:
                    self.logger.info("Unable to obtain orderpicture for orderid: {}".format(orderid))

        if len(self.orders_to_verify_protocol) > 0:
            min_date = min(self.orders_to_verify_protocol)
            max_date = max(self.orders_to_verify_protocol)
            self.running_nfe_situation(min_date, max_date)
            self.logger.info("Running check situation sefaz. See process on fiscalwrapper.log")


        if not len(self.orders_to_fix) > 0:
            self.logger.info("Not found any order paid pending to sent SEFAZ")
            return

        self.force_orders()
        self.cupons_to_fix = self.get_cupons()
        self.logger.info("Resign sent NumeroNota to SEFAZ: {}".format(",".join(str(c) for c in self.cupons_to_fix)))
        self.send_fiscalwrapper_event("ReSignXMLs")
        self.send_fiscalwrapper_event("Enabled", token=self.TK_FISCALWRAPPER_CHANGE_CONTINGENCY_STATUS)
        time.sleep(6)
        self.send_fiscalwrapper_event("Disabled", token=self.TK_FISCALWRAPPER_CHANGE_CONTINGENCY_STATUS)

    def process_unused_orders(self):
        self.orders = self.get_orders_unused()
        self.orders_unused = set(self.orders)
        force_disable = None

        for orderid in self.orders_unused:
            order_picture = self.get_order_picture(orderid)
            if order_picture:
                stateid = order_picture.find('.').attrib["stateId"]
                numeronota = order_picture.find("CustomOrderProperties/OrderProperty/[@key='FISCAL_ID']").get('value')
                pos_id = order_picture.find('.').attrib["posId"]
                for state in reversed(order_picture.find('StateHistory').findall('State')):
                    if state.get('stateId') == "5":
                        force_disable = False
                        break

                    force_disable = True

                if force_disable:
                    inutilization_status = \
                        order_picture.find("CustomOrderProperties/OrderProperty/[@key='ORDER_DISABLED']").get('value')

                    self.logger.info("Forcing inutilization for orderid: {} numeronota: {} "
                                     "stateid: {} current inutilization state: {}"
                                     .format(orderid, numeronota, stateid, inutilization_status))
                    self.delete_failed_inutilization(orderid)
                    self.send_fiscalwrapper_event("DisableNfceOrder")
                    time.sleep(5)
            else:
                self.logger.info("Unable to obtain orderpicture for orderid: {}".format(orderid))


    def update_fiscal_persist(self, orderid, new_request):
        def inner_func(conn):
         # type: (Connection) -> dict
            query = """update fiscaldata set xmlrequest = '{}' where orderid = {}""".format(new_request, orderid)

            conn.select(query)

        self.base_repository(self.mbcontext).execute_with_connection(inner_func, service_name="FiscalPersistence")
    def fix_cstat(self, orderid, key, cstat):
        # type: (int, str, str) -> None
        self.logger.info("Iniciando fix_cstat - orderid: {} key: {} cstat: {}".format(orderid, key, cstat))
        try:
            order_picture = self.get_order_picture(orderid)
            xml_request = order_picture.find("CustomOrderProperties/OrderProperty/[@key='FISCAL_XML']").get('value')
            # base64.b64decode devolve bytes em Python 3 (em Python 2 devolvia str/bytes de forma
            # intercambiável) - todo o replace/concatenação abaixo precisa ser feito em bytes, e só
            # o resultado final (já em base64) volta a ser texto para ir na query SQL.
            xml_string_fiscal_persistcomp = base64.b64decode(xml_request)
            xml_element = ET.fromstring(xml_string_fiscal_persistcomp)
            inf_nfe = self.remove_xml_namespace(ET.tostring(xml_element.find(".//")))
            nfe_key = inf_nfe.attrib["Id"][3:]
            new_xml = xml_string_fiscal_persistcomp.replace(nfe_key.encode("utf-8"), key.encode("utf-8"))
            numeronota = inf_nfe.find(".//nNF").text

            base_xml = b'''<nfeProc xmlns="http://www.portalfiscal.inf.br/nfe" versao="4.00">'''
            end_xml = b'''<protNFe versao="4.00"><infProt><tpAmb>1</tpAmb><verAplic>PR-v4_4_9</verAplic><chNFe></chNFe><dhRecbto>2021-08-02T16:30:48-03:00</dhRecbto><cStat>204</cStat><xMotivo>Duplicidade de NF-e [nRec:411002421114061]</xMotivo></infProt></protNFe></nfeProc>'''

            new_request = base64.b64encode(base_xml + new_xml + end_xml).decode("ascii")
            self.logger.info("Fixing protocol orderid: {} numero nota: {} with key: {}".format(orderid, numeronota, key))
            self.update_fiscal_persist(orderid, new_request)
            date = inf_nfe.find(".//dhEmi").text[0:10].replace('-', '')

            if date not in self.orders_to_verify_protocol:
                self.orders_to_verify_protocol.append(date)
        except Exception:
            self.logger.exception("Falha ao corrigir protocolo (fix_cstat) - orderid: {} key: {} cstat: {}".format(orderid, key, cstat))
            raise

    def running_nfe_situation(self, min_date, max_date):
        data = "{}\0{}".format(min_date, max_date)
        self.send_fiscalwrapper_event(data, token=self.TK_FISCALWRAPPER_SITUATION)

