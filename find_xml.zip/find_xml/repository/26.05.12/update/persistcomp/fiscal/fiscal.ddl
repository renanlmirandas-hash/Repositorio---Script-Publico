-- noinspection SqlNoDataSourceInspectionForFile

-- Schema: fiscal
-- Brief: Fiscal database definition
-- Created by: garaujo
-- Table schema_version: must be defined for database update through the Persistence Component

CREATE TABLE schema_version AS
SELECT "$Author$" AS Author,
       "$Date$" AS LastModifiedAt,
       "$Revision:$" AS Revision;

CREATE TABLE FiscalData (
    PosId INTEGER NOT NULL,
    OrderId INTEGER NOT NULL,
    XMLRequest VARCHAR NOT NULL,
    NumeroNota VARCHAR NOT NULL,
    NumeroSat VARCHAR NOT NULL,
    NextDateToSend VARCHAR DEFAULT NULL,
    SentToNfce INTEGER DEFAULT 0,
    NextDateToSendToBKC VARCHAR,
    OrderPicture VARCHAR NOT NULL DEFAULT '1',
    DataNota VARCHAR NOT NULL DEFAULT '1',
    XMLResponse VARCHAR DEFAULT NULL,
    InvoiceType VARCHAR NOT NULL DEFAULT 'NFCE',
    TransmittedXMLRequest VARCHAR DEFAULT NULL,
    PRIMARY KEY(OrderId)
);

CREATE TABLE JanitorData (
    Id INTEGER PRIMARY KEY,
    ProcessName TEXT NOT NULL,
    Created DATETIME DEFAULT CURRENT_TIMESTAMP,
    Updated DATETIME
);
CREATE UNIQUE INDEX idx_janitordata_processname
ON JanitorData (ProcessName);

CREATE TABLE BandeiraCartao (
    Bandeira INTEGER NOT NULL,
    Descricao VARCHAR,
    Type INTEGER NOT NULL,
    BKC_Id INTEGER,
    BKC_Nome VARCHAR,
    Detalhes VARCHAR,
    PRIMARY KEY(Bandeira)
);

-- ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++

CREATE TABLE Sequencer (
    SeqNo INTEGER NOT NULL,
    SeqNm VARCHAR NOT NULL,
    PRIMARY KEY(SeqNm)
);

INSERT OR IGNORE INTO Sequencer VALUES (0,'FiscalId');
INSERT OR IGNORE INTO Sequencer VALUES (0,'FiscalIdNfe');

-- ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++

-- Credito 1 | Voucher/Debito 2
INSERT INTO BandeiraCartao VALUES (1,'VISA CREDITO',1,7766,'VISA CREDITO','Credito');
INSERT INTO BandeiraCartao VALUES (10001,'Ticket',2,7798,'Other Cards','Voucher');
INSERT INTO BandeiraCartao VALUES (20001,'MAESTRO DÉBITO',2,7798,'MAESTRO DÉBITO','Debito');
INSERT INTO BandeiraCartao VALUES (2,'MASTERCARD',2,7737,'Master Card','Credito');
INSERT INTO BandeiraCartao VALUES (10002,'Visa Vale',2,7798,'Other Cards','Voucher');
INSERT INTO BandeiraCartao VALUES (20002,'VISAELECTRON DÉBITO',2,7798,'Other Cards','Debito');
INSERT INTO BandeiraCartao VALUES (3,'DINERS',1,7770,'Other Cards','Credito');
INSERT INTO BandeiraCartao VALUES (10003,'Sodexo',2,7798,'Other Cards','Voucher');
INSERT INTO BandeiraCartao VALUES (20003,'Cabal',2,7798,'Other Cards','Debito');
INSERT INTO BandeiraCartao VALUES (4,'AMEX CREDITO',1,7769,'AMEX CREDITO','Credito');
INSERT INTO BandeiraCartao VALUES (10004,'Nutricash',2,7798,'Other Cards','Debito');
INSERT INTO BandeiraCartao VALUES (5,'SOLLO',1,7798,'Other Cards','Credito');
INSERT INTO BandeiraCartao VALUES (10005,'Greencard',2,7798,'Other Cards','Voucher');
INSERT INTO BandeiraCartao VALUES (6,'SIDECARD (REDECARD)',1,7798,'Other Cards','Credito');
INSERT INTO BandeiraCartao VALUES (10006,'Planvale',2,7798,'Other Cards','Voucher');
INSERT INTO BandeiraCartao VALUES (7,'PRIVATE LABEL (REDECARD)',1,7798,'Other Cards','Credito');
INSERT INTO BandeiraCartao VALUES (10007,'Banquet',2,7798,'Other Cards','Voucher');
INSERT INTO BandeiraCartao VALUES (20007,'Private Label',2,7798,'Other Cards','Debito');
INSERT INTO BandeiraCartao VALUES (8,'REDESHOP',1,7798,'Other Cards','Credito');
INSERT INTO BandeiraCartao VALUES (10008,'Verocheque',2,7798,'Other Cards','Voucher');
INSERT INTO BandeiraCartao VALUES (9,'Pão de Açucar',1,7798,'Other Cards','Credito');
INSERT INTO BandeiraCartao VALUES (10009,'Sapore',2,7798,'Other Cards','Voucher');
INSERT INTO BandeiraCartao VALUES (10,'FININVEST (VISANET)',1,7798,'Other Cards','Credito');
INSERT INTO BandeiraCartao VALUES (10010,'BNB Clube',2,7798,'Other Cards','Voucher');
INSERT INTO BandeiraCartao VALUES (11,'JCB',1,7798,'Other Cards','Credito');
INSERT INTO BandeiraCartao VALUES (10011,'Valecard',2,7798,'Other Cards','Voucher');
INSERT INTO BandeiraCartao VALUES (12,'HIPERCARD CREDITO',1,7798,'Other Cards', 'Credito');
INSERT INTO BandeiraCartao VALUES (10012,'Cabal',2,7798,'Other Cards','Voucher');
INSERT INTO BandeiraCartao VALUES (20012,'Cabal',2,7798,'Other Cards','Debito');
INSERT INTO BandeiraCartao VALUES (13,'AURA',1,7798,'Other Cards','Credito');
INSERT INTO BandeiraCartao VALUES (10013,'Elo',2,7798,'Other Cards','Voucher');
INSERT INTO BandeiraCartao VALUES (20013,'Elo',2,7798,'Other Cards','Debito');
INSERT INTO BandeiraCartao VALUES (14,'LOSANGO',1,7798,'Other Cards','Credito');
INSERT INTO BandeiraCartao VALUES (10014,'Discovery',2,7798,'Other Cards','Voucher');
INSERT INTO BandeiraCartao VALUES (15,'SOROCRED',1,7798,'Other Cards','Credito');
INSERT INTO BandeiraCartao VALUES (10015,'Goodcard',2,7798,'Other Cards','Voucher');
INSERT INTO BandeiraCartao VALUES (10016,'Policard',2,7798,'Other Cards','Voucher');
INSERT INTO BandeiraCartao VALUES (10017,'Cardsystem',2,7798,'Other Cards','Voucher');
INSERT INTO BandeiraCartao VALUES (10018,'Bonus CBA',2,7798,'Other Cards','Voucher');
INSERT INTO BandeiraCartao VALUES (10019,'Alelo',2,7798,'Other Cards','Voucher');
INSERT INTO BandeiraCartao VALUES (10020,'Banescard',2,7798,'Other Cards','Voucher');
INSERT INTO BandeiraCartao VALUES (21,'BANRISUL',2,7798,'Other Cards','');
INSERT INTO BandeiraCartao VALUES (10021,'ALELO REFEIÇÃO',2,7798,'Other Cards','Refeicao');
INSERT INTO BandeiraCartao VALUES (10022,'Alelo',2,7798,'Other Cards','Alimentacao');
INSERT INTO BandeiraCartao VALUES (10023,'Alelo',2,7798,'Other Cards','Cultura');
INSERT INTO BandeiraCartao VALUES (10024,'TICKET RESTAURANTE',2,7798,'Other Cards','Refeicao');
INSERT INTO BandeiraCartao VALUES (10025,'Ticket',2,7798,'Other Cards','Alimentacao');
INSERT INTO BandeiraCartao VALUES (10026,'Ticket',2,7798,'Other Cards','Parceiro');
INSERT INTO BandeiraCartao VALUES (10027,'Ticket',2,7798,'Other Cards','Cultura');
INSERT INTO BandeiraCartao VALUES (10028,'SODEXO REFEIÇÃO',2,7798,'Other Cards','Refeicao');
INSERT INTO BandeiraCartao VALUES (10029,'Sodexo',2,7798,'Other Cards','Alimentacao');
INSERT INTO BandeiraCartao VALUES (10030,'Sodexo',2,7798,'Other Cards','Gift');
INSERT INTO BandeiraCartao VALUES (10031,'Sodexo',2,7798,'Other Cards','Premium');
INSERT INTO BandeiraCartao VALUES (10032,'Sodexo',2,7798,'Other Cards','Cultura');
INSERT INTO BandeiraCartao VALUES (10033,'Sodexo',2,7798,'Other Cards','Combustivel');
INSERT INTO BandeiraCartao VALUES (10051,'Planvale',2,7798,'Other Cards','Cultura');
INSERT INTO BandeiraCartao VALUES (10053,'Nutricash',2,7798,'Other Cards','Cultura');
INSERT INTO BandeiraCartao VALUES (10054,'Ticket',2,7798,'Other Cards','Combustivel');
INSERT INTO BandeiraCartao VALUES (10055,'Valecard',2,7798,'Other Cards','Cultura');
INSERT INTO BandeiraCartao VALUES (30,'Cabal',1,7798,'Other Cards','Credito');
INSERT INTO BandeiraCartao VALUES (31,'Elo',1,7798,'Other Cards','Credito');
INSERT INTO BandeiraCartao VALUES (20032,'ELO DÉBITO',2,7798,'Other Cards','Debito');
INSERT INTO BandeiraCartao VALUES (33,'Policard',1,7798,'Other Cards','Credito');
INSERT INTO BandeiraCartao VALUES (20034,'Policard',2,7798,'Other Cards','Debito');
INSERT INTO BandeiraCartao VALUES (35,'Banescard',1,7798,'Other Cards','Credito');
INSERT INTO BandeiraCartao VALUES (20036,'Banescard',2,7798,'Other Cards','Debito');
INSERT INTO BandeiraCartao VALUES (10037,'Sorocred',2,7798,'Other Cards','Voucher');
INSERT INTO BandeiraCartao VALUES (20037,'Hipercard',2,7798,'Other Cards','Debito');
INSERT INTO BandeiraCartao VALUES (38,'Cetelem',1,7798,'Other Cards','Credito');
INSERT INTO BandeiraCartao VALUES (10039,'Valemulti',2,7798,'Other Cards','Voucher');
INSERT INTO BandeiraCartao VALUES (10040,'Valefrota',2,7798,'Other Cards','Combustivel');
INSERT INTO BandeiraCartao VALUES (41,'Sicredi',1,7798,'Other Cards','Credito');
INSERT INTO BandeiraCartao VALUES (20042,'Sicredi',2,7798,'Other Cards','Debito');
INSERT INTO BandeiraCartao VALUES (43,'Coopercred',1,7798,'Other Cards','Credito');
INSERT INTO BandeiraCartao VALUES (10044,'Coopercred',2,7798,'Other Cards','Voucher');
INSERT INTO BandeiraCartao VALUES (45,'A Vista',1,7798,'Other Cards','Credito');
INSERT INTO BandeiraCartao VALUES (10046,'Valefácil',2,7798,'Other Cards','Voucher');
INSERT INTO BandeiraCartao VALUES (10047,'VR REFEIÇÃO',2,7798,'Other Cards','Refeicao');
INSERT INTO BandeiraCartao VALUES (10048,'VR',2,7798,'Other Cards','Alimentacao');
INSERT INTO BandeiraCartao VALUES (10049,'VR',2,7798,'Other Cards','Combustivel');
INSERT INTO BandeiraCartao VALUES (10050,'VR',2,7798,'Other Cards','Cultura');
INSERT INTO BandeiraCartao VALUES (10052,'Banrisul',2,7798,'Other Cards','Cultura');
INSERT INTO BandeiraCartao VALUES (57,'Credisystem',1,7798,'Other Cards','Credito');
INSERT INTO BandeiraCartao VALUES (58,'Banpará',1,7798,'Other Cards','Credito');
INSERT INTO BandeiraCartao VALUES (20059,'Banpará',2,7798,'Other Cards','Debito');
INSERT INTO BandeiraCartao VALUES (60,'Amazoncard',1,17798,'Other Cards','Credito');
INSERT INTO BandeiraCartao VALUES (61,'Yamada',1,7798,'Other Cards','Credito');
INSERT INTO BandeiraCartao VALUES (62,'Goiascard',1,7798,'Other Cards','Credito');
INSERT INTO BandeiraCartao VALUES (63,'Credpar',1,7798,'Other Cards','Credito');
INSERT INTO BandeiraCartao VALUES (64,'Boticario',1,7798,'Other Cards','Credito');
INSERT INTO BandeiraCartao VALUES (65,'Ascard',1,7798,'Other Cards','Credito');
INSERT INTO BandeiraCartao VALUES (66,'Jetpar',1,7798,'Other Cards','Credito');
INSERT INTO BandeiraCartao VALUES (67,'Maxxcard',1,7798,'Other Cards','Credito');
INSERT INTO BandeiraCartao VALUES (68,'Garantido',1,7798,'Other Cards','Credito');
INSERT INTO BandeiraCartao VALUES (69,'Amazon Prime',1,7798,'Other Cards','Credito');
INSERT INTO BandeiraCartao VALUES (70,'CredZ',1,7798,'Other Cards','Credito');
INSERT INTO BandeiraCartao VALUES (10070,'VR ALIMENTAÇÃO VOUCHER',2,7798,'Other Cards','Voucher');
INSERT INTO BandeiraCartao VALUES (71,'Credishop',1,7798,'Other Cards','Credito');
INSERT INTO BandeiraCartao VALUES (10071,'Planvale',2,7798,'Other Cards','Voucher');
INSERT INTO BandeiraCartao VALUES (20071,'Sorocred',2,7798,'Other Cards','Debito');
INSERT INTO BandeiraCartao VALUES (10072,'Planvale',2,7798,'Other Cards','Alimentacao');
INSERT INTO BandeiraCartao VALUES (20072,'Maxxicard',2,7798,'Other Cards','Debito');
INSERT INTO BandeiraCartao VALUES (73,'Libercard',1,7798,'Other Cards','Credito');
INSERT INTO BandeiraCartao VALUES (10073,'Planvale',2,7798,'Other Cards','Refeicao');
INSERT INTO BandeiraCartao VALUES (20073,'Maxxicard',1,7798,'Other Cards','Credito');
INSERT INTO BandeiraCartao VALUES (10074,'Planvale',2,7798,'Other Cards','Combustivel');
INSERT INTO BandeiraCartao VALUES (20074,'Maxxicard',2,7798,'Other Cards','Gift');
INSERT INTO BandeiraCartao VALUES (10075,'Planvale',2,7798,'Other Cards','Farmácia');
INSERT INTO BandeiraCartao VALUES (20075,'Maxxicard',2,7798,'Other Cards','Combustivel');
INSERT INTO BandeiraCartao VALUES (10076,'Peela',2,7798,'Other Cards','Gift');
INSERT INTO BandeiraCartao VALUES (10077,'Libercard',2,7798,'Other Cards','Voucher');
INSERT INTO BandeiraCartao VALUES (78,'Peela',1,7798,'Other Cards','Credito');
INSERT INTO BandeiraCartao VALUES (10079,'Up',2,7798,'Other Cards','Voucher');
INSERT INTO BandeiraCartao VALUES (10080,'Up',2,7798,'Other Cards','Combustivel');
INSERT INTO BandeiraCartao VALUES (10081,'Up',2,7798,'Other Cards','Cultura');
INSERT INTO BandeiraCartao VALUES (10082,'Elo',2,7798,'Other Cards','Combustivel');
INSERT INTO BandeiraCartao VALUES (10083,'VR',2,7798,'Other Cards','Voucher');
INSERT INTO BandeiraCartao VALUES (82,'GETNET',0,7798,'Other Cards',''); -- type 0
INSERT INTO BandeiraCartao VALUES (84,'Banrisul',1,7798,'Other Cards','Credito');
INSERT INTO BandeiraCartao VALUES (20085,'Banrisul',2,7798,'Other Cards','Debito');
INSERT INTO BandeiraCartao VALUES (86,'Verdecard',1,7798,'Other Cards','Credito');
INSERT INTO BandeiraCartao VALUES (87,'Refeisul',1,7798,'Other Cards','Credito');
INSERT INTO BandeiraCartao VALUES (10088,'Refeisul',2,7798,'Other Cards','Combustivel');
INSERT INTO BandeiraCartao VALUES (10089,'Refeisul',2,7798,'Other Cards','Alimentacao');
INSERT INTO BandeiraCartao VALUES (125,'VISANET - ESPECIFICAÇÃO 4.1',0,7798,'Other Cards', ''); -- type 0
INSERT INTO BandeiraCartao VALUES (99990,'Débito - Exteno',2,7798,'Other Cards', 'Débito');
INSERT INTO BandeiraCartao VALUES (99991,'Crédito Outros - Exteno',2,7798,'Other Cards', 'Crédito');
INSERT INTO BandeiraCartao VALUES (99992,'Vale Refeição - Exteno',2,7798,'Other Cards', 'Voucher');

-- ++++++++++++++++++++++ DIGITAL WALLETS ++++++++++++++++++++++++++++++++++++++++++
INSERT INTO BandeiraCartao VALUES (150001, 'VC +', 2, 7798, 'Other Cards', 'Carteiras Digitais');
INSERT INTO BandeiraCartao VALUES (190002, 'NuCash', 2, 7798, 'Other Cards', 'Carteiras Digitais');
INSERT INTO BandeiraCartao VALUES (200003, 'Veloe', 2, 7798, 'Other Cards', 'Carteiras Digitais');
INSERT INTO BandeiraCartao VALUES (210004, 'IzPay', 2, 7798, 'Other Cards', 'Carteiras Digitais');
INSERT INTO BandeiraCartao VALUES (260005, 'Vee', 2, 7798, 'Other Cards', 'Carteiras Digitais');
INSERT INTO BandeiraCartao VALUES (290006, 'Mercado Pago', 2, 7798, 'Other Cards', 'Carteiras Digitais');
INSERT INTO BandeiraCartao VALUES (300007, 'MoneyPag', 2, 7798, 'Other Cards', 'Carteiras Digitais');
INSERT INTO BandeiraCartao VALUES (340008, 'Troco Simples', 2, 7798, 'Other Cards', 'Carteiras Digitais');
INSERT INTO BandeiraCartao VALUES (380009, 'Itaú', 2, 7798, 'Other Cards', 'Carteiras Digitais');
INSERT INTO BandeiraCartao VALUES (550010, 'BeeVale', 2, 7798, 'Other Cards', 'Carteiras Digitais');
INSERT INTO BandeiraCartao VALUES (580011, 'BrinksPay', 2, 7798, 'Other Cards', 'Carteiras Digitais');
INSERT INTO BandeiraCartao VALUES (600012, 'PicPay', 2, 7798, 'Other Cards', 'Carteiras Digitais');
INSERT INTO BandeiraCartao VALUES (650013, 'PagSeguro', 2, 7798, 'Other Cards', 'Carteiras Digitais');
INSERT INTO BandeiraCartao VALUES (660014, 'Meu Vale', 2, 7798, 'Other Cards', 'Carteiras Digitais');
INSERT INTO BandeiraCartao VALUES (120015, 'Verde Card', 2, 7798, 'Other Cards', 'Carteiras Digitais');
INSERT INTO BandeiraCartao VALUES (340017, 'Troco Simples Doação', 2, 7798, 'Other Cards', 'Carteiras Digitais');
INSERT INTO BandeiraCartao VALUES (40018, 'TicketLog', 2, 7798, 'Other Cards', 'Carteiras Digitais');
INSERT INTO BandeiraCartao VALUES (130019, 'GoodCard', 2, 7798, 'Other Cards', 'Carteiras Digitais');
INSERT INTO BandeiraCartao VALUES (640020, 'ABM Cash', 2, 7798, 'Other Cards', 'Carteiras Digitais');
INSERT INTO BandeiraCartao VALUES (720021, 'ConnectyPay', 2, 7798, 'Other Cards', 'Carteiras Digitais');
INSERT INTO BandeiraCartao VALUES (760023, 'AME Digital', 2, 7798, 'Other Cards', 'Carteiras Digitais');
INSERT INTO BandeiraCartao VALUES (810025, 'UpBrasil', 2, 7798, 'Other Cards', 'Carteiras Digitais');
INSERT INTO BandeiraCartao VALUES (840026, 'Sem Parar', 2, 7798, 'Other Cards', 'Carteiras Digitais');
INSERT INTO BandeiraCartao VALUES (860027, 'Cash Berti', 2, 7798, 'Other Cards', 'Carteiras Digitais');
INSERT INTO BandeiraCartao VALUES (870028, 'ComproPay', 2, 7798, 'Other Cards', 'Carteiras Digitais');
INSERT INTO BandeiraCartao VALUES (1030037, 'Conductor', 2, 7798, 'Other Cards', 'Carteiras Digitais');
INSERT INTO BandeiraCartao VALUES (60110024, 'PIX', 2, 7798, 'Other Cards', 'Carteiras Digitais');
INSERT INTO BandeiraCartao VALUES (60110042, 'Pix Saque', 2, 7798, 'Other Cards', 'Carteiras Digitais');
INSERT INTO BandeiraCartao VALUES (60110043, 'Pix Troco', 2, 7798, 'Other Cards', 'Carteiras Digitais');
INSERT INTO BandeiraCartao VALUES (80001000, 'Cielo', 2, 7798, 'Other Cards', 'Carteiras Digitais');
INSERT INTO BandeiraCartao VALUES (80021002, 'Tá Pago', 2, 7798, 'Other Cards', 'Carteiras Digitais');
INSERT INTO BandeiraCartao VALUES (80031003, '4All', 2, 7798, 'Other Cards', 'Carteiras Digitais');
INSERT INTO BandeiraCartao VALUES (80051004, 'Midway', 2, 7798, 'Other Cards', 'Carteiras Digitais');
INSERT INTO BandeiraCartao VALUES (00920030, 'PayFace', 2, 7798, 'Other Cards', 'Carteiras Digitais');
INSERT INTO BandeiraCartao VALUES (60120033, 'QR Pago', 2, 7798, 'Other Cards', 'Carteiras Digitais');
INSERT INTO BandeiraCartao VALUES (970034, 'Rappi', 2, 7798, 'Other Cards', 'Carteiras Digitais');
INSERT INTO BandeiraCartao VALUES (980035, 'Banco24Horas', 2, 7798, 'Other Cards', 'Carteiras Digitais');
