from util import get_version, restart_component
import os
import sys
from distutils.dir_util import copy_tree
import re
import zipfile
import shutil

GENESIS_PATH = "C:\\edeployPOS\\genesis\\src\\"
DATA_PATH = "C:\\edeployPOS\\src\\"
BASE_UPDATE_FILE = os.path.dirname(os.path.realpath(__file__))
UPDATE_DIRS = [GENESIS_PATH, DATA_PATH]


def main():
    version = get_version()
    if sys.argv[1] in ("update", "rollback"):
        execute(version, "update")
    else:
        print("Invalid option {}".format(sys.argv))
        sys.exit(1)


def execute(version, action):
    print("Updating files for version: {} with: {}".format(version, action))
    if version == "CORE:5.2.6|SRC:26.05.06":
        update_dir = os.path.join(BASE_UPDATE_FILE, "repository\\26.05.06\\{}".format(action))
        for component in os.listdir(update_dir):
            copy_update_file(os.path.join(update_dir, component), component)
            restart_component(component)
            return
    else:
        raise ValueError("Version already has the fix : {}, abort".format(version))

    print("Process done")
    
def remove_pyc_files(file):
    for root, dirs, files in os.walk(file):
        for f in files:
            if f.endswith(".pyc"):
                os.remove(os.path.join(root, f))


def copy_update_file(file, component):
    for d in UPDATE_DIRS:
        f = os.path.join(d, component)
        if DATA_PATH in d:
            remove_pyc_files(f)

        copy_tree(file, f)
def parse_version(v):
    m = re.match(r"CORE:(\d+)\.(\d+)\.(\d+)\|SRC:(\d+)\.(\d+)\.(\d+)", v)
    if not m:
        raise ValueError("Formato de versao invalido: {}".format(v))
    nums = tuple(int(x) for x in m.groups())
    return nums[:3], nums[3:]  # (core_tuple, src_tuple)


main()

