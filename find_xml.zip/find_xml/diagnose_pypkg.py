# -*- coding: utf-8 -*-
"""
Diagnostico: descobre onde o modulo 'old_helper' (e outros usados por FixingCstatCupons -
msgbus, bustoken, cfgtools) realmente esta dentro dos pacotes .pypkg da instalacao e-deploy.

Os arquivos .pypkg sao lidos como zip (o Python importa deles via zipimport mesmo sem eles
terem extensao .zip), entao este script abre cada .pypkg encontrado na pasta bin/ e procura
os modulos de interesse dentro dele, sem precisar importar nada (evita side-effects de
conectar no barramento e-deploy).

Uso (rodar com o mesmo python3 que roda o main.py):
    C:\\edeploy-pos-structure\\python3\\python.exe diagnose_pypkg.py
    (ajuste o caminho do python3.exe e do BIN_DIR abaixo se a instalacao for outra)
"""
import os
import sys
import zipfile

# Ajuste aqui se a instalacao dessa loja nao for edeploy-pos-structure.
CANDIDATOS_APP_PATH = [
    r"C:\mwpos",
    r"C:\edeployPOS",
    r"C:\edeploy-pos-structure",
]

MODULOS_PROCURADOS = ["old_helper", "msgbus", "bustoken", "cfgtools", "mbcontextmessagehandler", "order_api"]


def encontrar_app_path():
    for candidato in CANDIDATOS_APP_PATH:
        if os.path.exists(candidato):
            return candidato
    return None


def listar_pypkg(bin_dir):
    if not os.path.isdir(bin_dir):
        print("Pasta bin nao encontrada: {}".format(bin_dir))
        return []
    return [f for f in os.listdir(bin_dir) if f.lower().endswith(".pypkg")]


def procurar_modulos_no_pypkg(caminho_pypkg, modulos):
    encontrados = {}
    try:
        with zipfile.ZipFile(caminho_pypkg) as z:
            nomes = z.namelist()
    except zipfile.BadZipFile:
        print("  [AVISO] {} nao e um zip valido (pode ser outro formato) - pulando".format(
            os.path.basename(caminho_pypkg)))
        return encontrados
    except Exception as ex:
        print("  [ERRO] Falha ao abrir {}: {}".format(os.path.basename(caminho_pypkg), ex))
        return encontrados

    for modulo in modulos:
        # modulo pode aparecer como "modulo.py", "modulo.pyc", ou "modulo/__init__.py" (pacote)
        hits = [n for n in nomes if n in (
            "{}.py".format(modulo), "{}.pyc".format(modulo), "{}/__init__.py".format(modulo)
        ) or n.endswith("/{}.py".format(modulo)) or n.endswith("/{}.pyc".format(modulo))]
        if hits:
            encontrados[modulo] = hits
    return encontrados


def main():
    app_path = encontrar_app_path()
    if not app_path:
        print("Nenhuma instalacao reconhecida encontrada em: {}".format(CANDIDATOS_APP_PATH))
        sys.exit(1)

    bin_dir = os.path.join(app_path, "bin")
    print("Instalacao detectada: {}".format(app_path))
    print("Pasta bin: {}".format(bin_dir))
    print("")

    pypkgs = listar_pypkg(bin_dir)
    if not pypkgs:
        print("Nenhum arquivo .pypkg encontrado em {}".format(bin_dir))
        sys.exit(1)

    print("Arquivos .pypkg encontrados: {}".format(", ".join(pypkgs)))
    print("")

    resumo = {m: [] for m in MODULOS_PROCURADOS}

    for pypkg in pypkgs:
        caminho = os.path.join(bin_dir, pypkg)
        print("Verificando {} ...".format(pypkg))
        encontrados = procurar_modulos_no_pypkg(caminho, MODULOS_PROCURADOS)
        if encontrados:
            for modulo, hits in encontrados.items():
                print("  OK - {} encontrado: {}".format(modulo, hits))
                resumo[modulo].append(pypkg)
        else:
            print("  (nenhum dos modulos procurados esta aqui)")
        print("")

    print("=" * 70)
    print("RESUMO")
    print("=" * 70)
    for modulo in MODULOS_PROCURADOS:
        onde = resumo[modulo]
        if onde:
            print("{:28s} -> {}".format(modulo, ", ".join(onde)))
        else:
            print("{:28s} -> NAO ENCONTRADO em nenhum .pypkg de {}".format(modulo, bin_dir))


if __name__ == "__main__":
    main()
