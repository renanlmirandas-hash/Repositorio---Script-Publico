C:\edeploypos\python\python.exe fix_protocolo_cupons.py --order-ids 
pause