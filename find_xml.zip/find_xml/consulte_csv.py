# -*- coding: utf-8 -*-
import base64
import logging
import sqlite3
import os
import platform
import shutil
import time
from datetime import datetime, timedelta
import xml.etree.ElementTree as ET
from sqlite_update import *
from fix_apply import *
from decode_base64 import *
from time_hora import *
from order_picture import *
from fix_protocolo_cupons import FixingCstatCupons

# Conexão com o SDK do e-deploy (msgbus/cfgtools) é reaproveitada durante toda a execução do
# main.py em vez de ser reaberta a cada venda em contingência - ver _obter_fixing_cstat_cupons().
_fixing_cstat_cupons = None
_fixing_cstat_cupons_indisponivel = False


def _obter_fixing_cstat_cupons():
    """
    Retorna uma instância única de FixingCstatCupons, reaproveitada durante toda a execução do
    main.py, para evitar reabrir a conexão com o barramento (MBEasyContext) a cada venda em
    contingência.

    Se o ambiente não for NFCE (loader_NFCE.cfg ausente - FixingCstatCupons faz sys.exit(1)
    nesse caso) ou a conexão com o SDK do e-deploy falhar por qualquer outro motivo, marca como
    indisponível e não tenta de novo pelo resto desta execução.
    """
    global _fixing_cstat_cupons, _fixing_cstat_cupons_indisponivel

    if _fixing_cstat_cupons_indisponivel:
        return None
    if _fixing_cstat_cupons is not None:
        return _fixing_cstat_cupons

    cwd_original = os.getcwd()
    try:
        # Usa o mesmo caminho de instalação que o main.py já detecta pra tudo mais (acesso_fiscal,
        # path_orders, etc.), em vez do get_application_path() fixo que a classe tinha antes -
        # aquele só reconhecia "C:/edeployPOS"/"/home/administrador/edeployPOS" e ficava errado em
        # instalações mwpos ou edeploy-pos-structure.
        app_path = get_system_version()
        _fixing_cstat_cupons = FixingCstatCupons(app_path)
        return _fixing_cstat_cupons
    except SystemExit:
        # FixingCstatCupons.__init__ faz sys.exit(1) quando o ambiente não é NFCE.
        logging.info("Ambiente não é NFCE - correção de protocolo (FixingCstatCupons) indisponível nesta execução")
    except Exception as ex:
        logging.info("Não foi possível conectar ao FixingCstatCupons para correção de protocolo: {}".format(ex))
    finally:
        os.chdir(cwd_original)

    _fixing_cstat_cupons_indisponivel = True
    return None


def _tentar_corrigir_protocolo_cupom(order_id):
    """
    Tenta corrigir o protocolo da nota via FixingCstatCupons.find_key_pattern quando a venda
    está em contingência (status "Problemas de conexao com a SEFAZ" ou "Notas anteriores em
    contingencia"). find_key_pattern procura nos logs do FiscalWrapper um cStat já resolvido
    para esse orderid e, se encontrar, corrige o protocolo sozinho (fix_cstat).

    Retorna True se a correção foi aplicada, False se não havia nada para corrigir ou se a
    correção não está disponível neste ambiente/execução.
    """
    fixer = _obter_fixing_cstat_cupons()
    if fixer is None:
        return False

    try:
        return bool(fixer.find_key_pattern(order_id))
    except Exception as ex:
        logging.info("Erro ao tentar corrigir protocolo (FixingCstatCupons) para orderid {}: {}".format(order_id, ex))
        return False


def ler_arquivo_csv(caminho_arquivo):
    dados = []
    with open(caminho_arquivo, 'r') as arquivo_csv:
        leitor_csv = arquivo_csv.readlines()
        for linha in leitor_csv:
            dados.append(linha)
    return dados

def get_system_version():
    if is_that_system_windows() and os.path.exists(r"C:\mwpos"):
        return r"C:\mwpos"
    elif is_that_system_windows() and os.path.exists(r"C:\edeployPOS"):
        return r"C:\edeployPOS"
    elif is_that_system_windows() and os.path.exists(r"C:\edeploy-pos-structure"):
        return r"C:\edeploy-pos-structure"
    elif not is_that_system_windows() and os.path.exists("/home/administrador/edeployPOS"):
        return "/home/administrador/edeployPOS"
    else:
        return r"/home/administrador/mwpos_server"

def is_that_system_windows():
    return platform.system().lower() == "windows"


def mover_arquvi_xml(diretorio, local):
    arquivo_diretorio_fiscalrepository = (
        "{}/fiscalrepository.py".format(diretorio))
    arquivo_local_fiscalrepository = ("{}/fiscalrepository.py".format(local))
    shutil.copy(arquivo_diretorio_fiscalrepository,
                arquivo_local_fiscalrepository)

def open_store_cfg(caminho_bkoffice):
    codido_centro = "{}".format(caminho_bkoffice)
    tree = ET.parse(codido_centro)
    root = tree.getroot()
    persistcomp_normal = root.find(".//key[@name='Id']/string").text
    return str(persistcomp_normal)

def file_valor_sentto(file_csv):
    valida_dic = []
    for file in file_csv:
        file_csv_le = file.replace("\n", "").split(";")
        file_valida = {
            "numeronota": file_csv_le[0]
        }
        valida_dic.append(file_valida)
    return valida_dic




def time_direction(venda, order_id, file_connect, nota, posid, fiscal_banco):
    void_time = None
    paid_time = None
    state_id_paid = None
    state_id_void = None
    no_ident_status = None
    type_posid = None
    state_recalled = None
    if posid == 0:
        type_posid = "Delivery"
    for order in venda:
        time_order = order.get("Timestamp")
        status_order = int(order.get("status_order"))
        date = datetime.strptime(time_order, "%Y-%m-%dT%H:%M:%S.%f")
        no_ident_status = status_order
        if status_order == 4:
            void_time = date
            state_id_void = status_order
        elif status_order == 5:
            paid_time = date
            state_id_paid = status_order
        elif status_order == 6:
            state_recalled = status_order
    if state_recalled:
        return 6

    if void_time and paid_time and state_id_void == 4 and state_id_paid == 5:
        #diferenca = paid_time - void_time
        minutos = abs((paid_time - void_time).total_seconds() / 60)
        if minutos >= 30:
            logging.info(
                "Cancelada após 30: Order:{}, Nota:{}, Dia:{}, Tempo:{}, Pos:{}".format(order_id, nota, date,
                                                                                                  minutos, type_posid,                                                                                                  ))
            updater_aped_20805(file_connect, order_id, nota, "cancelada")
            return
        else:
            updater_aped_20805(file_connect, order_id, nota)
            return
    if state_id_paid is not None and state_id_void is None:
        time.sleep(7)
        sale_custom = orders_customproperties(file_connect, order_id)
        order_disabled = False
        xml_fiscal_disabled = None
        for sale in sale_custom:
            if sale.get("key") == "FISCAL_XML":
                base = sale.get("value")
                decoder = DecodeBase64(base)
                status = decoder.decode()
                if status in ("100", "150"):
                    logging.info("Validar cstat no fiscal_persistcomp".format(order_id, status))
                    xml_request = validate_status(fiscal_banco, order_id)
                    decoder_xml = DecodeBase64(xml_request[0])
                    status_xml = decoder_xml.decode()
                    if status != status_xml:
                        logging.info(
                            "Order:{}, Nota:{}, Cstat: {} | Fiscal Status_xml:{} Atualizando informações no fiscal".format(
                                order_id, nota, status, status_xml))
                        update_xml_APED23848(fiscal_banco, base, order_id, 1, nota)
                        logging.info(
                            "Nota em contigencia , vamos alterar o status no banco {}, {}".format(order_id, nota)
                        )
                        return 5
                    else:
                        logging.info("Venda possui o mesmo status entre fiscal/order {}, {}".format(order_id, nota))
                        return 5
                if status in ("Problemas de conexao com a SEFAZ", "Notas anteriores em contingencia"):
                    protocolo_corrigido = _tentar_corrigir_protocolo_cupom(order_id)
                    if protocolo_corrigido:
                        logging.info(
                            "Protocolo corrigido via FixingCstatCupons - orderid {}, nota {}".format(order_id, nota))
                    sale_order_picture = 1 #rder_picture.encode()
                    date_time = order.get("Timestamp").replace("T", " ")
                    date_fiscal = datetime_to_float(date_time)
                    validate_sale = FiscalData(fiscal_banco, posid, order_id, base, nota, sale_order_picture, date_fiscal)
                    insert_fiscal = validate_sale.sales_inquiry()
                    if insert_fiscal:
                        update_xml_APED23848(fiscal_banco, base, order_id, 0, nota)
                        logging.info(
                            "Nota em contigencia , vamos alterar o status no banco {}, {}".format(order_id, nota))
                        return
                    else:
                        validate_sale.insert_fiscal_faltante()
                        return


        if order_disabled and xml_fiscal_disabled is not None:
            xml_encoded = base64.b64decode(xml_fiscal_disabled)
            ns = {"nfe": "http://www.portalfiscal.inf.br/nfe"}
            root = ET.fromstring(xml_encoded)
            cstat = root.find(".//nfe:cStat", ns)
            if cstat.text in ('206', '256', '102'):
                logging.info("Inutizada incorretamente {} APED-23983 nota:{}".format(order_id, nota))
                fiscal = seq_fiscal(fiscal_banco)
                seq = fiscal[0]["fiscal_id"]
                seq += 1
                seq_update(fiscal_banco, seq)
                update_fiscal_order(file_connect, order_id, seq)
                update_xml_APED23848(fiscal_banco, xml_fiscal_disabled, order_id, 555, seq)
                return
            else:
                logging.info("Não identificado inutilização {}, {}".format(order_id, nota))


    if state_id_void and state_id_paid is None:
        sale_custom = orders_customproperties(file_connect, order_id)
        cstat = None
        order_disabled = None
        for sale in sale_custom:
            if sale.get("key") == "DISABLED_FISCAL_XML":
                base = sale.get("value")
                decoder = DecodeBase64(base)
                status = decoder.decode()
                cstat = status
                break
            if sale.get("key") == "ORDER_DISABLED":
                order_disabled = sale.get("value")
        if cstat == "563":
            logging.info(
                "Order foi Void sem status de paid {}, {}, cstat {} : APED-20811 - Erro 563 ".format(order_id, nota,                                                                                                         cstat))
            return
        elif cstat == "102":
                logging.info("Order foi Void sem status de paid {}, {}, cstat {}".format(order_id, nota, cstat))
                return
        elif order_disabled is not  None:
            logging.info("Order foi Void sem status de paid {}, {}, ORDER_DISABLED {} possivel quebra de sequencia".format(order_id, nota, order_disabled))
            return
        else:
            logging.info(
                "Não existe tratamendo ainda, status atual da venda {}, order {} ".format(no_ident_status,
                                                                                             order_id,                                                                                             sale.get("key")))
            return

    elif state_id_paid is None and state_id_void is None:
        updated_state = consulte_orderid(file_connect, order_id)
        for updated in updated_state:
            no_ident_status = updated.get("status_order")
            type_venda = updated.get("ordersubtype")
            if no_ident_status == 2:
                logging.info("Venda com o status {}, {}, {} ".format(no_ident_status, order_id, type_venda))
            elif no_ident_status == 6:
                break
    else:
        if state_id_paid is None and state_id_void is None:
            logging.info("Não existe tratamendo ainda, status atual da venda {}, order {}".format(no_ident_status, order_id))
