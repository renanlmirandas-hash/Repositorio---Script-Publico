import os
import logging
import sqlite3

from alembic import command
from alembic.config import Config
from sqlalchemy import create_engine
from sqlalchemy import inspect as sa_inspect
from sqlalchemy import text
from sqlalchemy.engine import Engine

logger = logging.getLogger("FiscalWrapper")

_SQLITE_BUSY_TIMEOUT_SECONDS = 15.0

PSELECT_QUERIES = {
    "fiscal_getNfceToSendCount": (
        "SELECT COUNT(*) "
        "FROM FiscalData "
        "WHERE SentToNfce = 0 "
        "AND InvoiceType = 'NFCE'"
    ),
    "fiscal_getRequestXMLFiscalData": (
        "SELECT XMLRequest "
        "FROM FiscalData "
        "WHERE OrderId = :order_id"
    ),
    "fiscal_getResponseXMLFiscalData": (
        "SELECT XMLResponse "
        "FROM FiscalData "
        "WHERE OrderId = :order_id"
    ),
    "fiscal_getSatNumberAndRequestXMLFiscalData": (
        "SELECT NumeroSat, XMLRequest "
        "FROM FiscalData "
        "WHERE OrderId = :order_id"
    ),
    "fiscal_getNfceToSend": (
        "SELECT OrderId, PosId, XmlRequest, NumeroNota, OrderPicture, TransmittedXMLRequest "
        "FROM FiscalData "
        "WHERE SentToNfce = 0 "
        "LIMIT CAST(:limit AS integer)"
    ),
}

PQUERY_QUERIES = {
    "fiscal_setOrderPicture": (
        "UPDATE FiscalData "
        "SET OrderPicture = :order_picture "
        "WHERE OrderId = :order_id"
    ),
    "fiscal_setOrderCanceled": (
        "UPDATE FiscalData "
        "SET SentToNfce = -1 "
        "WHERE OrderId = :order_id"
    ),
    "fiscal_saveFiscalData": (
        "INSERT INTO FiscalData ("
        " PosId, OrderId, DataNota, NumeroNota, NumeroSat, "
        " XMLRequest, SentToNfce, XMLResponse, InvoiceType, TransmittedXMLRequest"
        ") VALUES ("
        " :pos_id, :order_id, :data_nota, :numero_nota, :numero_sat, "
        " :xml_request, :sent_to_nfce, :xml_response, :invoice_type, :transmitted_xml"
        ")"
    ),
    "fiscal_setNfceSent": (
        "UPDATE FiscalData "
        "SET SentToNfce = :status "
        "WHERE OrderId = :order_id"
    ),
    "fiscal_setXmlResponse": (
        "UPDATE FiscalData "
        "SET XMLResponse = :xml_response "
        "WHERE OrderId = :order_id"
    ),
    "fiscal_setNfceSentXml": (
        "UPDATE FiscalData "
        "SET SentToNfce = :status, "
        "    XMLRequest = :xml_request "
        "WHERE OrderId = :order_id"
    ),
    "fiscal_retryFiscalOrdersWithException": (
        "UPDATE FiscalData "
        "SET SentToNfce = 0 "
        "WHERE SentToNfce = -1 "
        "AND InvoiceType = 'NFCE' "
        "AND DataNota >= strftime('%s', 'now', :range_of_days)"
    ),
}


class CursorIterator(object):

    def __init__(
        self,
        cursor
    ):
        # type: (sqlite3.Cursor) -> None
        self._cursor = cursor
        self._rows = cursor.fetchall()
        self._index = 0
        description = cursor.description
        self._col_names = {description[i][0]: i for i in range(len(description))}

    def __iter__(self):
        # type: () -> CursorIterator
        return self

    def next(self):
        # type: () -> Row
        if self._index >= len(self._rows):
            raise StopIteration
        row = self._rows[self._index]
        self._index += 1
        return Row(row=row, col_names=self._col_names)

    __next__ = next

    def rows(self):
        # type: () -> int
        return len(self._rows)

    def get_row(
        self,
        idx
    ):
        # type: (int) -> Row
        return Row(row=self._rows[idx], col_names=self._col_names)


class Row(object):

    def __init__(
        self,
        row,
        col_names
    ):
        # type: (tuple, dict) -> None
        self.items = row
        self.col_names = col_names

    def get_entry(
        self,
        column
    ):
        # type: (object) -> object
        if isinstance(column, str):
            column = self.col_names[column]

        value = self.items[column]

        if value is None:
            return None

        if isinstance(value, bytes):
            return value.decode("utf-8")

        if isinstance(value, str):
            return value

        try:
            return unicode(value)
        except Exception:
            return unicode(value, 'utf-8', 'ignore')


class Connection(object):

    def __init__(
        self,
        conn_string
    ):
        # type: (str) -> None
        self.conn = sqlite3.connect(
            database=conn_string,
            timeout=_SQLITE_BUSY_TIMEOUT_SECONDS,
        )

    def query(
        self,
        sql
    ):
        # type: (str) -> int
        cursor = self.conn.cursor()
        cursor.execute(sql)
        self.conn.commit()
        return cursor.rowcount

    def pselect(
        self,
        procname,
        **params
    ):
        # type: (str, **dict) -> CursorIterator
        sql = PSELECT_QUERIES.get(procname)
        if sql is None:
            raise NotImplementedError("pselect procedure '{}' not mapped".format(procname))
        cursor = self.conn.cursor()
        cursor.execute(sql, params)
        return CursorIterator(cursor=cursor)

    def pquery(
        self,
        procname,
        **params
    ):
        # type: (str, **dict) -> int
        sql = PQUERY_QUERIES.get(procname)
        if not sql:
            raise RuntimeError("Unknown pquery: %s" % procname)
        cursor = self.conn.cursor()
        cursor.execute(sql, params)
        self.conn.commit()
        return cursor.rowcount

    def select(
        self,
        sql
    ):
        # type: (str) -> CursorIterator
        cursor = self.conn.cursor()
        cursor.execute(sql)
        return CursorIterator(cursor=cursor)

    def select_params(
        self,
        sql,
        params
    ):
        # type: (str, tuple) -> CursorIterator
        cursor = self.conn.cursor()
        cursor.execute(sql, params)
        return CursorIterator(cursor=cursor)

    def executescript(
        self,
        script
    ):
        # type: (str) -> None
        self.conn.executescript(script)

    def close(self):
        # type: () -> None
        self.conn.close()


class Driver(object):
    base_path = "../data/server/databases/"
    conn_string = None

    @staticmethod
    def open(dbname=None):
        # type: (str) -> Connection
        if Driver.base_path is None:
            raise RuntimeError("Driver.base_path must be configured before open()")

        if dbname:
            conn_string = os.path.join(Driver.base_path, dbname)
        else:
            conn_string = os.path.join(Driver.base_path, "fiscal_persistcomp.db")

        return Connection(conn_string=conn_string)


_FISCAL_DATA_COLUMNS = [
    ("NextDateToSend", "VARCHAR"),
    ("SentToNfce", "INTEGER DEFAULT 0"),
    ("NextDateToSendToBKC", "VARCHAR"),
    ("OrderPicture", "VARCHAR NOT NULL DEFAULT '1'"),
    ("DataNota", "VARCHAR NOT NULL DEFAULT '1'"),
    ("XMLResponse", "VARCHAR"),
    ("InvoiceType", "VARCHAR NOT NULL DEFAULT 'NFCE'"),
    ("TransmittedXMLRequest", "VARCHAR"),
]


def _repair_missing_columns(
    engine,    # type: Engine
):
    # type: (...) -> None

    inspector = sa_inspect(engine)
    existing = {col["name"] for col in inspector.get_columns("FiscalData")}
    missing = [(col, defn) for col, defn in _FISCAL_DATA_COLUMNS if col not in existing]

    if not missing:
        return

    with engine.connect() as conn:
        for col_name, col_def in missing:
            conn.execute(
                text("ALTER TABLE FiscalData ADD COLUMN {} {}".format(col_name, col_def)),
            )


def run_migrations(
    db_path,    # type: str
):
    # type: (...) -> None

    try:
        alembic_dir = os.path.join(os.path.dirname(__file__), "..", "..", "alembic")
        alembic_ini = os.path.join(alembic_dir, "alembic.ini")
        cfg = Config(alembic_ini)
        cfg.set_main_option(
            "script_location",
            alembic_dir,
        )

        engine = create_engine(
            "sqlite:///{}".format(db_path),
            connect_args={"timeout": _SQLITE_BUSY_TIMEOUT_SECONDS},
        )
        with engine.connect() as conn:
            existing_tables = {
                row[0]
                for row in conn.execute(
                    text("SELECT name FROM sqlite_master WHERE type='table'"),
                )
            }
            fiscal_data_exists = "FiscalData" in existing_tables
            recorded_revision = None
            if "alembic_version" in existing_tables:
                version_row = conn.execute(
                    text("SELECT version_num FROM alembic_version"),
                ).fetchone()
                recorded_revision = version_row[0] if version_row else None

            cfg.attributes["connection"] = conn
            needs_stamp = fiscal_data_exists and recorded_revision is None
            if needs_stamp:
                command.stamp(
                    cfg,
                    "head",
                )
            else:
                command.upgrade(
                    cfg,
                    "head",
                )

        _repair_missing_columns(engine=engine)
    except Exception as ex:
        logger.error("run_migrations failed: {}".format(ex))
        raise
