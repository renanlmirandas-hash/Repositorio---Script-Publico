# -*- coding: utf-8 -*-
"""
fiscal_reprocessa_nfeproc.py
-----------------------------------------------------------------------------
Script (Python 2.7) para reconstruir o XML "nfeProc" completo de uma nota
ja autorizada, a partir de:

  1) XML da venda (em base64) armazenado no banco fiscal_persistcomp.db
  2) Chave de acesso (chNFe) e cStat lidos nos logs do fiscalwrapper, no
     padrao:  "Order 000832487: chave autorizada <44 digitos> retornou cStat 100"

O script:
  - Le o XML de venda (base64) referente ao numero da nota.
  - Varre o diretorio de logs do fiscalwrapper procurando a linha da nota,
    extrai a chave de acesso e confirma que cStat == 100 (autorizado).
  - Extrai <dhEmi> do proprio XML da nota (usado tambem como <dhRecbto>).
  - Monta o envelope <nfeProc><NFe>...</NFe><protNFe>...</protNFe></nfeProc>
  - Grava um backup .xml local (auditoria) e regrava o resultado (em base64)
    de volta na tabela do fiscal_persistcomp.db.

-----------------------------------------------------------------------------
IMPORTANTE - CONFIGURACAO
Nao tenho como inspecionar o fiscal_persistcomp.db real deste computador,
entao os nomes de tabela/coluna abaixo sao um "melhor palpite" e devem ser
confirmados. Use antes:

    python fiscal_reprocessa_nfeproc.py --list-tables
    python fiscal_reprocessa_nfeproc.py --describe-table NOME_DA_TABELA

para descobrir os nomes reais e ajustar as constantes CONFIG abaixo (ou
passar via linha de comando com --table/--col-nota/--col-xml).
-----------------------------------------------------------------------------
"""

import argparse
import base64
import glob
import os
import re
import sqlite3
import sys


# ============================================================================
# CONFIG - ajuste conforme o ambiente. Tudo aqui pode ser sobrescrito via CLI.
# ============================================================================

# Caminho do banco sqlite do fiscal_persistcomp (informado pelo usuario).
DB_PATH = r"C:\edeployPOS\data\server\databases\fiscal_persistcomp.db"

# Confirmado com --list-tables / --describe-table.
TABLE_NAME = "fiscaldata"
COLUMN_NOTA = "orderid"
COLUMN_XML_BASE64 = "xmlrequest"

# Diretorio onde ficam os logs do fiscalwrapper (com rotacao / multiplos
# arquivos).
LOG_DIR = r"C:\edeployPOS\data\server\bundles\fiscalwrapper"
LOG_GLOB_PATTERNS = ["*.log", "*.log.*", "*.txt"]

# Pasta local (relativa a este script) onde salvamos uma copia de auditoria
# do XML final antes/depois de gravar no banco.
OUTPUT_DIR = "output_nfeproc"

# Dados fixos do protocolo (o downstream nao valida assinatura/protocolo
# real da SEFAZ, conforme informado; digVal e um valor fixo aceito pelo
# sistema).
TP_AMB = "1"
VER_APLIC = "GO4.0"
DIG_VAL_FIXO = "JtDmTrpJaFd63g719gwUPhlWtKM="
CSTAT_PROTOCOLO = "204"
X_MOTIVO_PROTOCOLO = "Autorizado o uso da NF-e"
VERSAO_LAYOUT = "4.00"
NFE_NAMESPACE = "http://www.portalfiscal.inf.br/nfe"

# Regex da linha de log do fiscalwrapper.
#   Order 000832487: chave autorizada 52260817261661005566650010002291321208295241 retornou cStat 100
LOG_LINE_RE_TEMPLATE = (
    r"Order\s+0*{numero}\b\s*:\s*chave\s+autorizada\s+(?P<chave>\d{{44}})"
    r"\s+retornou\s+cStat\s+(?P<cstat>\d+)"
)


# ============================================================================
# Banco de dados (fiscal_persistcomp.db - SQLite)
# ============================================================================

def conectar_db(db_path):
    if not os.path.isfile(db_path):
        raise IOError("Banco nao encontrado em: %s" % db_path)
    return sqlite3.connect(db_path)


def listar_tabelas(db_path):
    conn = conectar_db(db_path)
    try:
        cur = conn.cursor()
        cur.execute("SELECT name FROM sqlite_master WHERE type='table' ORDER BY name")
        return [row[0] for row in cur.fetchall()]
    finally:
        conn.close()


def descrever_tabela(db_path, table_name):
    conn = conectar_db(db_path)
    try:
        cur = conn.cursor()
        cur.execute("PRAGMA table_info(%s)" % table_name)
        # cid, name, type, notnull, dflt_value, pk
        return cur.fetchall()
    finally:
        conn.close()


def buscar_xml_base64(db_path, table_name, col_nota, col_xml, numero_nota):
    conn = conectar_db(db_path)
    try:
        cur = conn.cursor()
        sql = "SELECT %s FROM %s WHERE %s = ?" % (col_xml, table_name, col_nota)
        cur.execute(sql, (numero_nota,))
        row = cur.fetchone()
        if row is None:
            # tenta casar tambem como texto (numero pode estar armazenado
            # como string, com ou sem zeros a esquerda)
            cur.execute(sql, (str(numero_nota),))
            row = cur.fetchone()
        if row is None:
            raise LookupError(
                "Nenhum registro encontrado em %s.%s para %s = %r"
                % (table_name, col_xml, col_nota, numero_nota)
            )
        return row[0]
    finally:
        conn.close()


def gravar_xml_final(db_path, table_name, col_nota, col_xml, numero_nota, xml_base64_final):
    conn = conectar_db(db_path)
    try:
        cur = conn.cursor()
        sql = "UPDATE %s SET %s = ? WHERE %s = ?" % (table_name, col_xml, col_nota)
        cur.execute(sql, (xml_base64_final, numero_nota))
        if cur.rowcount == 0:
            # tenta casar como string, mesmo motivo do SELECT acima
            cur.execute(sql, (xml_base64_final, str(numero_nota)))
        conn.commit()
        return cur.rowcount
    finally:
        conn.close()


# ============================================================================
# Log do fiscalwrapper
# ============================================================================

def _listar_arquivos_log(log_dir, patterns):
    arquivos = []
    for pattern in patterns:
        arquivos.extend(glob.glob(os.path.join(log_dir, pattern)))
    # ordena por data de modificacao (mais antigo -> mais novo), para que,
    # havendo mais de uma ocorrencia da mesma nota, a ultima encontrada seja
    # a mais recente cronologicamente.
    arquivos.sort(key=lambda caminho: os.path.getmtime(caminho))
    return arquivos


def _ler_arquivo_tolerante(caminho):
    with open(caminho, "rb") as f:
        conteudo = f.read()
    try:
        return conteudo.decode("utf-8")
    except UnicodeDecodeError:
        return conteudo.decode("latin-1")


def buscar_chave_no_log(log_dir, numero_nota, exigir_cstat_100=True):
    """
    Varre os arquivos de log em log_dir procurando a linha da nota.
    Retorna (chave, cstat) da ULTIMA ocorrencia com cStat 100 encontrada
    (arquivos mais recentes tem prioridade). Lanca erro se nao encontrar
    nenhuma ocorrencia, ou se so houver ocorrencias com cStat != 100 e
    exigir_cstat_100=True.
    """
    if not os.path.isdir(log_dir):
        raise IOError("Diretorio de log nao encontrado: %s" % log_dir)

    padrao = re.compile(
        LOG_LINE_RE_TEMPLATE.format(numero=int(numero_nota)),
        re.IGNORECASE,
    )

    arquivos = _listar_arquivos_log(log_dir, LOG_GLOB_PATTERNS)
    if not arquivos:
        raise IOError(
            "Nenhum arquivo de log encontrado em %s (padroes: %s)"
            % (log_dir, LOG_GLOB_PATTERNS)
        )

    ocorrencias = []  # lista de (arquivo, chave, cstat), em ordem cronologica
    for caminho in arquivos:
        try:
            texto = _ler_arquivo_tolerante(caminho)
        except (IOError, OSError):
            continue
        for match in padrao.finditer(texto):
            ocorrencias.append((caminho, match.group("chave"), match.group("cstat")))

    if not ocorrencias:
        raise LookupError(
            "Nao encontrei nenhuma linha para a nota %s nos logs de %s"
            % (numero_nota, log_dir)
        )

    autorizadas = [o for o in ocorrencias if o[2] == "100"]
    if autorizadas:
        arquivo, chave, cstat = autorizadas[-1]
        return chave, cstat, arquivo

    if exigir_cstat_100:
        outros = ", ".join("cStat=%s (%s)" % (o[2], os.path.basename(o[0])) for o in ocorrencias)
        raise LookupError(
            "Encontrei a nota %s no log, mas nenhuma ocorrencia com cStat 100 "
            "(autorizada). Ocorrencias encontradas: %s" % (numero_nota, outros)
        )

    arquivo, chave, cstat = ocorrencias[-1]
    return chave, cstat, arquivo


# ============================================================================
# Montagem do XML nfeProc
# ============================================================================

XML_DECL_RE = re.compile(r"^\s*<\?xml[^>]*\?>\s*", re.IGNORECASE)
DH_EMI_RE = re.compile(r"<dhEmi>(.*?)</dhEmi>", re.IGNORECASE)
# Detecta se o conteudo ja comeca com a tag <NFe ...> (com ou sem
# xmlns/versao) - nesse caso ele JA inclui a tag <NFe>...</NFe> em volta do
# infNFe, e nao devemos adicionar outra por fora (senao fica <NFe><NFe>...).
JA_TEM_TAG_NFE_RE = re.compile(r"^\s*<NFe(\s|>)", re.IGNORECASE)


def extrair_dh_emi(xml_texto):
    m = DH_EMI_RE.search(xml_texto)
    if not m:
        raise LookupError("Nao encontrei <dhEmi> dentro do XML da nota.")
    return m.group(1).strip()


def montar_nfe_proc(xml_venda_texto, chave, dh_emi=None):
    """
    Recebe o XML da venda (o conteudo original, sem o envelope
    nfeProc/protNFe) e devolve o documento nfeProc completo, como string.

    O conteudo original pode vir de duas formas, dependendo de como foi
    persistido:
      a) ja com a tag <NFe xmlns="...">...<infNFe>...</infNFe></NFe> -
         nesse caso NAO adicionamos outra <NFe> por fora (evita ficar
         <NFe><NFe>...</NFe></NFe>);
      b) so com <infNFe>...</infNFe> (sem o <NFe> em volta) - nesse caso
         adicionamos a tag <NFe> por fora, como no exemplo original.
    """
    # remove declaracao <?xml ...?> do meio do documento, se houver -
    # ela so pode aparecer uma vez, no topo do documento final.
    conteudo = XML_DECL_RE.sub("", xml_venda_texto).strip()

    if dh_emi is None:
        dh_emi = extrair_dh_emi(conteudo)

    n_prot = chave[-15:]

    prot_nfe = (
        "<protNFe versao=\"%s\">"
        "<infProt>"
        "<tpAmb>%s</tpAmb>"
        "<verAplic>%s</verAplic>"
        "<chNFe>%s</chNFe>"
        "<dhRecbto>%s</dhRecbto>"
        "<nProt>%s</nProt>"
        "<digVal>%s</digVal>"
        "<cStat>%s</cStat>"
        "<xMotivo>%s</xMotivo>"
        "</infProt>"
        "</protNFe>"
    ) % (
        VERSAO_LAYOUT,
        TP_AMB,
        VER_APLIC,
        chave,
        dh_emi,
        n_prot,
        DIG_VAL_FIXO,
        CSTAT_PROTOCOLO,
        X_MOTIVO_PROTOCOLO,
    )

    if JA_TEM_TAG_NFE_RE.match(conteudo):
        # conteudo ja e <NFe ...>...</NFe> completo - so envolve com nfeProc.
        doc = (
            "<?xml version=\"1.0\" encoding=\"UTF-8\"?>"
            "<nfeProc xmlns=\"%s\" versao=\"%s\">"
            "%s"
            "%s"
            "</nfeProc>"
        ) % (NFE_NAMESPACE, VERSAO_LAYOUT, conteudo, prot_nfe)
    else:
        # conteudo e so <infNFe>...</infNFe> (e talvez <Signature>) - precisa
        # adicionar a tag <NFe> por fora.
        doc = (
            "<?xml version=\"1.0\" encoding=\"UTF-8\"?>"
            "<nfeProc xmlns=\"%s\" versao=\"%s\">"
            "<NFe xmlns=\"%s\">"
            "%s"
            "</NFe>"
            "%s"
            "</nfeProc>"
        ) % (NFE_NAMESPACE, VERSAO_LAYOUT, NFE_NAMESPACE, conteudo, prot_nfe)

    return doc


# ============================================================================
# Orquestracao principal
# ============================================================================

def processar_nota(numero_nota, args):
    print("=== Nota %s ===" % numero_nota)

    print("1) Buscando XML de venda em %s (tabela %s)..." % (args.db, args.table))
    xml_b64_original = buscar_xml_base64(
        args.db, args.table, args.col_nota, args.col_xml, numero_nota
    )
    xml_venda_bytes = base64.b64decode(xml_b64_original)
    xml_venda_texto = xml_venda_bytes.decode("utf-8")
    print("   OK - XML de venda obtido (%d bytes decodificados)." % len(xml_venda_bytes))

    print("2) Procurando chave autorizada nos logs em %s..." % args.log_dir)
    chave, cstat, arquivo_log = buscar_chave_no_log(args.log_dir, numero_nota)
    print("   OK - chave=%s cStat=%s (log: %s)" % (chave, cstat, arquivo_log))

    print("3) Montando XML nfeProc...")
    dh_emi = extrair_dh_emi(xml_venda_texto)
    nfe_proc_texto = montar_nfe_proc(xml_venda_texto, chave, dh_emi=dh_emi)
    print("   OK - dhEmi/dhRecbto=%s nProt=%s" % (dh_emi, chave[-15:]))

    if not os.path.isdir(OUTPUT_DIR):
        os.makedirs(OUTPUT_DIR)
    caminho_backup = os.path.join(OUTPUT_DIR, "%s_%s.xml" % (numero_nota, chave))
    with open(caminho_backup, "wb") as f:
        f.write(nfe_proc_texto.encode("utf-8"))
    print("4) Backup salvo em: %s" % caminho_backup)

    xml_final_b64 = base64.b64encode(nfe_proc_texto.encode("utf-8"))

    if args.dry_run:
        print("5) --dry-run ativo: NAO gravei no banco. Revise o backup acima.")
        return

    linhas_afetadas = gravar_xml_final(
        args.db, args.table, args.col_nota, args.col_xml, numero_nota, xml_final_b64
    )
    if linhas_afetadas:
        print("5) OK - XML final gravado de volta em %s (linhas afetadas: %d)."
              % (args.table, linhas_afetadas))
    else:
        print("5) ATENCAO - UPDATE nao afetou nenhuma linha. Confirme --col-nota "
              "e o valor de numero_nota.")


# ============================================================================
# CLI
# ============================================================================

def montar_parser():
    parser = argparse.ArgumentParser(
        description="Reconstroi o XML nfeProc de uma nota autorizada, a partir "
                     "do fiscal_persistcomp.db e dos logs do fiscalwrapper."
    )
    parser.add_argument("numero_nota", nargs="?", help="Numero da nota/order (ex: 832487 ou 000832487)")
    parser.add_argument("--db", default=DB_PATH, help="Caminho do fiscal_persistcomp.db")
    parser.add_argument("--table", default=TABLE_NAME, help="Nome da tabela")
    parser.add_argument("--col-nota", default=COLUMN_NOTA, help="Coluna do numero da nota")
    parser.add_argument("--col-xml", default=COLUMN_XML_BASE64, help="Coluna do XML em base64")
    parser.add_argument("--log-dir", default=LOG_DIR, help="Diretorio de logs do fiscalwrapper")
    parser.add_argument("--dry-run", action="store_true", help="Nao grava no banco, so gera o backup local")

    parser.add_argument("--list-tables", action="store_true",
                         help="Lista as tabelas existentes em --db e sai")
    parser.add_argument("--describe-table", metavar="NOME",
                         help="Lista as colunas da tabela NOME em --db e sai")
    return parser


def main():
    parser = montar_parser()
    args = parser.parse_args()

    if args.list_tables:
        for nome in listar_tabelas(args.db):
            print(nome)
        return

    if args.describe_table:
        for cid, nome, tipo, notnull, dflt, pk in descrever_tabela(args.db, args.describe_table):
            print("%s\t%s\t%s%s" % (nome, tipo, "PK" if pk else "", " NOT NULL" if notnull else ""))
        return

    if not args.numero_nota:
        parser.error("informe o numero da nota, ou use --list-tables / --describe-table")

    try:
        processar_nota(args.numero_nota, args)
    except (IOError, LookupError, sqlite3.Error) as exc:
        sys.stderr.write("ERRO: %s\n" % exc)
        sys.exit(1)


if __name__ == "__main__":
    main()