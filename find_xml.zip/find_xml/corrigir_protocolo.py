#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""Corrige o protocolo SEFAZ das notas em um intervalo de datas, para ser importado por
outro script Python.

Mesma acao do botao "Corrigir Protocolo SEFAZ" do Menu Suporte do POS (Painel > Corrigir
Protocolo SEFAZ). No POS, esse botao dispara doFixSefazProtocol
(edpscripts/src/posactions.py), que envia o token TK_FISCALWRAPPER_SITUATION para o
componente FiscalWrapper. Quem executa a correcao de verdade e'
NfceProcessor.check_nf_situation (fiscalwrapper/src/nfce.py): ele varre a tabela
FiscalData no intervalo de datas informado, reconsulta a SEFAZ o protocolo das notas
ainda pendentes e atualiza o registro local.

Essa funcao NAO da' pra importar isolada (ela usa uma conexao real com o Message Bus para
falar com outros componentes - FiscalDataRepository chama OrderService via MB - e faz
consulta real a SEFAZ com o certificado da loja). Por isso este script se conecta no
Message Bus como um cliente comum e manda a MESMA mensagem que o POS manda, deixando o
FiscalWrapper (ja rodando no sistema) processar - precisa do HyperVisor ativo.

Uso como modulo (integrando com outro script Python 2.7):
    from corrigir_protocolo import corrigir_protocolo

    sucesso, mensagem = corrigir_protocolo("20260101", "20260104")
    if not sucesso:
        ...

Uso via linha de comando (com o Python 2.7 do projeto):
    python\\python.exe scripts\\corrigir_protocolo.py 20260101 20260104
    python\\python.exe scripts\\corrigir_protocolo.py 20260101 20260104 --application-path C:\\edeployPOS
"""
from __future__ import print_function

import argparse
import datetime
import os
import sys

DEFAULT_APPLICATION_PATH_WINDOWS = r"C:\edeployPOS"
DEFAULT_APPLICATION_PATH_LINUX = "/home/administrador/edeployPOS"

DEFAULT_HVIP = "127.0.0.1"
DEFAULT_HVPORT = "14000"
DEFAULT_HVCOMPPORT = "35689"

# edpcommon/src/bustoken.py: TK_FISCALWRAPPER_SITUATION = create_token(MSGPRT_LOW, "31", "15")
TK_FISCALWRAPPER_SITUATION = 0x03100015

DATE_FORMAT = "%Y%m%d"


def default_application_path():
    if sys.platform == "win32":
        return DEFAULT_APPLICATION_PATH_WINDOWS
    return DEFAULT_APPLICATION_PATH_LINUX


def is_valid_date(value):
    try:
        datetime.datetime.strptime(value, DATE_FORMAT)
        return True
    except ValueError:
        return False


def _setup_msgbus_environment(application_path):
    bin_path = os.path.join(application_path, "bin")
    if not os.path.isdir(bin_path):
        raise IOError(
            "Diretorio bin nao encontrado em {}. Use application_path para indicar a raiz "
            "correta da instalacao (ex: C:\\edeployPOS).".format(bin_path)
        )

    os.environ.setdefault("BINPATH", bin_path)
    os.environ.setdefault("HVIP", DEFAULT_HVIP)
    os.environ.setdefault("HVPORT", DEFAULT_HVPORT)
    os.environ.setdefault("HVCOMPPORT", DEFAULT_HVCOMPPORT)
    os.environ.setdefault("HVPID", "-1")

    if bin_path not in sys.path:
        sys.path.insert(0, bin_path)


def corrigir_protocolo(
    initial_date,                               # type: str
    final_date,                                 # type: str
    application_path=None,                      # type: str
    client_name="corrigir_protocolo_script",    # type: str
    timeout_ms=180 * 1000,                      # type: int
):
    # type: (...) -> (bool, str)

    if not is_valid_date(initial_date) or not is_valid_date(final_date):
        return False, "Datas devem estar no formato AAAAMMDD (ex: 20260101)."

    application_path = application_path or default_application_path()
    _setup_msgbus_environment(application_path)

    from msgbus import FM_PARAM, TK_SYS_ACK, MBEasyContext

    mbcontext = None
    try:
        mbcontext = MBEasyContext(client_name)
        reply = mbcontext.MB_EasySendMessage(
            dest_name="FiscalWrapper",
            token=TK_FISCALWRAPPER_SITUATION,
            format=FM_PARAM,
            data="\0".join([initial_date, final_date]),
            timeout=timeout_ms,
        )
        sucesso = reply.token == TK_SYS_ACK
        mensagem = reply.data or ""
        return sucesso, mensagem
    finally:
        if mbcontext:
            mbcontext.MB_EasyFinalize()


def main():
    parser = argparse.ArgumentParser(
        description=(
            "Corrige o protocolo SEFAZ das notas no intervalo de datas informado - mesma "
            "acao do botao 'Corrigir Protocolo SEFAZ' do Menu Suporte do POS. Precisa do "
            "HyperVisor rodando."
        )
    )
    parser.add_argument("initial_date", help="Data inicial no formato AAAAMMDD")
    parser.add_argument("final_date", help="Data final no formato AAAAMMDD")
    parser.add_argument(
        "--application-path",
        default=None,
        help="Raiz da instalacao do POS (padrao: {})".format(default_application_path()),
    )
    args = parser.parse_args()

    sucesso, mensagem = corrigir_protocolo(
        initial_date=args.initial_date,
        final_date=args.final_date,
        application_path=args.application_path,
    )
    print("{}: {}".format("OK" if sucesso else "ERRO", mensagem))
    sys.exit(0 if sucesso else 1)


if __name__ == "__main__":
    main()
