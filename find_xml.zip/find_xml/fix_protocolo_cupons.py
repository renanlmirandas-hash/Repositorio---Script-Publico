# -*- coding: utf-8 -*-
"""
fix_protocolo_cupons.py
------------------------------------------------------------------------------
Correção do protocolo (cStat) de notas presas em contingência por divergência
de Chave de Acesso (cStat 539, 100 ou 150).

Este arquivo é o único lugar onde essa lógica mora - `FixingCstatCupons` (a
classe que conecta no barramento e-deploy, lê o FiscalWrapperThread.log e
corrige o XML em fiscal_persistcomp.db) é usada tanto:

  - automaticamente pelo main.py, uma nota por vez, a cada venda que cai em
    contingência (_tentar_corrigir_protocolo_cupom, em consulte_csv.py, que
    importa FixingCstatCupons deste arquivo); quanto
  - manualmente por quem estiver rodando este arquivo direto na linha de
    comando (CLI no fim do arquivo: --listar/--all-pendentes/--order-ids/
    --order-ids-file), para corrigir várias notas de uma vez quando acumula
    um volume que não compensa corrigir uma por uma.

(Antes, em 31/08/2026, essa classe morava separada em fix_cupom_protocol.py e
este arquivo era só um CLI fino por cima dela. Removido depois a pedido do
usuário - agora é um arquivo só, sem import cruzado entre os dois.)

RODA COM O PYTHON 2.7 DA INSTALAÇÃO (pasta "python\\", ao lado de "python3\\")
------------------------------------------------------------------------------
Os módulos proprietários do e-deploy usados aqui (old_helper, bustoken, em
edpcommon.pypkg; msgbus, cfgtools, em common.pypkg) só existem compilados
para Python 2.7 (confirmado comparando o magic number do .pyc - ver
CLAUDE.md). Por isso o componente inteiro (find_xml, main.py incluso) roda em
Python 2.7 - ver incidente de campo de 31/08/2026 no CLAUDE.md.

Uso do CLI (rodando este arquivo direto):
    python.exe fix_protocolo_cupons.py --listar
    python.exe fix_protocolo_cupons.py --all-pendentes
    python.exe fix_protocolo_cupons.py --all-pendentes --dry-run
    python.exe fix_protocolo_cupons.py --order-ids 123413 123999
    python.exe fix_protocolo_cupons.py --order-ids-file notas.txt
    python.exe fix_protocolo_cupons.py --all-pendentes --yes

Sem nenhuma dessas flags de seleção, o CLI recusa rodar (é proposital - nunca
corrige "tudo" sem alguém pedir isso explicitamente).

Se aparecer "ImportError" ou "bad magic number" ao rodar, quase certeza que
você rodou com o python3\\python.exe por engano - use o python\\python.exe
(2.7) da mesma instalação.
------------------------------------------------------------------------------
"""
from __future__ import print_function

import argparse
import base64
import glob
import io
import logging
import os
import re
import sys
import time

from datetime import datetime, timedelta
from xml.etree import cElementTree as ET

# cStat que indicam divergencia de Chave de Acesso corrigivel via fix_cstat (duplicidade de
# NF-e, com a SEFAZ ja reconhecendo uma chave diferente da que esta em fiscal_persistcomp.db).
CSTATS_CORRIGIVEIS = ("539", "100", "150")

# Linha que o nfce.py (parte do SDK e-deploy) grava no FiscalWrapperThread.log quando detecta e
# tenta corrigir sozinho um cStat de duplicidade. Usado tanto por find_key_pattern (uma nota,
# travada num orderid especifico) quanto por encontrar_pendentes/corrigir_lote (varias notas de
# uma vez, regex generico). Exemplo do formato "classico":
#
#   "... nfce.py:2349:_handle_duplicated_diff_key - Tratando 539 da order 000123413.
#    xMotivo SEFAZ: Rejeicao: Duplicidade de NF-e, com diferenca na Chave de Acesso
#    52260817261661005566650010001226111137067129"
#
# NOTA: em producao a SEFAZ tambem manda o xMotivo com a chave entre colchetes e prefixada por
# "chNFe:" (formato cru devolvido por ela), ex.:
#
#   "... Tratando 539 da order 001101699. xMotivo SEFAZ: Rejeicao: Duplicidade de NF-e, com
#    diferenca na Chave de Acesso [chNFe:33260817261661010489650010039377112899059453]"
#
# O RE_PATTERN_LOTE/re_pattern "classico" nao cobre esse formato (o "[chNFe:" faz o
# ([0-9]{44}) falhar logo apos "Chave de Acesso "), entao mantemos os dois padroes: primeiro
# tenta o formato classico, e o formato com colchete/label serve de fallback pras linhas que o
# primeiro nao pegar.
RE_PATTERN_LOTE = re.compile(r"Tratando (\d{3}) da order (\d{9})\..*?Chave de Acesso ([0-9]{44})")
RE_PATTERN_LOTE_CHNFE = re.compile(
    r"Tratando (\d{3}) da order (\d{9})\..*?Chave de Acesso \[chNFe:([0-9]{44})\]")

LOG_FILENAME = "fix_protocolo_cupons.log"


class FixingCstatCupons:
    def __init__(self, app_path):
        # type: (str) -> None
        # app_path vem de get_system_version() (consulte_csv.py) - o mesmo caminho que o main.py
        # já detecta e usa pra tudo mais (acesso_fiscal, path_orders, etc.). Antes essa classe
        # tinha seu próprio get_application_path() com um caminho fixo (só "C:/edeployPOS" ou
        # "/home/administrador/edeployPOS"), que ficava errado sempre que a instalação real fosse
        # mwpos ou edeploy-pos-structure - daí o resto da classe (bin, common.pypkg, o
        # loader_NFCE.cfg) apontava pra pasta errada.
        self.app_path = app_path
        self.app_bin = os.path.join(self.app_path, 'bin')
        self.start_date = datetime.strftime(datetime.today() - timedelta(days=60), "%Y-%m-%d")
        self.current_date = datetime.now().strftime("%Y-%m-%d")
        self.orders_to_fix = []
        self.orders_to_verify_protocol = []

        # Usa o mesmo log já configurado pelo main.py (ou pelo _configurar_log do CLI, no fim
        # deste arquivo, quando rodado standalone) - getLogger com esse nome só serve pra
        # identificar a origem das linhas ("FixingCstatCupons") no log único, as mensagens
        # propagam normalmente pro handler já configurado por quem chamou.
        self.logger = logging.getLogger("FixingCstatCupons")
        self.logger.setLevel(logging.INFO)

        self.nfce_loader = os.path.join(self.app_path, r"data\server\bundles\fiscalwrapper\loader_NFCE.cfg")
        if not os.path.exists(self.nfce_loader):
            self.logger.warning("Enviroment is not NFCE. This process is not supported")
            sys.exit(1)

        self.application_conn()

    def application_conn(self):
        self.mbcontext = None
        pump_path = os.path.join("src", "edpbohpump", "src")
        # O componente inteiro (find_xml) roda com o Python 2.7 da instalacao (pasta "python\",
        # ao lado de "python3\") - ver incidente de campo de 31/08/2026 no CLAUDE.md. Por isso
        # aqui usamos as builds 2.7 dos dois pacotes (common.pypkg e edpcommon.pypkg, SEM o "3"):
        # msgbus/cfgtools (common.pypkg) e old_helper/bustoken (edpcommon.pypkg) sao todos
        # compilados so para Python 2.7 nessa instalacao (confirmado comparando o magic number do
        # .pyc - ver diagnose_pypkg.py e CLAUDE.md). Usar as builds 3.8 (common3.pypkg) aqui
        # quebraria com "bad magic number", porque o interpretador que roda este arquivo e' 2.7.
        sys.path.append(os.path.join(self.app_bin, 'common.pypkg'))
        sys.path.append(os.path.join(self.app_bin, 'edpcommon.pypkg'))
        sys.path.append(os.path.join(self.app_path, pump_path))


        os.environ["BINPATH"] = os.path.join(self.app_path, self.app_bin)
        os.environ["HVPORT"] = "14000"
        os.environ["HVIP"] = "127.0.0.1"
        os.environ["HVCOMPPORT"] = "35689"
        os.environ["HVPID"] = "-1"

        os.chdir(os.environ["BINPATH"])
        from msgbus import MBEasyContext, FM_PARAM, TK_SLCTRL_OMGR_ORDERPICT, TK_SYS_ACK, TK_EVT_EVENT, TK_SLCTRL_OMGR_ORDERPICT
        from old_helper import BaseRepository, remove_xml_namespace
        from bustoken import TK_FISCALWRAPPER_SITUATION, TK_FISCALWRAPPER_CHANGE_CONTINGENCY_STATUS
        import cfgtools

        self.mbcontext = MBEasyContext("STANDALONE_SCRIPT")
        self.base_repository = BaseRepository
        self.FM_PARAM = FM_PARAM
        self.TK_EVT_EVENT = TK_EVT_EVENT
        self.TK_SLCTRL_OMGR_ORDERPICT = TK_SLCTRL_OMGR_ORDERPICT
        self.TK_FISCALWRAPPER_SITUATION = TK_FISCALWRAPPER_SITUATION
        self.TK_FISCALWRAPPER_CHANGE_CONTINGENCY_STATUS = TK_FISCALWRAPPER_CHANGE_CONTINGENCY_STATUS
        self.TK_SYS_ACK = TK_SYS_ACK
        self.cfgtools = cfgtools
        self.remove_xml_namespace = remove_xml_namespace

    def find_key_pattern(self, orderid):
        # type: (int) -> bool
        """
        Procura no FiscalWrapperThread.log a linha que o nfce.py grava quando detecta cStat 539
        (duplicidade de NF-e) e tenta tratar via _handle_duplicated_diff_key, por exemplo:

            "... nfce.py:2349:_handle_duplicated_diff_key - Tratando 539 da order 000123413.
             xMotivo SEFAZ: Rejeição: Duplicidade de NF-e, com diferença na Chave de Acesso
             52260817261661005566650010001226111137067129"

        e usa a "Chave de Acesso" indicada ali (a chave que o SEFAZ já reconhece pra essa nota)
        pra corrigir o protocolo via fix_cstat - mesmo quando o próprio nfce.py também tenta uma
        segunda chave ("XML remontado") e não consegue resolver sozinho.
        """
        self.logger.info("Procurando cStat corrigível nos logs do FiscalWrapper - orderid: {}".format(orderid))
        fiscal_component_directory = os.path.join(self.app_path, r"data\server\bundles\fiscalwrapper")
        logs = glob.glob(os.path.join(fiscal_component_directory, "FiscalWrapperThread.log*"))
        order_padded = str(orderid).zfill(9)
        re_pattern = r"Tratando (\d{{3}}) da order {}\..*?Chave de Acesso ([0-9]{{44}})".format(
            re.escape(order_padded))
        # Fallback pro formato que a SEFAZ realmente manda em produção às vezes - a chave vem
        # entre colchetes, prefixada por "chNFe:" (ver comentário de RE_PATTERN_LOTE_CHNFE acima).
        re_pattern_chnfe = r"Tratando (\d{{3}}) da order {}\..*?Chave de Acesso \[chNFe:([0-9]{{44}})\]".format(
            re.escape(order_padded))

        for file in logs:
            try:
                # io.open (em vez do open() nativo) porque o open() do Python 2.7 nao aceita os
                # parametros encoding/errors - io.open aceita nas duas versoes.
                with io.open(file, encoding="utf-8", errors="replace") as f:
                    log = f.read()
            except (IOError, OSError) as ex:
                self.logger.warning("Não foi possível ler o log {}: {}".format(file, ex))
                continue

            ocorrencias = re.findall(re_pattern, log)
            if not ocorrencias:
                # formato "clássico" não bateu neste arquivo - tenta o formato com
                # "[chNFe:...]" antes de desistir dele.
                ocorrencias = re.findall(re_pattern_chnfe, log)

            for cstat, key in ocorrencias:
                if cstat in CSTATS_CORRIGIVEIS:
                    return self.fix_cstat(orderid, key, cstat)
                elif cstat == "204":
                    return bool(self.key_pattern_fiscallog(orderid, key, cstat))
                else:
                    self.logger.info("Found cStat: {} for orderid: {} ".format(cstat, orderid))

        self.logger.info("Nenhum cStat corrigível encontrado nos logs do FiscalWrapper - orderid: {}".format(orderid))
        return False

    def key_pattern_fiscallog(self, orderid, key, cstat):
        fiscal_component_directory = os.path.join(self.app_path, r"data\server\bundles\fiscalwrapper")
        logs = reversed(glob.glob(os.path.join(fiscal_component_directory, "FiscalWrapper.log*")))
        re_pattern = "OrderId {} final [0-9]*".format(str(orderid).zfill(9))

        for file in logs:
            with open(file) as f:
                log = f.read()

            if re.search(re_pattern, log):
                for found_pattern in re.findall(re_pattern, log):
                    if not found_pattern.split('final ')[1] in key[30:]:
                        key = key[:30] + found_pattern.split('final ')[1]
                        self.fix_cstat(orderid, key, cstat)
                        return True

    def not_send_orders(self,):
        def inner_func(conn):
         # type: (Connection) -> dict
            query = """
            select orderid from fiscaldata where
            senttonfce <> 1 and datetime(datanota,'unixepoch','localtime')
            BETWEEN "{}" and "{}" """.format(self.start_date, self.current_date)

            return [(x.get_entry(0)) for x in conn.select(query)]

        orders_not_send = \
            self.base_repository(self.mbcontext).execute_with_connection(inner_func, service_name="FiscalPersistence")
        if len(orders_not_send) > 0:
            return orders_not_send

        self.logger.info("Nenhuma nota pendente de envio no período: {} a {}".format(self.start_date, self.current_date))

    def force_orders(self,):
        def inner_func(conn):
         # type: (Connection) -> dict
            query = \
                """update fiscaldata set senttonfce = 555 where orderid in ({})""".format(','.join(self.orders_to_fix))

            conn.select(query)

        self.base_repository(self.mbcontext).execute_with_connection(inner_func, service_name="FiscalPersistence")

    def send_fiscalwrapper_event(self, content, token=None):
        if not token:
            token = self.TK_EVT_EVENT
            content = '\0{}'.format(content)

        self.mbcontext.MB_EasySendMessage(
            "FiscalWrapper",
            token,
            format=self.FM_PARAM,
            data=content
        )

    def get_order_picture(self, orderid):
        msg = self.mbcontext.MB_EasySendMessage(
            "ORDERMGR0",
            self.TK_SLCTRL_OMGR_ORDERPICT,
            format=self.FM_PARAM,
            data='\00{}'.format(orderid)
        )

        if msg.token == self.TK_SYS_ACK:
            parsed_data = msg.data.split("\0")
            if parsed_data[2] != "":
                return ET.fromstring(parsed_data[2]).find('./')

    def get_xml_request(self, orderid):
        def inner_func(conn):
         # type: (Connection) -> dict
            query = """select xmlrequest from fiscaldata where orderid = {}""".format(orderid)

            return [(x.get_entry(0)) for x in conn.select(query)]

        return self.base_repository(self.mbcontext).execute_with_connection(inner_func, service_name="FiscalPersistence")

    def get_cupons(self,):
        def inner_func(conn):
         # type: (Connection) -> dict
            query = """select numeronota from fiscaldata where orderid in ({})""".format(",".join(self.orders_to_fix))

            return [(x.get_entry(0)) for x in conn.select(query)]

        return self.base_repository(self.mbcontext).execute_with_connection(inner_func, service_name="FiscalPersistence")

    def get_pos_list(self):
        def inner_func(conn):
            query = """select posid from posstate"""

            return [(x.get_entry(0)) for x in conn.select(query)]

        return self.base_repository(self.mbcontext).execute_with_connection(inner_func, db_name="posctrl")

    def get_orders_unused(self):
        pos_list = self.get_pos_list()

        def inner_func(conn):
            query = """select orderid from orders where orderid in (select orderid from
            OrderCustomProperties where key = 'ORDER_DISABLED' and value = 'false')"""

            return [(x.get_entry(0)) for x in conn.select(query)]

        return self.base_repository(self.mbcontext).execute_parallel_in_all_databases_returning_flat_list(inner_func, pos_list)

    def delete_failed_inutilization(self, orderid):
        pos_list = self.get_pos_list()
        conn = None
        def inner_func(conn):
            query = """delete from ordercustomproperties where key = 'ORDER_DISABLED' and orderid = {}""".format(orderid)

            conn.select(query)

        try:
            self.base_repository(self.mbcontext).execute_parallel_in_all_databases_returning_flat_list(inner_func, pos_list)
        except Exception:
            self.logger.exception("Erro ao deletar ORDER_DISABLED - orderid: {}".format(orderid))
        finally:
            if conn:
                conn.close()

    def process_resign(self):
        self.logger.info("Iniciando process_resign - período: {} a {}".format(self.start_date, self.current_date))
        self.orders_not_send = self.not_send_orders()

        if self.orders_not_send:
            for orderid in self.orders_not_send:
                order_picture = self.get_order_picture(orderid)
                if order_picture:
                    stateid = order_picture.find('.').attrib["stateId"]

                    if not stateid == "4" and not (self.find_key_pattern(orderid)):
                        self.orders_to_fix.append(orderid)
                else:
                    self.logger.info("Unable to obtain orderpicture for orderid: {}".format(orderid))

        if len(self.orders_to_verify_protocol) > 0:
            min_date = min(self.orders_to_verify_protocol)
            max_date = max(self.orders_to_verify_protocol)
            self.running_nfe_situation(min_date, max_date)
            self.logger.info("Running check situation sefaz. See process on fiscalwrapper.log")


        if not len(self.orders_to_fix) > 0:
            self.logger.info("Not found any order paid pending to sent SEFAZ")
            return

        self.force_orders()
        self.cupons_to_fix = self.get_cupons()
        self.logger.info("Resign sent NumeroNota to SEFAZ: {}".format(",".join(str(c) for c in self.cupons_to_fix)))
        self.send_fiscalwrapper_event("ReSignXMLs")
        self.send_fiscalwrapper_event("Enabled", token=self.TK_FISCALWRAPPER_CHANGE_CONTINGENCY_STATUS)
        time.sleep(6)
        self.send_fiscalwrapper_event("Disabled", token=self.TK_FISCALWRAPPER_CHANGE_CONTINGENCY_STATUS)

    def process_unused_orders(self):
        self.orders = self.get_orders_unused()
        self.orders_unused = set(self.orders)
        force_disable = None

        for orderid in self.orders_unused:
            order_picture = self.get_order_picture(orderid)
            if order_picture:
                stateid = order_picture.find('.').attrib["stateId"]
                numeronota = order_picture.find("CustomOrderProperties/OrderProperty/[@key='FISCAL_ID']").get('value')
                pos_id = order_picture.find('.').attrib["posId"]
                for state in reversed(order_picture.find('StateHistory').findall('State')):
                    if state.get('stateId') == "5":
                        force_disable = False
                        break

                    force_disable = True

                if force_disable:
                    inutilization_status = \
                        order_picture.find("CustomOrderProperties/OrderProperty/[@key='ORDER_DISABLED']").get('value')

                    self.logger.info("Forcing inutilization for orderid: {} numeronota: {} "
                                     "stateid: {} current inutilization state: {}"
                                     .format(orderid, numeronota, stateid, inutilization_status))
                    self.delete_failed_inutilization(orderid)
                    self.send_fiscalwrapper_event("DisableNfceOrder")
                    time.sleep(5)
            else:
                self.logger.info("Unable to obtain orderpicture for orderid: {}".format(orderid))


    def update_fiscal_persist(self, orderid, new_request):
        def inner_func(conn):
         # type: (Connection) -> dict
            query = """update fiscaldata set xmlrequest = '{}', senttonfce = 1 where orderid = {}""".format(new_request, orderid)

            conn.select(query)

        self.base_repository(self.mbcontext).execute_with_connection(inner_func, service_name="FiscalPersistence")
    def fix_cstat(self, orderid, key, cstat):
        # type: (int, str, str) -> bool
        """
        Troca a chave de acesso incorreta pela chave que a SEFAZ já reconhece pra essa nota, e
        regrava o XML (com um protocolo de aceite) de volta em fiscal_persistcomp.db.

        Retorna True se corrigiu, False se falhou (loga o motivo com self.logger.exception, com
        stack trace completo, mas não propaga a exceção) - assim tanto find_key_pattern (correção
        automática, uma nota por vez, durante o fluxo do main.py) quanto corrigir_lote (correção
        em lote, várias notas) conseguem seguir adiante sem se preocupar em capturar exceção.
        """
        self.logger.info("Iniciando fix_cstat - orderid: {} key: {} cstat: {}".format(orderid, key, cstat))
        try:
            order_picture = self.get_order_picture(orderid)
            if order_picture is None:
                self.logger.warning("Não consegui obter orderpicture para orderid: {} - pulando".format(orderid))
                return False
            xml_request = order_picture.find("CustomOrderProperties/OrderProperty/[@key='FISCAL_XML']").get('value')
            # base64.b64decode devolve bytes em Python 3 (em Python 2 devolvia str/bytes de forma
            # intercambiável) - todo o replace/concatenação abaixo precisa ser feito em bytes, e só
            # o resultado final (já em base64) volta a ser texto para ir na query SQL.
            xml_string_fiscal_persistcomp = base64.b64decode(xml_request)
            xml_element = ET.fromstring(xml_string_fiscal_persistcomp)
            inf_nfe = self.remove_xml_namespace(ET.tostring(xml_element.find(".//")))
            nfe_key = inf_nfe.attrib["Id"][3:]
            new_xml = xml_string_fiscal_persistcomp.replace(nfe_key.encode("utf-8"), key.encode("utf-8"))
            numeronota = inf_nfe.find(".//nNF").text

            base_xml = b'''<nfeProc xmlns="http://www.portalfiscal.inf.br/nfe" versao="4.00">'''
            end_xml = b'''<protNFe versao="4.00"><infProt><tpAmb>1</tpAmb><verAplic>PR-v4_4_9</verAplic><chNFe></chNFe><dhRecbto>2021-08-02T16:30:48-03:00</dhRecbto><cStat>204</cStat><xMotivo>Duplicidade de NF-e [nRec:411002421114061]</xMotivo></infProt></protNFe></nfeProc>'''

            new_request = base64.b64encode(base_xml + new_xml + end_xml).decode("ascii")
            self.logger.info("Fixing protocol orderid: {} numero nota: {} with key: {}".format(orderid, numeronota, key))
            self.update_fiscal_persist(orderid, new_request)
            date = inf_nfe.find(".//dhEmi").text[0:10].replace('-', '')

            if date not in self.orders_to_verify_protocol:
                self.orders_to_verify_protocol.append(date)
            return True
        except Exception:
            self.logger.exception("Falha ao corrigir protocolo (fix_cstat) - orderid: {} key: {} cstat: {}".format(orderid, key, cstat))
            return False

    def encontrar_pendentes(self, order_ids=None, cstats_alvo=CSTATS_CORRIGIVEIS):
        # type: (list, tuple) -> dict
        """
        Varre o(s) FiscalWrapperThread.log* procurando notas com cStat corrigível (539/100/150
        por padrão), lendo cada arquivo LINHA A LINHA - nunca carrega o log inteiro na memória de
        uma vez (alguns ficam bem grandes com o tempo, ver incidente de campo de 31/08/2026).

        Os arquivos são processados do MAIS NOVO para o mais antigo (por data de modificação). Se
        `order_ids` for informado, para de abrir arquivos mais antigos assim que todas as notas
        pedidas já tiverem sido encontradas (early exit) - evita varrer o histórico inteiro quando
        já se sabe quais notas corrigir.

        Retorna um dict {orderid: (cstat, key)} com a ocorrência mais recente de cada orderid
        encontrado (só os pedidos, se `order_ids` foi informado).
        """
        fiscal_component_directory = os.path.join(self.app_path, r"data\server\bundles\fiscalwrapper")
        logs = glob.glob(os.path.join(fiscal_component_directory, "FiscalWrapperThread.log*"))
        logs.sort(key=lambda caminho: os.path.getmtime(caminho), reverse=True)

        faltando = set(order_ids) if order_ids else None
        pendentes = {}

        for arquivo in logs:
            try:
                f = io.open(arquivo, encoding="utf-8", errors="replace")
            except (IOError, OSError) as ex:
                self.logger.warning("Não consegui abrir o log {}: {}".format(arquivo, ex))
                continue

            try:
                for linha in f:
                    ocorrencias = RE_PATTERN_LOTE.findall(linha)
                    if not ocorrencias:
                        # formato "clássico" não bateu nesta linha - tenta o formato com
                        # "[chNFe:...]" (o que a SEFAZ realmente manda em produção às vezes)
                        # antes de desistir dela.
                        ocorrencias = RE_PATTERN_LOTE_CHNFE.findall(linha)

                    for cstat, order_padded, key in ocorrencias:
                        if cstat not in cstats_alvo:
                            continue
                        orderid = int(order_padded)
                        if order_ids and orderid not in order_ids:
                            continue
                        # sobrescreve: lendo o arquivo em ordem, a última ocorrência encontrada é
                        # sempre a mais recente pra esse orderid dentro do arquivo.
                        pendentes[orderid] = (cstat, key)
                        if faltando is not None:
                            faltando.discard(orderid)
            finally:
                f.close()

            if faltando is not None and not faltando:
                self.logger.info(
                    "Todas as notas pedidas já foram encontradas em {} - não preciso abrir logs mais antigos".format(arquivo))
                break

        return pendentes

    def corrigir_lote(self, order_ids=None, dry_run=False):
        # type: (list, bool) -> tuple
        """
        Encontra as notas pendentes (todas, ou só as de `order_ids`) e aplica fix_cstat em cada
        uma. Uma falha numa nota não interrompe as demais.

        Retorna (total_encontrado, total_corrigido, total_falhou, nao_encontrados) - o último item
        é a lista de orderids pedidos que não apareceram no log (só relevante quando `order_ids`
        foi informado).
        """
        pendentes = self.encontrar_pendentes(order_ids=order_ids)
        nao_encontrados = [oid for oid in (order_ids or []) if oid not in pendentes]

        if not pendentes:
            self.logger.info("Nenhuma nota pendente de correção de protocolo encontrada")
            return 0, 0, 0, nao_encontrados

        self.logger.info("Encontradas {} nota(s) pendente(s) de correção de protocolo:".format(len(pendentes)))
        for orderid, (cstat, key) in sorted(pendentes.items()):
            self.logger.info("  orderid={} cstat={} chave={}".format(orderid, cstat, key))
        if nao_encontrados:
            self.logger.info("Não encontrados no log: {}".format(", ".join(str(o) for o in sorted(nao_encontrados))))

        if dry_run:
            self.logger.info("[dry-run] Nenhuma alteração aplicada.")
            return len(pendentes), 0, 0, nao_encontrados

        total_corrigido = 0
        total_falhou = 0
        for orderid, (cstat, key) in sorted(pendentes.items()):
            sucesso = self.fix_cstat(orderid, key, cstat)
            if sucesso:
                total_corrigido += 1
            else:
                total_falhou += 1
            time.sleep(1)  # evita martelar o barramento numa lista grande

        return len(pendentes), total_corrigido, total_falhou, nao_encontrados

    def running_nfe_situation(self, min_date, max_date):
        data = "{}\0{}".format(min_date, max_date)
        self.send_fiscalwrapper_event(data, token=self.TK_FISCALWRAPPER_SITUATION)


# ==============================================================================
# CLI - só usado quando este arquivo é rodado direto (python fix_protocolo_cupons.py ...),
# não quando é importado (ex: consulte_csv.py só importa a classe FixingCstatCupons acima).
# ==============================================================================

def _configurar_log():
    logger = logging.getLogger("FixingCstatCupons")
    logger.setLevel(logging.INFO)
    if not logger.handlers:
        handler = logging.FileHandler(LOG_FILENAME, encoding="utf-8")
        handler.setFormatter(logging.Formatter("%(asctime)s - %(levelname)s - %(message)s"))
        logger.addHandler(handler)
        console = logging.StreamHandler()
        console.setFormatter(logging.Formatter("%(levelname)s - %(message)s"))
        logger.addHandler(console)


def ler_order_ids_de_arquivo(caminho):
    order_ids = []
    with open(caminho) as f:
        for linha in f:
            linha = linha.strip()
            if not linha or linha.startswith("#"):
                continue
            order_ids.append(int(linha))
    return order_ids


def parse_args():
    parser = argparse.ArgumentParser(
        description=(
            "Corrige o protocolo (cStat) de notas presas em contingência por divergência de "
            "Chave de Acesso. Rode com o Python 2.7 da instalação (pasta 'python\\', não "
            "'python3\\')."
        )
    )
    parser.add_argument(
        "--app-path", default=None,
        help="Força o caminho da instalação (ex: C:\\edeployPOS). Sem isso, detecta automaticamente."
    )

    selecao = parser.add_mutually_exclusive_group(required=True)
    selecao.add_argument(
        "--order-ids", type=int, nargs="+", metavar="ORDERID",
        help="Corrige só essas notas específicas (uma ou mais, separadas por espaço)."
    )
    selecao.add_argument(
        "--order-ids-file", metavar="ARQUIVO",
        help="Corrige as notas listadas nesse arquivo (um orderid por linha; linhas em branco "
             "e começando com # são ignoradas)."
    )
    selecao.add_argument(
        "--all-pendentes", action="store_true",
        help="Corrige TODAS as notas com cStat corrigível encontradas no log."
    )
    selecao.add_argument(
        "--listar", action="store_true",
        help="Só lista as notas pendentes encontradas no log (todas, ou as de --order-ids/"
             "--order-ids-file), sem corrigir nada."
    )

    parser.add_argument("--dry-run", action="store_true", help="Só mostra o que seria corrigido, não grava nada.")
    parser.add_argument("-y", "--yes", action="store_true", help="Não pede confirmação antes de corrigir.")
    return parser.parse_args()


def main():
    args = parse_args()
    _configurar_log()

    if sys.version_info[0] != 2:
        print(
            "AVISO: este script foi feito para rodar com o Python 2.7 da instalação "
            "(pasta 'python\\python.exe'), não com python3. Os imports de old_helper/"
            "bustoken provavelmente vão falhar a seguir."
        )

    order_ids = None
    if args.order_ids:
        order_ids = args.order_ids
    elif args.order_ids_file:
        order_ids = ler_order_ids_de_arquivo(args.order_ids_file)
        if not order_ids:
            print("Nenhum orderid válido encontrado em {}".format(args.order_ids_file))
            sys.exit(1)

    # get_system_version() só é importado aqui dentro (e não no topo do arquivo) para este CLI
    # não depender de consulte_csv.py quando FixingCstatCupons é usado só como biblioteca (ex:
    # consulte_csv.py importando FixingCstatCupons deste arquivo) - evita import circular.
    if args.app_path:
        app_path = args.app_path
    else:
        from consulte_csv import get_system_version
        app_path = get_system_version()
    print("Instalação: {}".format(app_path))

    corretor = FixingCstatCupons(app_path)

    if args.listar:
        pendentes = corretor.encontrar_pendentes(order_ids=order_ids)
        if not pendentes:
            print("Nenhuma nota pendente de correção de protocolo encontrada.")
            return
        print("\n{} nota(s) pendente(s) de correção de protocolo:".format(len(pendentes)))
        for orderid, (cstat, key) in sorted(pendentes.items()):
            print("  orderid={} cstat={} chave={}".format(orderid, cstat, key))
        return

    if order_ids:
        print("Notas selecionadas: {}".format(", ".join(str(o) for o in order_ids)))
    else:
        print("Seleção: TODAS as notas pendentes encontradas no log.")

    if not args.dry_run and not args.yes:
        alvo = "essas {} nota(s)".format(len(order_ids)) if order_ids else "TODAS as notas pendentes"
        resposta = raw_input("Confirma a correção de {}? [s/N] ".format(alvo))  # noqa: F821 (Python 2)
        if resposta.strip().lower() not in ("s", "sim", "y", "yes"):
            print("Cancelado pelo usuário.")
            return

    total, corrigido, falhou, nao_encontrados = corretor.corrigir_lote(order_ids=order_ids, dry_run=args.dry_run)

    if args.dry_run:
        print("\n[dry-run] {} nota(s) seriam corrigidas. Nenhuma alteração aplicada.".format(total))
    else:
        print("\nConcluído: {} encontrada(s), {} corrigida(s), {} falhou(aram).".format(total, corrigido, falhou))
        print("Detalhes em: {}".format(os.path.abspath(LOG_FILENAME)))

    if nao_encontrados:
        print("Não encontrados no log: {}".format(", ".join(str(o) for o in sorted(nao_encontrados))))


if __name__ == "__main__":
    main()
