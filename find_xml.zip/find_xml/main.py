# -*- coding: utf-8 -*-
from send_orderpaid_boh import *
from xml_file import *
from sqlite_update import *
from time_hora import *
from consulte_csv import *
import subprocess
import time
import logging
import base64
import re

log_filename = 'system_script.log'
# Configuracao manual do handler (em vez de logging.basicConfig(..., encoding='utf-8')) porque o
# parametro encoding do basicConfig so existe a partir do Python 3.9, e o componente inteiro
# (find_xml) voltou a rodar com o Python 2.7 da instalacao (pasta "python\", ao lado de
# "python3\") - ver incidente de campo de 31/08/2026 no CLAUDE.md.
# SEM encoding= aqui (mesmo o FileHandler aceitando o parametro) - ver incidente de campo de
# 31/08/2026 (5): em Python 2.7 as mensagens de log sao "str" comuns, ja em bytes UTF-8 (por causa
# do "# -*- coding: utf-8 -*-" no topo dos arquivos), e nao unicode. Um FileHandler com
# encoding="utf-8" abre o arquivo via codecs.open(), cujo stream.write() so aceita unicode -
# escrever um "str" nele faz o Python tentar decodificar esse "str" com o codec ASCII padrao antes
# de re-codificar, o que quebra (UnicodeDecodeError) assim que a mensagem tem um acento. Sem
# encoding=, o FileHandler abre um arquivo binario comum e escreve os bytes UTF-8 direto, sem
# tentar decodificar nada - o .log final continua sendo UTF-8 valido, só que sem essa camada
# problemática no meio.
_log_handler = logging.FileHandler(log_filename)
_log_handler.setFormatter(logging.Formatter('%(asctime)s - %(levelname)s - %(message)s'))
logging.getLogger().setLevel(logging.INFO)
logging.getLogger().addHandler(_log_handler)

arquivo_file = "file_csv/bkoffice.csv"
logging.info("Start Componente")
print("start Componente")
caminho_databases = get_system_version()
if caminho_databases == "/home/administrador/mwpos_server":
    acesso_fiscal = r"""{}/data/server/databases/fiscal_persistcomp.db""".format(caminho_databases)
    file_store = r"""{}/data/server/bundles/storecfg/loader.cfg""".format(caminho_databases)
    localizar_xml = r"{}/bin/".format(caminho_databases)
    Erro = ["Erros", "Enviados/2025/12/"]
    local_fix = "fix_venda/"
    local_fix_data = "{}/data/server/bundles/bkofficeuploader/python/repository".format(caminho_databases)
elif caminho_databases == r"C:\edeployPOS":
    acesso_fiscal = r"""{}\data\server\databases\fiscal_persistcomp.db""".format(caminho_databases)
    file_store = r"""{}\data\server\bundles\storecfg\loader.cfg""".format(caminho_databases)
    localizar_xml = r"{}\bin".format(caminho_databases)
    path_orders = r"{}\data\server\databases".format(caminho_databases)
    path_orders_backup = r"{}\data\server\backups_maintenance\databases".format(caminho_databases)
    Erro = [r"\Erros", r"\Enviados\2026\06"]
    acesso_orders_tbl = r"""{}\data\server\databases\tblservice.db""".format(caminho_databases)
elif caminho_databases == r"C:\edeploy-pos-structure":
    acesso_fiscal = r"""{}\data\server\databases\fiscal_persistcomp.db""".format(caminho_databases)
    file_store = r"""{}\data\server\bundles\storecfg\loader.cfg""".format(caminho_databases)
    path_orders = r"{}\data\server\databases".format(caminho_databases)
    path_orders_backup = r"{}\data\server\backups_maintenance\databases".format(caminho_databases)
    localizar_xml = r"{}\bin".format(caminho_databases)
    Erro = [r"\Erros", r"\Enviados\2026\06"]
    acesso_orders_tbl = r"""{}\data\server\databases\tblservice.db""".format(caminho_databases)


def main():
    logging.info("Validando as informações do arquivo bkoffice.csv")
    arquivo_csv = ler_arquivo_csv(arquivo_file)
    retorno_archilo = file_valor_sentto(arquivo_csv)
    xml_bin = []
    for store_cfg in retorno_archilo:
        xml_numero = store_cfg.get("numeronota")
        sales_data = find_fiscal_id(path_orders, xml_numero)
        if sales_data:
            invoceid = sales_data[0]["nota"]
            order_id = sales_data[0]["orderid"]
            path_sales = sales_data[0]["path_order"]
            xml_bin.append({"numero_nota": xml_numero, "invoceid": invoceid, "orderid": order_id, "path_order": path_sales})
        else:
            logging.info("Nota não identificada no banco {}".format(xml_numero))
    try:
        for xml_file in xml_bin:
            if xml_file.get("numero_nota") == xml_file.get("invoceid"):
                path_pos = xml_file.get("path_order")
                posid = re.search(r'(\d+)$', path_pos)
                consult_order = connect_order_state(xml_file.get("path_order"), xml_file.get("orderid"))
                if consult_order:
                    order_statr = time_direction(consult_order, xml_file.get("orderid"), xml_file.get("path_order"), xml_file.get("invoceid"), posid.group(1), acesso_fiscal)
                    logging.debug(order_statr)
                    #if order_statr == 5:
                        #StandAlone(xml_file.get("orderid"))
    except Exception as ex:
        logging.info("Erro {}".format(ex))


main()
main_fix()
print("Finish Componente, Log do Script no arquivo: ", log_filename, "")
logging.info("Finish Componente")

