C:\edeploy-pos-structure\python\python.exe main.py update
pause