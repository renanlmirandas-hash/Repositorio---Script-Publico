# -*- coding: utf-8 -*-
"""
fix_protocolo_cupons.py
------------------------------------------------------------------------------
Script EXCLUSIVO para corrigir em lote o protocolo (cStat) de notas presas em
contingencia por divergencia de Chave de Acesso (cStat 539, 100 ou 150) - o
mesmo problema que o FixingCstatCupons (fix_cupom_protocol.py) tentaria
corrigir automaticamente a cada venda, dentro do main.py.

POR QUE ESSE SCRIPT PRECISA SER SEPARADO E RODAR COM PYTHON 2.7
------------------------------------------------------------------------------
Os modulos proprietarios do e-deploy usados aqui (old_helper, bustoken, de
edpcommon.pypkg) so existem compilados para Python 2.7 nessa instalacao - nao
existe build Python 3 desses dois modulos em lugar nenhum (confirmado
comparando o magic number do .pyc: old_helper.pyc e bustoken.pyc = 62211,
que e exatamente o magic number do Python 2.7; msgbus/cfgtools tem build
Python 3.8 em common3.pypkg, mas old_helper/bustoken NAO tem equivalente
"edpcommon3.pypkg"). Por isso:

  - main.py e o resto da integracao (find_xml) continuam em Python 3, sem
    nenhuma mudanca.
  - Este script roda a parte, manualmente ou agendado, usando o Python 2.7
    que ja vem junto da instalacao e-deploy (pasta "python\\", ao lado de
    "python3\\") - e la os quatro modulos (msgbus, cfgtools, old_helper,
    bustoken) resolvem sem problema, porque common.pypkg/edpcommon.pypkg
    (sem o "3") sao as builds 2.7.

Uso (rodar com o Python 2.7 da instalacao, NAO com o python3):
    C:\\edeploy-pos-structure\\python\\python.exe fix_protocolo_cupons.py
    C:\\edeploy-pos-structure\\python\\python.exe fix_protocolo_cupons.py --dry-run
    C:\\edeploy-pos-structure\\python\\python.exe fix_protocolo_cupons.py --yes
    C:\\edeploy-pos-structure\\python\\python.exe fix_protocolo_cupons.py --order-id 123413

Sem --order-id, varre TODO o FiscalWrapperThread.log procurando todas as
notas com cStat 539/100/150 corrigivel (a mesma linha que o nfce.py grava ao
tentar e falhar em corrigir sozinho: "Tratando <cstat> da order <orderid>...
Chave de Acesso <44 digitos>") e corrige todas de uma vez - em vez de
precisar identificar e corrigir nota por nota na mao.

Se aparecer "ImportError" ou "bad magic number" ao rodar, quase certeza que
voce rodou com o python3\\python.exe por engano - use o python\\python.exe
(2.7) da mesma instalacao.
------------------------------------------------------------------------------
"""
from __future__ import print_function

import argparse
import base64
import glob
import logging
import os
import re
import sys
import time
from datetime import datetime, timedelta
from xml.etree import cElementTree as ET


# ============================================================================
# Deteccao da instalacao (mesmo criterio do get_system_version em
# consulte_csv.py, para os dois ficarem sempre de acordo sobre qual
# instalacao e qual).
# ============================================================================

def is_windows():
    import platform
    return platform.system().lower() == "windows"


def detectar_app_path():
    if is_windows() and os.path.exists(r"C:\mwpos"):
        return r"C:\mwpos"
    if is_windows() and os.path.exists(r"C:\edeployPOS"):
        return r"C:\edeployPOS"
    if is_windows() and os.path.exists(r"C:\edeploy-pos-structure"):
        return r"C:\edeploy-pos-structure"
    if not is_windows() and os.path.exists("/home/administrador/edeployPOS"):
        return "/home/administrador/edeployPOS"
    return r"/home/administrador/mwpos_server"


# ============================================================================
# Regex da linha de log gravada pelo nfce.py ao detectar e tentar (e falhar
# em) corrigir sozinho um cStat de duplicidade - mesma logica do
# find_key_pattern em fix_cupom_protocol.py, mas sem travar num orderid
# especifico: aqui capturamos TODAS as ocorrencias do log.
#
#   "... nfce.py:2349:_handle_duplicated_diff_key - Tratando 539 da order
#    000123413. xMotivo SEFAZ: Rejeicao: Duplicidade de NF-e, com diferenca
#    na Chave de Acesso 52260817261661005566650010001226111137067129"
# ============================================================================

RE_PATTERN_LOTE = re.compile(
    r"Tratando (\d{3}) da order (\d{9})\..*?Chave de Acesso ([0-9]{44})"
)

CSTATS_CORRIGIVEIS = ("539", "100", "150")

LOG_FILENAME = "fix_protocolo_cupons.log"


class CorrecaoProtocoloLote(object):
    """
    Versao standalone (Python 2.7) da correcao de protocolo do
    FixingCstatCupons (fix_cupom_protocol.py), com um metodo adicional para
    corrigir TODAS as notas pendentes encontradas no log de uma vez, em vez
    de uma por vez.
    """

    def __init__(self, app_path):
        self.app_path = app_path
        self.app_bin = os.path.join(self.app_path, "bin")
        self.mbcontext = None

        self.logger = logging.getLogger("fix_protocolo_cupons")
        self.logger.setLevel(logging.INFO)
        if not self.logger.handlers:
            handler = logging.FileHandler(LOG_FILENAME, encoding="utf-8")
            handler.setFormatter(logging.Formatter("%(asctime)s - %(levelname)s - %(message)s"))
            self.logger.addHandler(handler)
            # tambem no console, pra quem estiver rodando na mao ver na hora
            console = logging.StreamHandler()
            console.setFormatter(logging.Formatter("%(levelname)s - %(message)s"))
            self.logger.addHandler(console)

        nfce_loader = os.path.join(self.app_path, "data/server/bundles/fiscalwrapper/loader_NFCE.cfg")
        if not os.path.exists(nfce_loader):
            self.logger.error("Ambiente nao e NFCE (nao achei loader_NFCE.cfg em %s) - abortando", nfce_loader)
            sys.exit(1)

        self.application_conn()

    def application_conn(self):
        pump_path = os.path.join("src", "edpbohpump", "src")
        # IMPORTANTE: aqui usamos as builds Python 2.7 (common.pypkg /
        # edpcommon.pypkg, SEM o "3") porque este script roda com o
        # python\python.exe (2.7) da instalacao - e' onde old_helper e
        # bustoken realmente funcionam. Nao trocar para common3/edpcommon3
        # aqui (isso e' so para quando o script roda em Python 3, que nao e'
        # o caso deste arquivo).
        sys.path.append(os.path.join(self.app_bin, "common.pypkg"))
        sys.path.append(os.path.join(self.app_bin, "edpcommon.pypkg"))
        sys.path.append(os.path.join(self.app_path, pump_path))

        os.environ["BINPATH"] = os.path.join(self.app_path, self.app_bin)
        os.environ["HVPORT"] = "14000"
        os.environ["HVIP"] = "127.0.0.1"
        os.environ["HVCOMPPORT"] = "35689"
        os.environ["HVPID"] = "-1"

        os.chdir(os.environ["BINPATH"])
        from msgbus import MBEasyContext, FM_PARAM, TK_SLCTRL_OMGR_ORDERPICT, TK_SYS_ACK
        from old_helper import BaseRepository, remove_xml_namespace
        import cfgtools

        self.mbcontext = MBEasyContext("FIX_PROTOCOLO_CUPONS_LOTE")
        self.base_repository = BaseRepository
        self.FM_PARAM = FM_PARAM
        self.TK_SLCTRL_OMGR_ORDERPICT = TK_SLCTRL_OMGR_ORDERPICT
        self.TK_SYS_ACK = TK_SYS_ACK
        self.cfgtools = cfgtools
        self.remove_xml_namespace = remove_xml_namespace

    def get_order_picture(self, orderid):
        msg = self.mbcontext.MB_EasySendMessage(
            "ORDERMGR0",
            self.TK_SLCTRL_OMGR_ORDERPICT,
            format=self.FM_PARAM,
            data="\00{}".format(orderid),
        )
        if msg.token == self.TK_SYS_ACK:
            parsed_data = msg.data.split("\0")
            if parsed_data[2] != "":
                return ET.fromstring(parsed_data[2]).find("./")
        return None

    def update_fiscal_persist(self, orderid, new_request):
        def inner_func(conn):
            query = """update fiscaldata set xmlrequest = '{}' where orderid = {}""".format(new_request, orderid)
            conn.select(query)

        self.base_repository(self.mbcontext).execute_with_connection(inner_func, service_name="FiscalPersistence")

    def fix_cstat(self, orderid, key, cstat):
        # type: (int, str, str) -> bool
        """
        Mesma logica do fix_cstat original (fix_cupom_protocol.py): troca a
        chave de acesso incorreta pela chave que a SEFAZ ja reconhece pra
        essa nota, e regrava o XML (com um protocolo de aceite) de volta em
        fiscal_persistcomp.db. Retorna True se corrigiu, False se falhou
        (loga o motivo e segue pra proxima nota, nao interrompe o lote).
        """
        self.logger.info("Iniciando fix_cstat - orderid: %s key: %s cstat: %s", orderid, key, cstat)
        try:
            order_picture = self.get_order_picture(orderid)
            if order_picture is None:
                self.logger.warning("Nao consegui obter orderpicture para orderid: %s - pulando", orderid)
                return False

            xml_request = order_picture.find(
                "CustomOrderProperties/OrderProperty/[@key='FISCAL_XML']"
            ).get("value")
            xml_string_fiscal_persistcomp = base64.b64decode(xml_request)
            xml_element = ET.fromstring(xml_string_fiscal_persistcomp)
            inf_nfe = self.remove_xml_namespace(ET.tostring(xml_element.find(".//")))
            nfe_key = inf_nfe.attrib["Id"][3:]
            new_xml = xml_string_fiscal_persistcomp.replace(nfe_key.encode("utf-8"), key.encode("utf-8"))
            numeronota = inf_nfe.find(".//nNF").text

            base_xml = b"""<nfeProc xmlns="http://www.portalfiscal.inf.br/nfe" versao="4.00">"""
            end_xml = (
                b"""<protNFe versao="4.00"><infProt><tpAmb>1</tpAmb><verAplic>PR-v4_4_9</verAplic>"""
                b"""<chNFe></chNFe><dhRecbto>2021-08-02T16:30:48-03:00</dhRecbto><cStat>204</cStat>"""
                b"""<xMotivo>Duplicidade de NF-e [nRec:411002421114061]</xMotivo></infProt></protNFe></nfeProc>"""
            )

            new_request = base64.b64encode(base_xml + new_xml + end_xml)
            self.logger.info(
                "Corrigindo protocolo orderid: %s numero nota: %s com chave: %s", orderid, numeronota, key
            )
            self.update_fiscal_persist(orderid, new_request)
            return True
        except Exception:
            self.logger.exception(
                "Falha ao corrigir protocolo (fix_cstat) - orderid: %s key: %s cstat: %s", orderid, key, cstat
            )
            return False

    def encontrar_pendentes(self, log_dir, cstats_alvo=CSTATS_CORRIGIVEIS):
        """
        Varre TODOS os arquivos FiscalWrapperThread.log* (do mais antigo pro
        mais novo) e retorna um dict {orderid: (cstat, key)} com a ULTIMA
        ocorrencia de cada orderid encontrado - ou seja, se uma nota aparece
        mais de uma vez no log (o nfce.py tentando de novo), pegamos a
        tentativa mais recente.
        """
        logs = glob.glob(os.path.join(log_dir, "FiscalWrapperThread.log*"))
        logs.sort(key=lambda caminho: os.path.getmtime(caminho))  # mais antigo -> mais novo

        pendentes = {}
        for arquivo in logs:
            try:
                with open(arquivo, "rb") as f:
                    conteudo = f.read()
                try:
                    texto = conteudo.decode("utf-8")
                except UnicodeDecodeError:
                    texto = conteudo.decode("latin-1", errors="replace")
            except (IOError, OSError) as ex:
                self.logger.warning("Nao consegui ler o log %s: %s", arquivo, ex)
                continue

            for cstat, order_padded, key in RE_PATTERN_LOTE.findall(texto):
                if cstat not in cstats_alvo:
                    continue
                orderid = int(order_padded)
                # sobrescreve com a ocorrencia mais recente (arquivos em ordem cronologica)
                pendentes[orderid] = (cstat, key)

        return pendentes

    def corrigir_lote(self, log_dir, dry_run=False):
        """
        Encontra todas as notas pendentes e aplica fix_cstat em cada uma.
        Retorna (total_encontrado, total_corrigido, total_falhou).
        """
        pendentes = self.encontrar_pendentes(log_dir)

        if not pendentes:
            self.logger.info("Nenhuma nota pendente de correcao de protocolo encontrada em %s", log_dir)
            return 0, 0, 0

        self.logger.info("Encontradas %d nota(s) pendente(s) de correcao de protocolo:", len(pendentes))
        for orderid, (cstat, key) in sorted(pendentes.items()):
            self.logger.info("  orderid=%s cstat=%s chave=%s", orderid, cstat, key)

        if dry_run:
            self.logger.info("[dry-run] Nenhuma alteracao aplicada.")
            return len(pendentes), 0, 0

        total_corrigido = 0
        total_falhou = 0
        for orderid, (cstat, key) in sorted(pendentes.items()):
            sucesso = self.fix_cstat(orderid, key, cstat)
            if sucesso:
                total_corrigido += 1
            else:
                total_falhou += 1
            time.sleep(1)  # evita martelar o barramento numa lista grande

        return len(pendentes), total_corrigido, total_falhou


def parse_args():
    parser = argparse.ArgumentParser(
        description=(
            "Corrige em lote o protocolo (cStat) de notas presas em contingencia por "
            "divergencia de Chave de Acesso. Rode com o Python 2.7 da instalacao "
            "(pasta 'python\\', nao 'python3\\')."
        )
    )
    parser.add_argument(
        "--app-path", default=None,
        help="Forca o caminho da instalacao (ex: C:\\edeployPOS). Sem isso, detecta automaticamente."
    )
    parser.add_argument(
        "--order-id", type=int, default=None,
        help="Corrige so essa nota especifica, em vez de varrer o log inteiro."
    )
    parser.add_argument("--dry-run", action="store_true", help="So mostra o que seria corrigido, nao grava nada.")
    parser.add_argument("-y", "--yes", action="store_true", help="Nao pede confirmacao antes de corrigir.")
    return parser.parse_args()


def main():
    args = parse_args()

    if sys.version_info[0] != 2:
        print(
            "AVISO: este script foi feito para rodar com o Python 2.7 da instalacao "
            "(pasta 'python\\python.exe'), nao com python3. Os imports de old_helper/"
            "bustoken provavelmente vao falhar a seguir."
        )

    app_path = args.app_path or detectar_app_path()
    print("Instalacao: {}".format(app_path))

    corretor = CorrecaoProtocoloLote(app_path)

    log_dir = os.path.join(app_path, "data/server/bundles/fiscalwrapper")

    if args.order_id:
        pendentes = corretor.encontrar_pendentes(log_dir)
        if args.order_id not in pendentes:
            print("Orderid {} nao encontrado com cStat corrigivel no log ({}).".format(args.order_id, log_dir))
            sys.exit(1)
        cstat, key = pendentes[args.order_id]
        print("orderid={} cstat={} chave={}".format(args.order_id, cstat, key))
        if args.dry_run:
            print("[dry-run] Nenhuma alteracao aplicada.")
            return
        if not args.yes:
            resposta = raw_input("Confirma a correcao dessa nota? [s/N] ")  # noqa: F821 (Python 2)
            if resposta.strip().lower() not in ("s", "sim", "y", "yes"):
                print("Cancelado pelo usuario.")
                return
        sucesso = corretor.fix_cstat(args.order_id, key, cstat)
        print("Corrigido com sucesso." if sucesso else "Falhou - ver log para detalhes.")
        return

    # Modo lote: primeiro so mostra o que tem pendente, sem gravar nada.
    pendentes = corretor.encontrar_pendentes(log_dir)
    if not pendentes:
        print("Nenhuma nota pendente de correcao de protocolo encontrada.")
        return

    print("\n{} nota(s) pendente(s) de correcao de protocolo:".format(len(pendentes)))
    for orderid, (cstat, key) in sorted(pendentes.items()):
        print("  orderid={} cstat={} chave={}".format(orderid, cstat, key))

    if args.dry_run:
        print("\n[dry-run] Nenhuma alteracao aplicada.")
        return

    if not args.yes:
        resposta = raw_input(  # noqa: F821 (Python 2)
            "\nConfirma a correcao dessas {} nota(s)? [s/N] ".format(len(pendentes))
        )
        if resposta.strip().lower() not in ("s", "sim", "y", "yes"):
            print("Cancelado pelo usuario.")
            return

    total, corrigido, falhou = corretor.corrigir_lote(log_dir, dry_run=False)
    print("\nConcluido: {} encontrada(s), {} corrigida(s), {} falhou(aram).".format(total, corrigido, falhou))
    print("Detalhes em: {}".format(os.path.abspath(LOG_FILENAME)))


if __name__ == "__main__":
    main()
