# -*- coding: utf-8 -*-
"""
Inutiliza junto a SEFAZ os numeros de NFC-e "queimados" pelo bug de dupla
alocacao em _set_fiscal_id_on_custom_property (eventhandler.py) da loja
osaka.boh.e-deploy.com.br-0001.

Reaproveita as MESMAS classes que o fiscalwrapper ja usa para inutilizar
(nfcedisabler/_NfceDisabler.py, _NfceDisablerRequestBuilder, _NfceDisablerParameters)
e o mesmo padrao de XML sintetico que o proprio codigo ja usa para numeros sem
order associada (_OrderDisabler._mount_xml_to_disable_from_order).

RODAR ISSO NA MAQUINA/AMBIENTE DA LOJA, com o Python do fiscalwrapper e o
PYTHONPATH apontando pro codigo do componente (mesmos paths do loader.cfg
Process.Arguments), por exemplo:

    "C:\\edeployPOS\\python\\python.exe" inutilizar_numeros_orfaos.py --help

Uso recomendado (CLI em lote, a partir de um missing_numbers.json ja levantado):

  1) Dry-run (NAO manda nada pra SEFAZ, so mostra o que seria enviado):
       python.exe inutilizar_numeros_orfaos.py --missing-json missing_numbers.json --bundle-dir "C:\\edeployPOS\\data\\server\\bundles\\fiscalwrapper"

  2) Depois de revisar a lista e a justificativa, roda de verdade:
       python.exe inutilizar_numeros_orfaos.py --missing-json missing_numbers.json --bundle-dir "C:\\edeployPOS\\data\\server\\bundles\\fiscalwrapper" --confirm

O script e resumivel: cada numero inutilizado com sucesso (ou legitimamente
pulado pela SEFAZ) e gravado no --state-file, e uma nova execucao pula o que
ja foi processado.

------------------------------------------------------------------------------
ADICIONADO EM 09/09/2026 - integracao com o fluxo automatico do main.py
------------------------------------------------------------------------------
Alem do CLI em lote acima (uso manual, a partir de um missing_numbers.json
levantado a mao), este arquivo agora expoe `inutilizar_nota_orfa(numero_nota)`:
a mesma logica de inutilizacao, mas para UM UNICO numero por vez, pensada para
ser chamada de dentro do fluxo automatico do main.py (consulte_csv.py) quando
uma nota do CSV do backoffice nao aparece em nenhum order.db<N> corrente NEM e
recuperada do backup (restaurar_nota, em restore_order_from_backup.py) - ou
seja, um numero "orfao" sem venda nenhuma por tras, o mesmo cenario que este
arquivo ja foi feito para tratar manualmente.

Decisoes tomadas com o usuario (09/09/2026), ver CLAUDE.md para o registro
completo:
  - Inutilizacao junto a SEFAZ e uma acao IRREVERSIVEL (diferente de
    restaurar_nota, que so mexe no banco local) - por isso consulte_csv.py
    (`_tentar_inutilizar_nota_orfa`) sempre pede confirmacao manual (raw_input,
    "[s/N]") antes de chamar `inutilizar_nota_orfa` de verdade. Isso faz
    main.py bloquear esperando resposta se aparecer uma nota orfa - aceitavel
    porque isso deveria ser raro.
  - A serie da NFC-e (exigida pela inutilizacao, mas ausente do CSV do
    backoffice, que so traz o numero) e sempre lida dinamicamente do
    loader_NFCE.cfg da propria loja (chave <key name="serie"><string>N</string></key>,
    a mesma leitura ja feita para cUF/cnpj/versao_ws/ambiente etc. em
    load_loader_config) - nunca fixa/hardcoded, pra nao errar a serie se a loja
    mudar ou se outra loja/ambiente usar uma serie diferente.
  - O caminho do codigo-fonte do proprio componente fiscalwrapper (pasta com
    nfcedisabler.py, models.py, nfcebuilder/, comp_exceptions.py, usado via
    --fiscalwrapper-src no CLI) nao aparece nos bundles de repository/ desta
    pasta conectada (repository/ so tem os arquivos que foram atualizados em
    cada patch do fix_apply.py, nao o componente inteiro) - o usuario pediu
    para assumir a mesma convencao de destino que fix_apply.py ja usa pra
    copiar bundles atualizados (repository/<versao>/update/<componente> ->
    "<app_path>\\src\\<componente>\\", ver CLAUDE.md, secao "Atualizacao de
    componentes") - ver default_fiscalwrapper_src() abaixo. CONFIRMADO em
    09/09/2026 (2) direto na instalacao real (C:\\edeploy-pos-structure) -
    loader_NFCE.cfg/nfce_urls.xml ficam exatamente em default_bundle_dir(), e
    nfcedisabler/models/comp_exceptions/etc ficam exatamente em
    default_fiscalwrapper_src() - o caminho em si estava certo.

------------------------------------------------------------------------------
ADICIONADO EM 09/09/2026 (2) - "No module named pos_model" (incidente em producao)
------------------------------------------------------------------------------
Primeira tentativa real de inutilizar_nota_orfa() em producao (nota 122611)
falhou com "Erro ao inutilizar numero 122611 (serie None): No module named
pos_model" - o "serie None" no log confirma que a falha aconteceu DENTRO de
_montar_disabler, antes da linha "serie = serie or pecas['cfg']['serie']".
Reproduzido depois numa segunda instalacao (10/09/2026) - nao era coisa de
uma loja especifica.

Investigando direto na instalacao (C:\\edeploy-pos-structure), a causa raiz e:
nfcedisabler/__init__.py (arquivo do PROPRIO fiscalwrapper, nao deste script)
importa incondicionalmente, alem das classes de baixo nivel que este arquivo
usa (NfceDisabler, NfceDisablerParameters/RequestBuilder/ResponseParser,
ProcInutNfeBuilder/Saver), duas classes que nao existiam quando esta
integracao foi escrita: OrderRepository e OrderDisabler
(_OrderRepository.py/_OrderDisabler.py) - usadas pelo fluxo "inutilizar tudo
que estiver pendente, varrendo TODOS os POS/orders" do proprio fiscalwrapper
(disparado de dentro do processo real, conectado ao msgbus, quando alguem
aciona o evento "DisableNfceOrder" - ver FixingCstatCupons.process_unused_orders
em fix_protocolo_cupons.py). Esses dois modulos, por sua vez, fazem
"from pos_model import (OrderKey, PosConnection)" e
"from posot import OrderTakerException" - modulos do SDK e-deploy que so
existem carregados DENTRO do processo real do fiscalwrapper (msgbus com lista
de POS de verdade) e que NAO existem como arquivo em lugar nenhum da
instalacao (confirmado varrendo bin/*.pypkg, src/fiscalwrapper/lib/ e
src/fiscalwrapper/src/ inteiros - nenhum tem pos_model nem posot). Como
Python executa __init__.py por INTEIRO ao importar qualquer submodulo de um
pacote, o simples "from nfcedisabler import NfceDisabler" (linha abaixo, em
_montar_disabler) ja dispara essa cadeia de import e quebra com "No module
named pos_model", mesmo esta funcao nunca usando OrderRepository/OrderDisabler.

(O script original desta pasta - xml_venda/inutilizacao/inutilizar_numeros_orfaos.py,
usado manualmente no incidente da loja osaka - faz o mesmo import e NAO
quebrava: rodou contra uma versao mais antiga do fiscalwrapper, de antes do
e-deploy adicionar _OrderRepository.py/_OrderDisabler.py ao componente. As
instalacoes testadas agora ja receberam esse patch, por isso o erro passou a
aparecer - nao e regressao desta integracao.)

Correcao: como este arquivo nunca instancia OrderRepository/OrderDisabler,
_stub_pos_model_dependencies() (abaixo) registra stubs minimos pros dois
nomes em sys.modules ANTES de importar o pacote nfcedisabler - so o
suficiente pra nfcedisabler/__init__.py rodar ate o fim (os stubs nunca sao
efetivamente usados). Ver essa funcao para mais detalhes.

A logica de montar o NfceDisabler (ler loader_NFCE.cfg/nfce_urls.xml, montar
signer/certificados) foi fatorada para `_montar_disabler`/`_criar_nfce_disabler`
e e compartilhada pelo CLI em lote (main(), abaixo) e por
`inutilizar_nota_orfa` - para nao duplicar essa logica em dois lugares (mesmo
principio ja seguido no resto desta pasta, ver fix_protocolo_cupons.py).

------------------------------------------------------------------------------
ADICIONADO EM 10/09/2026 - "cannot import name TenderType" (mesma familia do
incidente 09/09/2026 (2), mais nomes do SDK faltando)
------------------------------------------------------------------------------
Depois da correcao acima (pos_model/posot com so OrderKey/PosConnection/
OrderTakerException), a mesma nota de teste (122611) avancou e quebrou de
novo, agora com "cannot import name TenderType" - ou seja, o import chegou a
executar nfcedisabler/__init__.py ate o fim (o stub anterior resolveu isso),
mas quebrou num import SEGUINTE, ainda dentro de `from models import NfModel`
(a primeira linha depois de `_stub_pos_model_dependencies()` em
`_montar_disabler`).

Investigando de novo direto na instalacao (agora varrendo TODO o
src/fiscalwrapper/src/ - models/, services/, nfcebuilder/, comp_exceptions/,
adapter/ - nao so nfcedisabler/ como da vez anterior), o padrao se repete:
varios arquivos do PROPRIO fiscalwrapper (nao deste script) fazem imports
incondicionais de nomes do SDK que so existem dentro do processo real:

  - models/_PosTenderToNfeTender.py: "from pos_model import TenderType"
    (importado por models/__init__.py, que e o PRIMEIRO import feito por
    _montar_disabler - "from models import NfModel" - por isso o erro mudou
    de "No module named pos_model" pra "cannot import name TenderType": o
    modulo pos_model agora existe em sys.modules (por causa do stub), so que
    sem o atributo TenderType).
  - services/_TPagService.py: "from pos_model import OrderTender" (services/
    nao e importado por nada que _montar_disabler usa diretamente, mas fica
    documentado aqui pra cobrir o SDK inteiro de uma vez, ja que o objetivo
    desta rodada foi mapear TODO o grafo de imports alcancavel, nao so ir
    corrigindo erro por erro a cada teste em producao - cada teste aqui e uma
    inutilizacao de verdade, irreversivel, que exige confirmacao manual do
    operador).
  - Varrendo o restante (models/*.py completo, nfcebuilder/*.py e
    nfceutil/*.py completos, comp_exceptions/*, adapter/sqlite_adapter.py,
    utils.py): nenhum outro arquivo faz "from pos_model import ...", mas
    alguns fixture/dict-literals do proprio modelo referenciam
    (indiretamente, via outras classes do SDK que tambem so existem no
    processo real) os nomes Order, SaleItem, TaxItem, Fee e OrderParser - por
    isso o stub de pos_model abaixo cobre esses nomes tambem, de forma
    generica (ver _AnyAttrMeta), em vez de ir descobrindo um de cada vez a
    cada nova execucao em producao.
  - "old_helper" (round_half_away_from_zero, remove_punctuation,
    remove_xml_namespace, OrderTaker) e "helper" (remove_accents,
    is_valid_cnpj) sao dois outros modulos do SDK referenciados em imports
    incondicionais pela mesma familia de arquivos. Nenhum dos dois foi
    encontrado em bin/*.pypkg NESTA instalacao especifica, mas "old_helper" JA
    apareceu de verdade em edpcommon.pypkg em OUTRA instalacao (ver incidente
    de campo 28/08/2026 (2) no CLAUDE.md desta mesma pasta) - so builds Python
    2.7, e so aparece se essa loja tiver edpcommon.pypkg (nem toda instalacao
    tem). Ja "helper" EXISTE de verdade em src/fiscalwrapper/lib/helper.py
    (junto com as libs vendorizadas cryptography/lxml/signxml/requests que
    NfeSigner/XmlEnveloper usam de verdade). Por isso a correcao adiciona
    "lib" ao sys.path (ver _montar_disabler) e os DOIS (old_helper e helper)
    so caem no stub se o import real, tentado primeiro, falhar - nunca
    stubados incondicionalmente feito pos_model/posot (que nunca existem como
    arquivo em nenhuma instalacao testada ate agora).

Confirmado (lendo o codigo-fonte de cada classe, nao so os imports) que as
classes que ESTE arquivo de fato instancia/chama -
NfceDisabler/NfceDisablerParameters/NfceDisablerRequestBuilder/
NfceDisablerResponseParser/ProcInutNfeBuilder/ProcInutNfeSaver - nao dependem
de pos_model/posot/old_helper/helper para nada alem de constantes/tipos que
nunca sao de fato comparados/usados por este fluxo (so pelo fluxo "varrer
todos os POS", que este arquivo nunca aciona) - continua seguro stubar todos
os quatro.

Correcao: `_stub_pos_model_dependencies()` foi expandida para registrar,
alem de pos_model/posot, tambem old_helper e helper (este ultimo so como
fallback, ver acima) - usando um stub generico "AnyAttr" (classe cujo
QUALQUER atributo, ex: TenderType.cash, devolve um valor sentinela) pros
nomes que funcionam como enum/constante, em vez de listar cada valor
manualmente. `_montar_disabler` tambem passou a adicionar
"<fiscalwrapper_src>/../lib" ao sys.path, pra que helper.py e as libs
vendorizadas resolvam de verdade quando existirem (correcao real, nao stub).

------------------------------------------------------------------------------
ADICIONADO EM 10/09/2026 (2) - "No module named modelcommon.model" - de
mapear nome por nome para um finder generico
------------------------------------------------------------------------------
Depois da correcao acima, a mesma nota de teste (122611) avancou e quebrou
DE NOVO, com "No module named modelcommon.model" - o terceiro incidente
consecutivo desta familia (pos_model/posot -> TenderType/old_helper/helper ->
agora modelcommon.model). Investigando (varredura de TODOS os
"from X import"/"import X" em src/fiscalwrapper/src/ inteiro, nao so os
arquivos ja mapeados), ficou claro que o problema nao tem fim natural: a
arvore de imports alcancavel a partir de nfcedisabler/__init__.py (que
precisa rodar por INTEIRO so pra pegar as poucas classes que este arquivo usa
de verdade) e MUITO maior do que as duas rodadas anteriores cobriram -
_OrderDisabler.py (ja stubado por causa de pos_model/posot/old_helper) faz
"from services import OrderService", o que forca TODO o pacote services/ a
rodar, que por sua vez importa "common" (outro pacote, com
"modelcommon.fiscalwrapper" dentro), "repository", "fiscalpersistence",
"cfgtools", "pem" - alguns desses sao modulos do SDK e-deploy que so existem
no processo real (feito pos_model/posot), outros existem de verdade mas em
lugares que este script nao necessariamente tem no sys.path (feito
old_helper/helper). Continuar mapeando manualmente cada nome que aparece a
cada nova rodada de teste em producao (cada teste = uma inutilizacao real e
irreversivel) nao escala - e nada garante que nao apareceria um quarto, quinto
incidente com mais nomes ainda.

**Correcao definitiva**: em vez de listar nomes um por um, foi criado
`_AutoStubImportFinder` - um finder de import (`sys.meta_path`) instalado SO
durante a janela de `_importar_modulos_fiscalwrapper()` (nova funcao que
concentra os imports do proprio fiscalwrapper, chamada por `_montar_disabler`)
e removido logo depois, sucesso ou falha. Ele tenta o import de verdade
primeiro (via `__import__`, que passa por zipimport - cobre modulos dentro de
.pypkg, ao contrario de so checar arquivos em disco) e SO stuba
automaticamente (com uma classe generica "AnyAttr", via `_AutoStubModule`) se
esse import de verdade falhar - qualquer nome do SDK e-deploy que falte,
conhecido ou nao, passa a ser coberto sem precisar de mais uma rodada de
mapeamento manual. Suporta nomes com ponto (ex: "modelcommon.model") ao
registrar o pacote-pai como stub tambem, com o filho pendurado nele.

Dois cuidados importantes pra isso ser seguro:
- O finder so intercepta um nome DEPOIS que a tentativa de import real
  falhar - nunca compete com um modulo genuino (ex: se `old_helper` estiver
  resolvivel via `edpcommon.pypkg` no sys.path, o modulo real e usado, nao o
  stub - mesmo comportamento de antes, so que generalizado).
- `_NUNCA_STUBAR_IMPORT` (lista curta e explicita: iso8601, cryptography,
  lxml, signxml, requests) marca os poucos modulos que este fluxo usa DE
  VERDADE em tempo de execucao (nao so em definicao de classe/import) -
  `_ProcInutNfeSaver.save_proc_inut_nfe_xml` (chamado de verdade por este
  fluxo) usa `iso8601` pra parsear datas de verdade, e `NfeSigner`/
  `XmlEnveloper`/`NfceDisabler` usam `cryptography`/`lxml`/`signxml`/
  `requests` pra assinar XML e falar com a SEFAZ de verdade - stubar
  qualquer um desses silenciosamente produziria um comportamento ERRADO em
  vez de um erro claro (pior do que travar). Esses nomes NUNCA sao
  interceptados pelo finder - se realmente faltarem, o ImportError sobe
  normalmente, sinalizando um problema real de instalacao.

Cada nome efetivamente stubado numa execucao fica logado (`logger.warning`,
dentro de `_importar_modulos_fiscalwrapper`) - nunca silencioso, pra dar
visibilidade em produção do que foi coberto automaticamente.

`_stub_pos_model_dependencies()`, `_register_stub_module()` e as listas
manuais de atributos por modulo (pos_model/posot/old_helper/helper) foram
REMOVIDAS - o finder generico cobre os mesmos casos (e os que ainda nao
apareceram) sem precisar delas.
"""

import argparse
import json
import logging
import os
import sys
import time
import traceback
import types as _types
from datetime import datetime
from xml.etree import cElementTree as eTree

logger = logging.getLogger("InutilizarNumerosOrfaos")

# cUF (codigo IBGE da UF) -> sigla, so o necessario pra achar a <estado> certa
# em nfce_urls.xml. Ajuste/complete se a loja nao for SP.
CUF_TO_UF = {
    "35": "SP",
    "33": "RJ",
    "31": "MG",
    "41": "PR",
    "43": "RS",
    "42": "SC",
    "29": "BA",
}

def default_bundle_dir(app_path):
    # type: (str) -> str
    """
    Mesmo caminho que FixingCstatCupons (fix_protocolo_cupons.py) ja usa pra achar
    loader_NFCE.cfg - ver self.nfce_loader em FixingCstatCupons.__init__.
    """
    return os.path.join(app_path, "data", "server", "bundles", "fiscalwrapper")


def default_fiscalwrapper_src(app_path):
    # type: (str) -> str
    """
    Convencao (ainda nao confirmada numa instalacao real - ver nota no topo do arquivo) de onde
    fica o codigo-fonte do proprio componente fiscalwrapper (pasta com nfcedisabler.py, models.py,
    nfcebuilder/, comp_exceptions.py): o mesmo destino que fix_apply.py ja usa pra copiar bundles
    atualizados de repository/<versao>/update/<componente> nesta instalacao.
    """
    return os.path.join(app_path, "src", "fiscalwrapper", "src")


def find_key_text(root, key_name):
    # type: (eTree.Element, str) -> str
    node = root.find(".//key[@name='{}']".format(key_name))
    if node is None:
        raise RuntimeError("Chave '{}' nao encontrada no loader.cfg".format(key_name))
    value_node = list(node)[0]
    return value_node.text


def load_loader_config(loader_cfg_path):
    # type: (str) -> dict
    root = eTree.parse(loader_cfg_path).getroot()
    return {
        "cUF": find_key_text(root, "cUF"),
        "cnpj": find_key_text(root, "CnpjContribuinte"),
        "versao_ws": find_key_text(root, "versao_ws"),
        "ambiente": find_key_text(root, "ambiente"),
        # Serie atual da loja (<key name="serie"><string>N</string></key> no loader_NFCE.cfg) -
        # usada por inutilizar_nota_orfa() pra sempre inutilizar na serie certa, em vez de um
        # valor fixo/hardcoded (ver nota no topo do arquivo, decisao de 09/09/2026).
        "serie": find_key_text(root, "serie"),
        "certificate_key_path": find_key_text(root, "certificate_key_path"),
        "certificate_path": find_key_text(root, "certificate_path"),
        "sefaz_certificate_path": find_key_text(root, "sefaz_certificate_path"),
        "justificativa_inutilizacao": find_key_text(root, "justificativa_inutilizacao"),
    }


def load_url_inutilizacao(nfce_urls_path, cuf, versao_ws, ambiente):
    # type: (str, str, str, str) -> str
    uf = CUF_TO_UF.get(cuf)
    if uf is None:
        raise RuntimeError(
            "cUF={} nao mapeado em CUF_TO_UF - complete a tabela pra essa loja".format(cuf)
        )
    root = eTree.parse(nfce_urls_path).getroot()
    state = root.find("estado[@uf='{}']".format(uf))
    if state is None:
        raise RuntimeError("UF '{}' nao encontrada em {}".format(uf, nfce_urls_path))
    version = state.find("versao[@ws='{}'][@ambiente='{}']".format(versao_ws, ambiente))
    if version is None:
        raise RuntimeError(
            "versao ws={} ambiente={} nao encontrada pra UF {}".format(versao_ws, ambiente, uf)
        )
    for url in version:
        if url.tag == "url_inutilizacao":
            return url.text.strip()
    raise RuntimeError("url_inutilizacao nao encontrada em {}".format(nfce_urls_path))


def build_synthetic_order_xml(mod, nnf, dh_emi):
    # type: (int, int, str) -> eTree.Element
    xml = (
        "<NFe xmlns=\"http://www.portalfiscal.inf.br/nfe\">"
        "<infNFe>"
        "<ide>"
        "<mod>{0}</mod>"
        "<nNF>{1}</nNF>"
        "<dhEmi>{2}</dhEmi>"
        "</ide>"
        "</infNFe>"
        "</NFe>"
    ).format(mod, nnf, dh_emi)
    return eTree.XML(xml)


def load_state(state_file_path):
    # type: (str) -> dict
    if not os.path.exists(state_file_path):
        return {}
    with open(state_file_path, "r") as f:
        return json.load(f)


def save_state(state_file_path, state):
    # type: (str, dict) -> None
    with open(state_file_path, "w") as f:
        json.dump(state, f, indent=2)


# State file usado por inutilizar_nota_orfa() (uso automatico, uma nota por vez, chamado por
# consulte_csv.py) - mesmo mecanismo de resumibilidade que o CLI em lote (main(), abaixo) ja usa
# via --state-file, so que com um caminho fixo (nao um por --missing-json) e chave mais simples
# (so o numero da nota, sem serie - ver nota_ja_processada abaixo).
#
# Caminho ABSOLUTO, baseado na pasta deste proprio arquivo (__file__) - NAO um caminho relativo
# tipo "system_script.log" (que main.py usa, confiando que o cwd no INICIO da execucao e a pasta
# find_xml). Isso importa porque o cwd muda DURANTE a execucao do main.py por efeito colateral de
# outras funcoes (find_fiscal_id faz os.chdir; FixingCstatCupons.application_conn faz
# os.chdir(BINPATH) e nunca desfaz de propósito - ver incidente de campo de 31/08/2026 (6) no
# CLAUDE.md) - um caminho relativo aqui gravaria (ou procuraria) o arquivo de estado na pasta
# errada dependendo de quando essa funcao roda dentro do fluxo.
def default_state_file():
    # type: () -> str
    return os.path.join(os.path.dirname(os.path.abspath(__file__)), "inutilizacao_notas_orfas.state.json")


def nota_ja_processada(numero_nota, state_file=None):
    # type: (int, str) -> bool
    """
    True se numero_nota já tem um resultado TERMINAL gravado no state file (inutilizada de
    verdade, pulada pela própria SEFAZ, ou erro permanente) - ver inutilizar_nota_orfa() para
    quais desfechos contam como terminais. Usado por consulte_csv.py
    (_tentar_inutilizar_nota_orfa) para nem pedir confirmação de novo ao operador quando a nota já
    foi resolvida numa execução anterior do main.py.
    """
    state = load_state(state_file or default_state_file())
    return str(numero_nota) in state


class _AnyAttrMeta(type):
    """
    Metaclasse que faz QUALQUER acesso a atributo de classe nao definido explicitamente (ex:
    TenderType.cash, OrderTender.dynamic_pix) devolver um valor sentinela generico, em vez de
    levantar AttributeError. Usada para stubar classes do SDK e-deploy que na pratica funcionam
    como "bag" de constantes/enum informal (TenderType, OrderTender, etc.) - este arquivo nunca
    compara nem usa o VALOR de nenhuma dessas constantes, so precisa que o import e a definicao
    de classes/dicts do modulo REAL (nfcedisabler, models, services, e o que mais estiver na
    mesma arvore de imports) nao quebrem ao referenciar esses nomes. Ver "ADICIONADO EM
    10/09/2026 (2)" no topo do arquivo.

    Cada (classe, nome) recebe seu PROPRIO sentinela (guardado em _sentinels), nao um unico
    valor compartilhado - assim, se algum codigo real algum dia comparar dois desses valores
    entre si (coisa que o fluxo deste arquivo nao faz), "TenderType.cash == TenderType.cash"
    continua True e "TenderType.cash == TenderType.credit" continua False.
    """
    _sentinels = {}

    def __getattr__(cls, name):
        key = (cls, name)
        if key not in _AnyAttrMeta._sentinels:
            _AnyAttrMeta._sentinels[key] = object()
        return _AnyAttrMeta._sentinels[key]


def _make_any_attr_class(name):
    # type: (str) -> type
    """
    Classe generica que aceita QUALQUER construtor (`Classe(a, b, x=1)` nunca levanta
    TypeError - precisa disso porque alguns nomes do SDK stubado (ex: pos_model.OrderKey/
    PosConnection) sao de fato instanciados com argumentos posicionais em codigo que so existe
    pra DEFINIR classes/funcoes deste arquivo nunca chama, nao pra executa-los de verdade) e
    responde a QUALQUER atributo de classe (via _AnyAttrMeta, pros casos tipo enum/constante).
    """
    def _init(self, *args, **kwargs):
        pass

    return _AnyAttrMeta(str(name), (object,), {"__init__": _init})


class _AutoStubModule(_types.ModuleType):
    """
    "Modulo" stub devolvido por _AutoStubImportFinder pra um nome de import que nao resolveu de
    verdade. Qualquer atributo acessado nele que nao tenha sido setado explicitamente (ex: um
    submodulo dotted registrado por load_module) devolve uma classe genérica via
    _make_any_attr_class - o suficiente pra "from modulo_fake import QualquerCoisa" ou
    "modulo_fake.QualquerCoisa" nao quebrarem, sem precisar listar os nomes um por um.
    """
    def __getattr__(self, name):
        if name.startswith("__") and name.endswith("__"):
            raise AttributeError(name)
        return _make_any_attr_class(name)


# Nomes de modulo TOP-LEVEL que este script precisa que resolvam DE VERDADE, mesmo com
# _AutoStubImportFinder instalado - nunca stubados, porque sao efetivamente USADOS em tempo de
# execucao pelas classes que este arquivo de fato instancia/chama (NfceDisabler e colaboradores),
# nao so referenciados em import/definicao de classe: "iso8601" (parsing de data em
# ProcInutNfeSaver.save_proc_inut_nfe_xml - ver item de divida tecnica "iso8601" no CLAUDE.md/
# projeto), "cryptography"/"lxml"/"signxml"/"requests"/"OpenSSL" (assinatura XML/HTTP em
# NfeSigner/XmlEnveloper/NfceDisabler, vendorizados em src/fiscalwrapper/lib/ - "OpenSSL"
# adicionado em 10/09/2026 (3) depois de aparecer stubado em producao como
# "nfcebuilder.nfceutil.OpenSSL", exatamente a mesma familia de risco). "sqlalchemy" adicionado em
# 10/09/2026 (5): depois que o finder parou de mascarar `adapter.sqlite_adapter` (um modulo REAL,
# usado de verdade pelo NfceDisabler, que importa sqlalchemy pra valer), apareceram
# "sqlalchemy.cprocessors"/"cresultproxy"/"cutils" (submodulos C opcionais - o proprio sqlalchemy
# ja faz try/except ImportError em volta deles e cai pra uma versao pura Python quando faltam)
# sendo stubados por engano com classes fake - em vez de deixar o ImportError real subir e o
# fallback do proprio sqlalchemy funcionar, o finder devolvia um stand-in fake, que o sqlalchemy
# passou a usar como se fosse o processor/resultproxy de verdade - contribuiu para (ou causou) o
# erro "Type <class 'sqlalchemy.engine.interfaces.Connectable'> is already registered". sqlalchemy
# e uma biblioteca de verdade, usada de verdade pelo adapter - nenhum submodulo dela deve ser
# mascarado, mesmo que pareca "so faltando um acelerador C". Se algum desses nomes realmente
# faltar na instalacao, o ImportError deve continuar subindo sem ser mascarado - e um problema de
# instalacao incompleta, nao um nome do SDK so usado em tempo de import.
#
# ADICIONADO EM 10/09/2026 (6): mesma familia de bug encontrada de novo, dessa vez com
# "fcntl"/"termios" (via `adapter.sqlite_adapter` -> `alembic` -> `alembic.util.messaging`, puxado
# so porque `_DetFeeBuilder` (nfcebuilder) importa `services.FeeService`, que puxa toda a cadeia
# services/repository/adapter/alembic - nada disso e efetivamente usado pela inutilizacao, so
# carregado de carona). O codigo real do alembic (confirmado lendo o pacote de verdade) faz:
#   try:
#       import fcntl, termios, struct
#       ioctl = fcntl.ioctl(0, termios.TIOCGWINSZ, struct.pack("HHHH", 0, 0, 0, 0))
#       _h, TERMWIDTH, _hp, _wp = struct.unpack("HHHH", ioctl)
#   except (ImportError, OSError):
#       TERMWIDTH = None
# so pra descobrir a largura do terminal (cosmetico, irrelevante pra nos). "fcntl"/"termios" nao
# existem no Windows DE VERDADE (sao modulos so-Unix) - o proprio alembic ja trata isso certinho
# via except ImportError. Mas o finder, ao inves de deixar o ImportError real acontecer, criava
# stubs fake pra "fcntl"/"termios"; o import passava (sem ImportError!), e ai
# `fcntl.ioctl(...)` (uma classe fake, chamavel, que so devolve uma instancia fake) virava o
# argumento de `struct.unpack`, que espera bytes de verdade - daí o erro real que apareceu em
# producao: "unpack requires a string argument of length 8" (um struct.error, que o
# "except (ImportError, OSError)" do alembic nao pega, porque nao e nenhum dos dois).
#
# CONCLUSAO/PRINCIPIO GERAL (pra nao continuar corrigindo um nome por vez a cada incidente): modulos
# de baixo nivel, especificos de UM sistema operacional, que bibliotecas bem escritas (alembic,
# sqlalchemy, etc.) ja esperam que possam faltar e ja tratam com try/except - nunca devem ser
# mascarados pelo finder. A lista abaixo cobre esses (fcntl/termios/tty/pty - so Unix;
# msvcrt/winreg/_winreg - so Windows; resource/grp/pwd/curses - so Unix) alem das bibliotecas
# usadas de verdade por este fluxo. Se algum desses realmente faltar na instalacao, o ImportError
# deve continuar subindo sem ser mascarado - e normal, a propria biblioteca que os usa ja sabe lidar
# com a ausencia, o problema era so o finder fingir que eles existiam.
_NUNCA_STUBAR_IMPORT = frozenset([
    "iso8601",
    "cryptography",
    "lxml",
    "signxml",
    "requests",
    "OpenSSL",
    "sqlalchemy",
    "alembic",
    "fcntl",
    "termios",
    "tty",
    "pty",
    "msvcrt",
    "winreg",
    "_winreg",
    "resource",
    "grp",
    "pwd",
    "curses",
])


class _AutoStubImportFinder(object):
    """
    sys.meta_path finder instalado (e removido logo em seguida) so durante a janela de import
    dos modulos do proprio fiscalwrapper, dentro de _importar_modulos_fiscalwrapper() - ver
    "ADICIONADO EM 10/09/2026 (2)" no topo do arquivo pro raciocinio completo por tras disso.

    Substitui a abordagem anterior de listar manualmente cada nome do SDK e-deploy que falta
    (pos_model, posot, old_helper, helper, e agora modelcommon.model - 3 incidentes reais em
    producao seguidos, cada um achando mais um nome faltando numa arvore de imports que so
    cresce - nfcedisabler puxa OrderRepository/OrderDisabler, que puxam TODO o pacote services,
    que por sua vez puxa common/repository/fiscalpersistence/etc.). Em vez de continuar mapeando
    nome por nome a cada nova rodada de teste em producao (uma acao real e irreversivel cada
    vez), este finder resolve a familia inteira de uma vez: qualquer nome de modulo que os
    mecanismos normais de import (stdlib, sys.path, .pypkg/zip) NAO consigam resolver recebe
    automaticamente um stub generico (_AutoStubModule) - o suficiente pra qualquer
    import/definicao de classe do proprio fiscalwrapper conseguir rodar, mesmo referenciando um
    nome do SDK que so existe carregado dentro do processo real (msgbus com POS de verdade).

    So intercepta um nome depois de tentar o import de VERDADE primeiro (via `__import__`, que
    passa inclusive por zipimport - cobre modulos dentro de .pypkg, diferente de checar so o
    sistema de arquivos) - se isso funcionar, o modulo real e usado, nunca o stub. Um guard de
    reentrancia (self._checking) evita que essa tentativa de import real acabe chamando este
    mesmo finder de novo pro mesmo nome (recursao infinita), permitindo ainda que OUTROS
    finders/mecanismos normais resolvam de verdade durante essa tentativa. Nomes em
    _NUNCA_STUBAR_IMPORT nunca sao interceptados, mesmo que a tentativa de import real falhe -
    o ImportError sobe normalmente pra esses (ver comentario da constante).

    Cada nome efetivamente stubado fica registrado em self.stubbed_names, pra
    _importar_modulos_fiscalwrapper() logar isso (nunca silencioso) depois de importar.
    """

    def __init__(self):
        self.stubbed_names = []
        self._checking = set()

    def _resolves_for_real(self, name):
        # type: (str) -> bool
        """
        True se "name" resolve de verdade via o mecanismo de import padrao (stdlib, sys.path,
        dentro de .pypkg via zipimport) - importa de verdade pra descobrir (efeito colateral
        aceitavel: se resolver, e exatamente o modulo real que queremos usar mesmo, entao ja
        fica pronto em sys.modules). Guard de reentrancia (self._checking) evita que esta
        tentativa acabe chamando find_module de novo pro MESMO nome (recursao infinita),
        permitindo que outros finders/mecanismos normais resolvam de verdade nesse meio tempo.
        """
        if name in sys.modules:
            return True
        if name in self._checking:
            return False
        self._checking.add(name)
        try:
            __import__(name)
            return True
        except ImportError:
            return False
        finally:
            self._checking.discard(name)

    def find_module(self, fullname, path=None):
        # type: (str, list) -> object
        if fullname in sys.modules or fullname in self._checking:
            return None

        parts = fullname.split(".")

        # Nunca interceptamos se "fullname" (ou QUALQUER componente dele, nao so o primeiro -
        # ver o loop de sufixos mais abaixo, que e exatamente onde um nome de
        # _NUNCA_STUBAR_IMPORT pode aparecer no MEIO do nome, ex: "nfcedisabler.iso8601") tocar
        # um nome da lista - o ImportError de verdade deve subir pra esses, nunca ser mascarado
        # por um stub, mesmo vindo de uma variante prefixada.
        if any(part in _NUNCA_STUBAR_IMPORT for part in parts):
            return None

        if self._resolves_for_real(fullname):
            return None

        # ADICIONADO EM 10/09/2026 (3) - ver o incidente correspondente no topo do arquivo:
        # Python 2 (sem "from __future__ import absolute_import" no arquivo que esta
        # importando) tenta, pra QUALQUER import feito de dentro de um pacote, uma variante
        # "relativa" primeiro - o pacote atual (que pode ter varios niveis, ex:
        # "nfcebuilder.nfceutil") prefixado ao nome como escrito no codigo (ex: "OpenSSL",
        # "xml.etree", "modelcommon.model", "logging", "requests") - e so tenta o nome absoluto
        # (sem esse prefixo) DEPOIS que a tentativa relativa falha. "fullname" aqui pode ser
        # exatamente essa tentativa relativa (ex: "nfcebuilder.nfceutil.OpenSSL",
        # "nfcedisabler.logging", "nfcedisabler.requests"). Se QUALQUER sufixo dele (cortando 1,
        # 2, ... componentes do inicio) resolver de verdade como import absoluto, existe um
        # modulo real por tras (stdlib ou de terceiros - OpenSSL, xml.etree, requests, logging,
        # os, time, datetime, base64, enum, etc.) e NAO devemos reivindicar esta variante
        # prefixada - devolvendo None aqui, o mecanismo normal do Python cai pro nome absoluto,
        # que resolve sozinho (sem precisar deste finder pra nada). SEM essa checagem de
        # sufixo, modulos reais simplesmente sendo importados de DENTRO de um pacote do
        # fiscalwrapper (ex: "nfcedisabler.logging", "nfcebuilder.xml.etree",
        # "nfcedisabler.requests", "models.enum") eram stubados por engano - inclusive "enum"
        # (usado por classes reais do proprio fiscalwrapper, ex: NfceCstatCode) virando um stub
        # fake quebrou o `.value` desses membros, causando "'int' object has no attribute
        # 'value'" mais adiante - um bug real de comportamento, nao so um ImportError.
        for i in range(1, len(parts)):
            if self._resolves_for_real(".".join(parts[i:])):
                return None

        return self

    def load_module(self, fullname):
        # type: (str) -> object
        if fullname in sys.modules:
            return sys.modules[fullname]

        parts = fullname.split(".")
        parent_name = ".".join(parts[:-1])
        leaf_name = parts[-1]

        module = _AutoStubModule(fullname)
        module.__file__ = "<auto-stub:{0}>".format(fullname)
        module.__loader__ = self
        module.__path__ = []  # trata como pacote, pra um proximo nivel dotted tambem resolver
        sys.modules[fullname] = module

        if parent_name:
            parent_module = sys.modules.get(parent_name) or self.load_module(parent_name)
            setattr(parent_module, leaf_name, module)

        self.stubbed_names.append(fullname)
        return module


def _importar_modulos_fiscalwrapper():
    # type: () -> tuple
    """
    Importa os modulos/classes do proprio componente fiscalwrapper usados por _montar_disabler,
    com _AutoStubImportFinder instalado SO durante esta janela (removido no finally, sucesso ou
    falha) - nunca fica ativo pro resto do processo, pra nao mascarar um ImportError genuino em
    outra parte do script. Ver "ADICIONADO EM 10/09/2026 (2)" no topo do arquivo.
    """
    finder = _AutoStubImportFinder()
    sys.meta_path.append(finder)
    try:
        from models import NfModel
        from nfcebuilder.nfceutil import NfceRequest, NfeSigner, XmlEnveloper
        from nfcedisabler import NfceDisabler
        from nfcedisabler._NfceDisablerParameters import NfceDisablerParameters
        from nfcedisabler._NfceDisablerRequestBuilder import NfceDisablerRequestBuilder
        from nfcedisabler._NfceDisablerResponseParser import NfceDisablerResponseParser
        from nfcedisabler._ProcInutNfeBuilder import ProcInutNfeBuilder
        from nfcedisabler._ProcInutNfeSaver import ProcInutNfeSaver
        from comp_exceptions import (
            FiscalInutilizationRetryableError,
            FiscalInutilizationPermanentError,
            FiscalSkippableWarning,
        )
    finally:
        try:
            sys.meta_path.remove(finder)
        except ValueError:
            pass
        if finder.stubbed_names:
            logger.warning(
                "Modulos do SDK e-deploy stubados automaticamente (nao resolvidos de verdade, "
                "nunca efetivamente usados por este fluxo de inutilizacao): %s",
                ", ".join(sorted(set(finder.stubbed_names))),
            )

    return (
        NfModel, NfceRequest, NfeSigner, XmlEnveloper, NfceDisabler,
        NfceDisablerParameters, NfceDisablerRequestBuilder, NfceDisablerResponseParser,
        ProcInutNfeBuilder, ProcInutNfeSaver,
        FiscalInutilizationRetryableError, FiscalInutilizationPermanentError,
        FiscalSkippableWarning,
    )


def _montar_disabler(bundle_dir, fiscalwrapper_src=None, justificativa_override=None):
    # type: (str, str, str) -> dict
    """
    Monta as pecas necessarias pra inutilizar numeros junto a SEFAZ (signer, enveloper, request,
    builders, e as classes de excecao do proprio fiscalwrapper) a partir da config da loja
    (loader_NFCE.cfg + nfce_urls.xml em bundle_dir). Compartilhado pelo CLI em lote (main(),
    abaixo) e por inutilizar_nota_orfa() - pra nao duplicar essa logica em dois lugares.

    So insere fiscalwrapper_src em sys.path (e importa os modulos do proprio componente) na hora
    de chamar esta funcao - nao no topo do arquivo - assim, so importar este modulo (ex:
    "from inutilizar_numeros_orfaos import inutilizar_nota_orfa", feito por consulte_csv.py) fica
    seguro em qualquer instalacao, mesmo sem o fiscalwrapper disponivel.

    Levanta a mesma excecao que a config/certificado/URL levantarem se algo estiver errado -
    quem chama decide como tratar (ver inutilizar_nota_orfa, que captura e devolve
    (False, mensagem) em vez de propagar).
    """
    if fiscalwrapper_src and fiscalwrapper_src not in sys.path:
        sys.path.insert(0, fiscalwrapper_src)

    # "lib" fica ao LADO de "src" (nao dentro) - tem o helper.py real e as libs de terceiros
    # vendorizadas (cryptography, lxml, signxml, requests) que NfeSigner/XmlEnveloper usam de
    # verdade em tempo de execucao. Ver "ADICIONADO EM 10/09/2026" no topo do arquivo. Precisa
    # ser adicionado ANTES de _importar_modulos_fiscalwrapper() logo abaixo, pra "helper"
    # conseguir resolver de verdade (o _AutoStubImportFinder so cai pro stub se o import real
    # falhar).
    if fiscalwrapper_src:
        fiscalwrapper_lib = os.path.join(os.path.dirname(fiscalwrapper_src), "lib")
        if os.path.isdir(fiscalwrapper_lib) and fiscalwrapper_lib not in sys.path:
            sys.path.insert(0, fiscalwrapper_lib)

    # Ver "ADICIONADO EM 09/09/2026 (2)" e "ADICIONADO EM 10/09/2026 (2)" no topo do arquivo -
    # importa os modulos/classes do proprio fiscalwrapper com _AutoStubImportFinder instalado,
    # que stuba automaticamente qualquer nome do SDK e-deploy que nao resolva de verdade (em vez
    # de mapear cada nome manualmente a cada nova rodada de teste em producao).
    (
        NfModel, NfceRequest, NfeSigner, XmlEnveloper, NfceDisabler,
        NfceDisablerParameters, NfceDisablerRequestBuilder, NfceDisablerResponseParser,
        ProcInutNfeBuilder, ProcInutNfeSaver,
        FiscalInutilizationRetryableError, FiscalInutilizationPermanentError,
        FiscalSkippableWarning,
    ) = _importar_modulos_fiscalwrapper()

    loader_cfg_path = os.path.join(bundle_dir, "loader_NFCE.cfg")
    nfce_urls_path = os.path.join(bundle_dir, "nfce_urls.xml")

    cfg = load_loader_config(loader_cfg_path)
    justificativa = justificativa_override or cfg["justificativa_inutilizacao"]
    if len(justificativa) < 15:
        raise RuntimeError(
            "Justificativa precisa ter pelo menos 15 caracteres (SEFAZ exige): {!r}".format(justificativa))

    url_inutilizacao = load_url_inutilizacao(
        nfce_urls_path=nfce_urls_path,
        cuf=cfg["cUF"],
        versao_ws=cfg["versao_ws"],
        ambiente=cfg["ambiente"],
    )

    key_path = os.path.join(bundle_dir, cfg["certificate_key_path"])
    cert_path = os.path.join(bundle_dir, cfg["certificate_path"])
    sefaz_cert_path = os.path.join(bundle_dir, cfg["sefaz_certificate_path"])

    return {
        "cfg": cfg,
        "justificativa": justificativa,
        "url_inutilizacao": url_inutilizacao,
        "nfe_signer": NfeSigner(key_path, cert_path),
        "xml_enveloper": XmlEnveloper(cfg["cUF"]),
        "nfce_request": NfceRequest(
            certificate_key_path=key_path,
            certificate_path=cert_path,
            sefaz_certificate_path=sefaz_cert_path,
            check_situation_timeout=60,
        ),
        "proc_inut_nfe_builder": ProcInutNfeBuilder(),
        "proc_inut_nfe_saver": ProcInutNfeSaver(xmls_base_path=os.path.join(bundle_dir, "InutilizacaoManual")),
        "response_parser": NfceDisablerResponseParser(int(cfg["versao_ws"])),
        "NfModel": NfModel,
        "NfceDisablerParameters": NfceDisablerParameters,
        "NfceDisablerRequestBuilder": NfceDisablerRequestBuilder,
        "NfceDisabler": NfceDisabler,
        "FiscalInutilizationRetryableError": FiscalInutilizationRetryableError,
        "FiscalInutilizationPermanentError": FiscalInutilizationPermanentError,
        "FiscalSkippableWarning": FiscalSkippableWarning,
    }


def _criar_nfce_disabler(pecas, serie):
    # type: (dict, str) -> tuple
    """Monta um NfceDisabler para uma serie especifica, a partir das pecas de _montar_disabler."""
    disabler_parameters = pecas["NfceDisablerParameters"](
        initial_order_id=0,
        tp_amb=pecas["cfg"]["ambiente"],
        c_uf=pecas["cfg"]["cUF"],
        cnpj=pecas["cfg"]["cnpj"],
        serie=serie,
        justificativa=pecas["justificativa"],
    )
    request_builder = pecas["NfceDisablerRequestBuilder"](
        disabler_parameters=disabler_parameters,
        nfce_signer=pecas["nfe_signer"],
        xml_enveloper=pecas["xml_enveloper"],
        versao_ws=int(pecas["cfg"]["versao_ws"]),
    )
    nfce_disabler = pecas["NfceDisabler"](
        nfce_disabler_request_builder=request_builder,
        nfce_disabler_response_parser=pecas["response_parser"],
        nfce_request=pecas["nfce_request"],
        url_inutilizacao=pecas["url_inutilizacao"],
        proc_inut_nfe_builder=pecas["proc_inut_nfe_builder"],
        proc_inut_nfe_saver=pecas["proc_inut_nfe_saver"],
        versao_ws=int(pecas["cfg"]["versao_ws"]),
        nfe_url_disabler=pecas["url_inutilizacao"],
    )
    return nfce_disabler, request_builder


def inutilizar_nota_orfa(
    numero_nota,                    # type: int
    serie=None,                     # type: str
    app_path=None,                  # type: str
    bundle_dir=None,                # type: str
    fiscalwrapper_src=None,         # type: str
    justificativa=None,             # type: str
    confirm=True,                   # type: bool
    state_file=None,                # type: str
):
    # type: (...) -> (bool, str)
    """
    Inutiliza junto a SEFAZ um UNICO numero de NFC-e "orfao" (numero do CSV do backoffice que
    nao apareceu em nenhum order.db<N> nem foi recuperado do backup) - versao "uma nota por vez"
    da logica em lote deste arquivo (que parte de missing_numbers.json). Reaproveita as mesmas
    classes que o fiscalwrapper ja usa para inutilizar (NfceDisabler e afins) e o mesmo XML
    sintetico (build_synthetic_order_xml).

    Chamada por consulte_csv.py (_tentar_inutilizar_nota_orfa), so depois que o operador confirma
    manualmente (raw_input) - ver nota no topo deste arquivo sobre essa decisao (inutilizacao e
    irreversivel junto a SEFAZ, diferente de restaurar_nota).

    serie: se None (padrao), le a serie atual direto do loader_NFCE.cfg da loja
    (cfg["serie"], preenchido por load_loader_config a partir de
    <key name="serie"><string>N</string></key>) - nunca fixa/hardcoded (decisao do usuario,
    09/09/2026). So passe um valor explicito aqui pra sobrescrever isso (ex: reprocessar uma nota
    antiga de uma serie que ja mudou).
    app_path: raiz da instalacao (mesma que get_system_version() de consulte_csv.py ja detecta) -
    se nao for passado, importa e chama get_system_version() (import atrasado, so nesta funcao,
    pra nao criar import circular com consulte_csv.py, que importa este arquivo no topo).
    bundle_dir/fiscalwrapper_src: se nao passados, usam as convencoes default_bundle_dir()/
    default_fiscalwrapper_src() acima.
    confirm=False faz um dry-run (monta a requisicao mas nao manda pra SEFAZ) - por simetria com
    o --confirm do CLI em lote abaixo; quem decide se chama esta funcao ou nao ja e
    consulte_csv.py (via confirmacao do operador), entao o padrao aqui e confirm=True.

    PERSISTENCIA/IDEMPOTENCIA (09/09/2026): a inutilizacao em si nao grava nada em
    fiscal_persistcomp.db nem em order.db<N> - nao existe order nenhuma pra essas tabelas
    associarem a um numero "orfao" (so o proprio ProcInutNfeSaver, dentro do fiscalwrapper, salva
    o XML do protocolo de inutilizacao em disco, na pasta InutilizacaoManual do bundle_dir - isso
    ja existia e nao muda aqui). Por isso, pra nao pedir confirmacao/tentar de novo o mesmo numero
    numa proxima execucao do main.py (esse numero vai continuar aparecendo como "nao encontrado"
    pra sempre, ja que nunca vai existir venda nenhuma por tras dele), esta funcao grava o
    desfecho num arquivo de estado JSON (mesmo mecanismo que o CLI em lote abaixo ja usa via
    --state-file, so que com um caminho default fixo - ver default_state_file()). So desfechos
    TERMINAIS (numero realmente inutilizado, ou a propria SEFAZ confirmando que ja estava
    tratado/usado, ou um erro permanente) sao gravados; falhas temporarias (SEFAZ fora do ar,
    erro inesperado de configuracao/conexao) NAO sao gravadas, pra serem tentadas de novo na
    proxima execucao. Use nota_ja_processada(numero_nota) pra checar isso ANTES de chamar esta
    funcao (é o que consulte_csv.py faz, pra nem pedir confirmacao de novo ao operador).

    Retorna (sucesso, mensagem) - mesmo formato de corrigir_protocolo() (corrigir_protocolo.py),
    pra um uso simetrico em consulte_csv.py. Nunca propaga excecao - qualquer falha (config
    ausente, certificado, SDK do fiscalwrapper nao encontrado, SEFAZ fora do ar, etc.) volta como
    (False, mensagem).
    """
    state_file = state_file or default_state_file()
    chave_estado = str(numero_nota)

    state = load_state(state_file)
    if chave_estado in state:
        return True, "Numero {} já processado anteriormente ({}) - não tentando de novo (ver {})".format(
            numero_nota, state[chave_estado], state_file)

    try:
        if app_path is None:
            from consulte_csv import get_system_version
            app_path = get_system_version()

        bundle_dir = bundle_dir or default_bundle_dir(app_path)
        fiscalwrapper_src = fiscalwrapper_src or default_fiscalwrapper_src(app_path)

        pecas = _montar_disabler(bundle_dir, fiscalwrapper_src, justificativa_override=justificativa)
        serie = serie or pecas["cfg"]["serie"]
        nfce_disabler, request_builder = _criar_nfce_disabler(pecas, serie)

        now_iso = datetime.now().strftime("%Y-%m-%dT%H:%M:%S-00:00")
        order = build_synthetic_order_xml(mod=pecas["NfModel"].NFCE.value, nnf=numero_nota, dh_emi=now_iso)
        fake_order_id = "INUT{}".format(numero_nota)

        if not confirm:
            req_xml = request_builder.build_request(order)
            # dry-run: nao grava no state file - so um preview, sem desfecho de verdade.
            return True, "[DRY-RUN] serie={} nNF={} -> enviaria:\n{}".format(serie, numero_nota, req_xml)

        try:
            nfce_disabler.disable_fiscal_number(order=order, nf_type=pecas["NfModel"].NFCE.value, order_id=fake_order_id)
            state[chave_estado] = "disabled (serie {})".format(serie)
            save_state(state_file, state)
            return True, "Numero {} (serie {}) inutilizado com sucesso na SEFAZ".format(numero_nota, serie)
        except pecas["FiscalSkippableWarning"] as exc:
            # SEFAZ respondeu que o numero ja foi tratado/usado - desfecho terminal, grava.
            state[chave_estado] = "skipped_by_sefaz (serie {}): {}".format(serie, exc)
            save_state(state_file, state)
            return True, "SEFAZ pulou (numero ja usado ou faixa ja tratada): serie={} nNF={} - {}".format(
                serie, numero_nota, exc)
        except pecas["FiscalInutilizationRetryableError"] as exc:
            # SEFAZ fora do ar ou similar - NAO grava, pra tentar de novo na proxima execucao.
            return False, "SEFAZ indisponivel, tentar de novo depois: serie={} nNF={} - {}".format(
                serie, numero_nota, exc)
        except pecas["FiscalInutilizationPermanentError"] as exc:
            # Erro permanente (ex: numero fora de faixa autorizada) - desfecho terminal, grava,
            # senao ficaria tentando a mesma coisa impossivel pra sempre.
            state[chave_estado] = "permanent_error (serie {}): {}".format(serie, exc)
            save_state(state_file, state)
            return False, "Erro permanente ao inutilizar: serie={} nNF={} - {}".format(serie, numero_nota, exc)
    except Exception as exc:
        # Falha de config/conexao/SDK (nao é um desfecho da SEFAZ sobre o numero em si) - NAO
        # grava, pra tentar de novo na proxima execucao (pode ser um problema temporario/
        # ambiental, ex: bundle-dir errado, certificado ausente, fiscalwrapper-src errado).
        # ADICIONADO EM 10/09/2026 (5): loga o traceback completo (nao so str(exc)) - "str(exc)"
        # sozinho nao diz em que arquivo/linha a excecao realmente aconteceu, o que ja custou
        # varias rodadas de "adivinhar a causa raiz olhando so a mensagem" nos incidentes
        # anteriores. O traceback completo vai pro log (logger.error), a mensagem de retorno
        # continua curta (mesmo formato de sempre, pra nao quebrar quem já espera essa string).
        logger.error(
            "Traceback completo do erro ao inutilizar numero %s (serie %s):\n%s",
            numero_nota, serie, traceback.format_exc())
        return False, "Erro ao inutilizar numero {} (serie {}): {} ({}) - traceback completo no log".format(
            numero_nota, serie, exc, type(exc).__name__)


# ==============================================================================
# CLI em lote - so usado quando este arquivo e rodado direto (uso manual, a
# partir de um missing_numbers.json ja levantado). Nao usado por
# inutilizar_nota_orfa()/consulte_csv.py acima.
# ==============================================================================

def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--missing-json", required=True, help="Caminho do missing_numbers.json")
    parser.add_argument("--bundle-dir", required=True, help="Diretorio do bundle do fiscalwrapper (BUNDLEDIR)")
    parser.add_argument("--loader-cfg", default=None, help="Default: <bundle-dir>/loader_NFCE.cfg (nao usado mais diretamente, mantido por compatibilidade)")
    parser.add_argument("--nfce-urls", default=None, help="Default: <bundle-dir>/nfce_urls.xml (nao usado mais diretamente, mantido por compatibilidade)")
    parser.add_argument("--state-file", default=None, help="Default: <missing-json>.state.json")
    parser.add_argument("--justificativa", default=None, help="Sobrescreve a justificativa do loader.cfg")
    parser.add_argument("--sleep", type=float, default=5.0, help="Segundos entre cada chamada a SEFAZ (default 5)")
    parser.add_argument("--confirm", action="store_true", help="Sem essa flag, so mostra o que seria enviado (dry-run)")
    parser.add_argument("--fiscalwrapper-src", default=None, help="Default: diretorio deste script/../src, ajuste se necessario")
    args = parser.parse_args()

    state_file_path = args.state_file or (args.missing_json + ".state.json")

    logging.basicConfig(level=logging.INFO, format="%(asctime)s %(levelname)s %(message)s")

    pecas = _montar_disabler(args.bundle_dir, args.fiscalwrapper_src, justificativa_override=args.justificativa)

    with open(args.missing_json, "r") as f:
        data = json.load(f)
    missing = data["missing"]

    # agrupa por serie pra montar um NfceDisabler por serie (parametros dependem da serie)
    by_serie = {}
    for item in missing:
        by_serie.setdefault(item["serie"], []).append(item["nnf"])

    state = load_state(state_file_path)
    total = sum(len(v) for v in by_serie.values())
    logger.info("Total de numeros a processar: %s (ja processados antes: %s)", total, len(state))

    if not args.confirm:
        logger.info("=== DRY-RUN (nada sera enviado a SEFAZ; use --confirm pra enviar de verdade) ===")

    for serie, numeros in sorted(by_serie.items(), key=lambda kv: int(kv[0])):
        nfce_disabler, request_builder = _criar_nfce_disabler(pecas, serie)

        for nnf in sorted(numeros):
            key = "serie{}_nnf{}".format(serie, nnf)
            if key in state:
                logger.info("Ja processado, pulando: %s (%s)", key, state[key])
                continue

            now_iso = datetime.now().strftime("%Y-%m-%dT%H:%M:%S-00:00")
            order = build_synthetic_order_xml(mod=pecas["NfModel"].NFCE.value, nnf=nnf, dh_emi=now_iso)
            fake_order_id = "INUT{}".format(nnf)

            if not args.confirm:
                req_xml = request_builder.build_request(order)
                logger.info("[DRY-RUN] serie=%s nNF=%s -> enviaria:\n%s", serie, nnf, req_xml)
                continue

            try:
                nfce_disabler.disable_fiscal_number(order=order, nf_type=pecas["NfModel"].NFCE.value, order_id=fake_order_id)
                logger.info("OK: serie=%s nNF=%s inutilizado", serie, nnf)
                state[key] = "disabled"
            except pecas["FiscalSkippableWarning"] as exc:
                logger.warning("Pulado pela SEFAZ (numero ja usado ou faixa ja tratada): serie=%s nNF=%s - %s", serie, nnf, exc)
                state[key] = "skipped_by_sefaz"
            except pecas["FiscalInutilizationRetryableError"] as exc:
                logger.warning("SEFAZ indisponivel, tentar de novo depois: serie=%s nNF=%s - %s", serie, nnf, exc)
                # nao marca no state -> proxima execucao tenta de novo
            except pecas["FiscalInutilizationPermanentError"] as exc:
                logger.error("Erro permanente: serie=%s nNF=%s - %s", serie, nnf, exc)
                state[key] = "permanent_error: {}".format(exc)
            except Exception:
                logger.exception("Erro inesperado processando serie=%s nNF=%s", serie, nnf)
                # nao marca no state -> revisar manualmente e rodar de novo

            save_state(state_file_path, state)
            time.sleep(args.sleep)

    logger.info("Finalizado.")


if __name__ == "__main__":
    main()
