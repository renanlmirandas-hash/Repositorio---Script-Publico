# find_xml — tratamento automático de venda (integração e-deploy / NFCe)

Este documento descreve o que cada script desta pasta faz, como se encaixam entre si, e o
contexto operacional (POS e-deploy, banco fiscal, SEFAZ) necessário para dar manutenção neles.
É complementar ao histórico de migração Python 2→3 (projeto "Tratamento de venda" no Claude,
doc `migracao-python3-find-xml.md`), que registra decisões e correções já aplicadas — este
arquivo foca em **o que o sistema faz hoje**, não no histórico de mudanças.

## Visão geral

O `main.py` é o script principal, disparado por `update.bat` (rodando com
`C:\edeploypos\python3\python.exe` — o caminho real do interpretador varia por loja, ver seção
"Ambientes/instalações" abaixo) em cada terminal de loja. Ele lê um arquivo CSV
(`file_csv/bkoffice.csv`) contendo números de nota vindos do backoffice, localiza a venda
correspondente no banco local de pedidos do POS, verifica o estado fiscal dessa nota (autorizada,
em contingência, cancelada, etc.) e corrige inconsistências entre o banco de pedidos e o banco
fiscal (`fiscal_persistcomp.db`). Ao final, também roda uma rotina de atualização de componentes
do sistema (`fix_apply.py`).

Além do fluxo principal, a pasta reúne um conjunto de scripts standalone de suporte/correção —
recuperar pedidos apagados, preencher parâmetros fiscais faltantes, reconstruir o XML da NFC-e,
etc. — usados manualmente quando algo dá errado numa loja específica.

## Fluxo principal (`main.py`)

1. **Detecta a instalação** via `get_system_version()` (`consulte_csv.py`): procura, nessa
   ordem, `C:\mwpos`, `C:\edeployPOS`, `C:\edeploy-pos-structure` (Windows) ou
   `/home/administrador/edeployPOS` (Linux), caindo em `/home/administrador/mwpos_server` como
   default. Isso define os caminhos de banco de dados, backups e binários usados no resto do
   script.
2. **Lê `file_csv/bkoffice.csv`** (`ler_arquivo_csv` / `file_valor_sentto`, em `consulte_csv.py`):
   cada linha do CSV traz um número de nota (`numeronota`) separado por `;`.
3. **Localiza a venda no banco local** (`find_fiscal_id`, `sqlite_update.py`): varre os arquivos
   `order.db<N>` (um por POS/caixa) procurando, em `OrderCustomProperties`, a linha onde
   `Key = 'FISCAL_ID'` bate com o número de nota do CSV. Retorna `orderid`, `nota` e o caminho do
   banco onde a venda foi encontrada.
4. **Para cada venda encontrada, decide o que fazer** (`time_direction`, em `consulte_csv.py`) —
   ver seção dedicada abaixo, é o coração da lógica de negócio.
5. **Roda a atualização de componentes** (`main_fix()`, `fix_apply.py`) — sempre, independente do
   resultado do passo 4.
6. Loga início/fim em `system_script.log` (formato `timestamp - LEVEL - mensagem`, UTF-8).

### `time_direction` — a lógica de decisão fiscal

Recebe o histórico de estados de uma venda (`orderstatehistory`) e decide a ação com base na
combinação de estados:

- **Void + Paid presentes, void ocorreu ≥30min depois do paid**: marca a venda como "cancelada"
  no fluxo interno (`updater_aped_20805`, com status "cancelada") e não segue adiante — é uma
  venda cancelada normalmente, fora da janela de contingência.
- **Void + Paid presentes, void <30min depois do paid**: trata como cancelamento normal dentro da
  janela aceitável (`updater_aped_20805`, sem status).
- **Paid sem Void** (venda paga e não cancelada) — o caso mais importante:
  - Aguarda 7s (dar tempo do XML fiscal ser gravado) e lê a custom property `FISCAL_XML` da
    venda (XML da nota em base64).
  - Decodifica o `cStat` (código de status da SEFAZ) desse XML via `DecodeBase64`
    (`decode_base64.py`).
  - **Se `cStat` é 100 ou 150** (autorizada): compara com o `cStat` que está gravado no banco
    fiscal (`fiscal_persistcomp.db`, via `validate_status`). Se divergem, atualiza o banco fiscal
    com o XML mais recente (`update_xml_APED23848`) e retorna 5 (nota corrigida). Se já batem,
    apenas confirma e retorna 5.
  - **Se `cStat` indica contingência** ("Problemas de conexao com a SEFAZ" ou "Notas anteriores
    em contingencia"): antes de mais nada, tenta corrigir o protocolo automaticamente via
    `FixingCstatCupons.find_key_pattern` (ver seção "Correção de protocolo" abaixo). Depois,
    monta um registro `FiscalData` com os dados da venda e:
    - Se já existe registro fiscal para esse `orderid` (`sales_inquiry`), atualiza o XML
      (`update_xml_APED23848`).
    - Senão, insere um novo registro (`insert_fiscal_faltante`) — essa é a rotina que
      "recupera" notas que ficaram sem registro no banco fiscal.
  - Também existe um bloco (`order_disabled`/`xml_fiscal_disabled`) para tratar inutilização
    incorreta (`cStat` 206/256/102 quando deveria estar ativa) e corrigir a sequência fiscal
    (`seq_fiscal`/`seq_update`/`update_fiscal_order`) — mas hoje essas variáveis nunca são
    setadas como `True`/valor no código atual, então esse ramo é efetivamente inatingível como
    está escrito (possível dívida técnica/código morto a revisar).
- **Void sem Paid** (cancelada antes de ser paga): olha a custom property
  `DISABLED_FISCAL_XML`/`ORDER_DISABLED` e loga o motivo (cStat 563, 102, ou sequência quebrada
  via `ORDER_DISABLED`) — não faz alteração no banco além do log, é diagnóstico.
- **Nem Void nem Paid**: consulta o estado atual da venda (`consulte_orderid`) e só loga.
- **Estado 6 (recalled)**: interrompe o processamento dessa venda sem mais ação.

### Correção automática de protocolo (`FixingCstatCupons`, `fix_cupom_protocol.py`)

Quando uma venda está em contingência, o `main.py` tenta corrigir sozinho o protocolo da nota
antes de cair no fluxo manual de `FiscalData`. Como isso funciona:

- `FixingCstatCupons` abre uma conexão com o barramento e-deploy (`MBEasyContext`) e importa o
  SDK proprietário (`msgbus`, `cfgtools` de `common3.pypkg`; `old_helper`, `bustoken` de
  `edpcommon.pypkg` — confirmado em campo em 28/08/2026 que não existe `edpcommon3.pypkg`, ver
  incidente de campo abaixo) dentro da instalação. Essa conexão é cara de abrir, então o `main.py` a
  reaproveita durante toda a execução via `_obter_fixing_cstat_cupons()` (uma única instância em
  cache). Se a loja não for NFCE (não existe `loader_NFCE.cfg`) ou a conexão falhar por qualquer
  motivo, a correção fica marcada como indisponível pelo resto da execução e o fluxo normal
  continua sem ela.
- `find_key_pattern(orderid)` varre o `FiscalWrapperThread.log` procurando a linha que o
  `nfce.py` (parte do SDK e-deploy) grava quando detecta e tenta corrigir sozinho um `cStat` 539
  (duplicidade de chave de acesso), 100, 150 ou 204 — do tipo:
  `"... nfce.py:...:_handle_duplicated_diff_key - Tratando 539 da order 000123413 ...
  Chave de Acesso <44 dígitos>"`. Extrai o `cStat` e a chave de acesso que a SEFAZ já reconhece
  para essa nota.
- `fix_cstat(orderid, key, cstat)` pega o `FISCAL_XML` atual da venda (via `get_order_picture`,
  mensagem ao barramento), troca a chave de acesso incorreta pela chave correta encontrada no
  log, remonta o XML com um protocolo de aceite (`cStat 204`, motivo "Duplicidade de NF-e") e
  grava de volta em `fiscal_persistcomp.db` (`update_fiscal_persist`).
- `process_resign` / `process_unused_orders` são rotinas mais amplas (não chamadas pelo
  `main.py` no fluxo atual, existem para execução manual/futura): a primeira varre um período de
  60 dias procurando notas pendentes de envio à SEFAZ e força reenvio; a segunda identifica
  pedidos indevidamente "não usados"/inutilizados e limpa a flag `ORDER_DISABLED`.

### Atualização de componentes (`fix_apply.py`)

Depois do processamento das vendas, `main_fix()` sempre roda: lê a versão instalada
(`get_version()`, em `util.py`, consulta `pos_updater.db`) e, se bater com uma das versões
mapeadas (`CORE:4.2.0|SRC:25.08.11`, `CORE:5.2.3|SRC:26.02.11`, `CORE:5.2.6|SRC:26.05.06`,
`CORE:5.3.0|SRC:26.05.12`), copia os bundles correspondentes da pasta `repository/<versão>/update/`
para `C:\edeploypos\genesis\src\` e `C:\edeploypos\src\` (removendo `.pyc` antigos antes) e
reinicia o componente afetado (`restart_component`, via `hv -o <componente>`, usando os nomes
`remoteorder`, `fiscalwrapper`, `npersistcomp`). Se a versão instalada já tiver a correção
(nenhuma das quatro acima), levanta `ValueError` e não faz nada — é esse erro que aparece como
"Unable to get system version" no log quando a máquina não é um terminal POS real (não tem
`pos_updater.db`).

## Módulos de apoio

- **`consulte_csv.py`**: núcleo da lógica de negócio (`time_direction`, detecção de instalação,
  leitura do CSV) — descrito acima.
- **`sqlite_update.py`**: toda a camada de acesso a SQLite usada pelo fluxo principal — consultas
  e updates em `order.db<N>` (pedidos), `fiscal_persistcomp.db` (dados fiscais) e
  `tblservice.db`. Inclui as funções de correção pontual `updater_aped_20805` (cancelamento),
  `updater_OXAP_5832`, `updater_aped_20805_unpaid` (várias delas nomeadas por número de chamado/
  bug interno — APED-xxxxx, OXAP-xxxx).
- **`decode_base64.py`**: `DecodeBase64` decodifica um XML de nota (base64) e extrai o `cStat` —
  seja de `protNFe/infProt/cStat` (nota normal), `cStat` direto (nota inutilizada) ou
  `infNFe/ide/xJust` (motivo de contingência/justificativa, quando não há cStat numérico ainda).
- **`util.py`**: `get_version()` lê a última atualização aplicada em `pos_updater.db`;
  `restart_component()` reinicia um componente via `hv -o`.
- **`time_hora.py`**: `datetime_to_float` converte timestamp de string para epoch (usado ao
  montar o registro `FiscalData`).
- **`xml_file.py`**: utilitário genérico de listagem recursiva de arquivos (`get_xmls_list`) —
  não está no caminho crítico do fluxo atual.
- **`order_picture.py`** (`StandAlone_OrderPicture`) e **`send_orderpaid_boh.py`**
  (`StandAlone`): classes para, dado um `orderid`, buscar o "order picture" completo da venda no
  barramento e-deploy e (no caso de `send_orderpaid_boh.py`) montar o payload e enviar ao BOH
  (back office) via HTTP (`POST /pump/sale/order-picture`). **Não são chamadas em nenhum ponto
  ativo do `main.py` hoje** — só há uma referência comentada em `time_direction`
  (`#StandAlone(xml_file.get("orderid"))` quando `order_statr == 5`). Ficam prontas para reativar
  quando for decisão de negócio enviar pedidos pagos ao BOH nesse ponto do fluxo.

## Scripts standalone (uso manual, sob demanda)

Não fazem parte do fluxo automático do `main.py` — são rodados manualmente quando uma loja
reporta um problema específico:

- **`backfill_fiscal_params_from_order.py`**: quando um produto não tem parâmetro fiscal
  cadastrado em `fiscal_params.db` (NCM, CFOP, CST_ICMS, CST_PIS, CST_COFINS, CSOSN, CEST) e isso
  impede reconstruir o XML de uma nota, este script lê o `FISCAL_XML` já aceito pela SEFAZ de uma
  nota existente e usa esses valores oficiais para preencher os parâmetros faltantes — nunca
  sobrescreve o que já existe. Faz backup do banco antes de gravar. Uso:
  `python backfill_fiscal_params_from_order.py <numero_nota> [--dry-run] [--yes]`.
- **`restore_order_from_backup.py`**: dado um ou mais números de nota (`FISCAL_ID`), procura o
  pedido primeiro nas bases correntes (`order.db<N>`), depois nos backups mensais
  (`orders_*.db`), e em último caso reconstrói o pedido a partir do `OrderPicture` salvo no
  próprio registro fiscal (`FiscalData`) — essa reconstrução é best-effort e não recupera
  histórico de cancelamento nem taxas de delivery. Também garante/restaura o registro fiscal
  correspondente. Sempre faz backup antes de gravar. Uso:
  `python restore_order_from_backup.py <notas...> [--pos N] [--backup-file NOME] [--dry-run] [--yes]`.
- **`backfill_missing_order.py`**: usa o SDK novo do e-deploy (`common3.pypkg`,
  `mbcontextmessagehandler`, `order_api`) para buscar pedidos direto do serviço de pedidos
  (`OrderService`) por `orderid` e inserir/backfillar entradas no audit log
  (`auditlogger_services`) quando ainda não constam lá — usado para recuperar eventos de
  voided/stored que não chegaram a ser auditados. Uso:
  `run_backfill_missing_order.bat <ORDER_ID> [ORDER_ID2 ...] [--force]` (o `.bat` já resolve o
  caminho do `python3` e a pasta de saída do audit log).
- **`fiscal_reprocessa_nfeproc.py`**: reconstrói o XML `nfeProc` completo (envelope com
  `<NFe>` + `<protNFe>`) de uma nota já autorizada, juntando o XML de venda salvo em
  `fiscal_persistcomp.db` com a chave de acesso e `cStat` encontrados no log do fiscalwrapper
  (padrão `"Order <n>: chave autorizada <44 dígitos> retornou cStat 100"`). Salva um backup local
  em `output_nfeproc/` antes de gravar de volta no banco. Os nomes de tabela/coluna
  (`fiscaldata`/`orderid`/`xmlrequest`) são um "melhor palpite" documentado no próprio arquivo —
  usar `--list-tables`/`--describe-table` para confirmar antes de rodar em uma instalação nova.

## Ambientes / instalações reconhecidas

O código reconhece três variações de instalação e-deploy, cada uma com seu próprio caminho base
(detectado por `get_system_version()` em `consulte_csv.py`, ou fixo como default nos scripts
standalone via `DEFAULT_DB_DIR`/`DB_PATH`):

| Instalação | Caminho base | Observação |
|---|---|---|
| `mwpos` | `C:\mwpos` ou `/home/administrador/mwpos_server` | default quando nada mais é encontrado |
| `edeployPOS` | `C:\edeployPOS` | usado como default nos scripts standalone (`DEFAULT_DB_DIR`) |
| `edeploy-pos-structure` | `C:\edeploy-pos-structure` | instalação mais recente |

**Atenção**: o `python3\python.exe` embarcado varia por loja e nem sempre está na versão
esperada (3.12+) — ver incidente de campo abaixo. Sempre que um erro mencionar
`logging.basicConfig` ou outro recurso "novo" da linguagem, suspeitar primeiro da versão do
Python instalada naquela loja específica antes de assumir bug de lógica.

## Bancos de dados envolvidos

- **`order.db<N>`** (um por POS/caixa, `N` = número do caixa): tabelas `Orders`,
  `OrderCustomProperties` (incluindo `FISCAL_ID`, `FISCAL_XML`, `DISABLED_FISCAL_XML`,
  `ORDER_DISABLED`), `OrderStateHistory`, `OrderItem`, `OrderTax`, `OrderTender`, etc.
- **`fiscal_persistcomp.db`**: tabela `FiscalData` (`PosId`, `OrderId`, `XMLRequest`,
  `NumeroNota`, `SentToNfce`, `OrderPicture`, `DataNota`, ...) e `sequencer` (sequência do
  `FiscalId`).
- **`tblservice.db`**: tabela `serviceorders` (relaciona `orderid`/`posid` para pedidos remotos/
  delivery).
- **`pos_updater.db`**: tabela `updatescontroller`, usada só por `util.get_version()` para saber
  a última atualização de sistema aplicada.
- **`fiscal_params.db`**: tabela `FiscalParameter` (catálogo de classificação tributária por
  produto), usado só por `backfill_fiscal_params_from_order.py`.

## Log

Tudo grava em `system_script.log`, na pasta do script, formato
`timestamp - LEVEL - mensagem`, UTF-8. `FixingCstatCupons` usa um `getLogger("FixingCstatCupons")`
que propaga para esse mesmo log (só serve para identificar a origem das linhas, não abre arquivo
separado).

## Diagnóstico de `.pypkg`

`diagnose_pypkg.py` (nesta pasta) abre cada `.pypkg` da instalação (são arquivos zip, mesmo sem
extensão `.zip`) e procura em qual deles cada módulo do SDK (`old_helper`, `msgbus`, `bustoken`,
`cfgtools`, `mbcontextmessagehandler`, `order_api`) realmente está — sem precisar importar nada
(evita efeitos colaterais de conectar no barramento e-deploy). Útil sempre que um `ModuleNotFoundError`
aparecer envolvendo esses módulos, já que o layout dos `.pypkg` varia entre instalações. Uso:
`<python3 da loja> diagnose_pypkg.py`.

## Incidentes de campo conhecidos

### 28/08/2026 (1) — `ValueError: Unrecognised argument(s): encoding` ao rodar `main.py` numa loja

O `logging.basicConfig(..., encoding='utf-8')` original só funciona em Python 3.9+. Uma loja
tinha `python3\python.exe` numa versão anterior a 3.9, o que quebrava o script antes mesmo de
processar qualquer venda. Corrigido substituindo o `basicConfig` por configuração manual do
handler (`logging.FileHandler(log_filename, encoding='utf-8')` + `addHandler`), que produz o
mesmo resultado mas funciona em qualquer Python 3.x. Recomenda-se checar
`python3\python.exe --version` nas demais lojas para saber quantas ainda estão com runtime
desatualizado.

### 28/08/2026 (2) — `ModuleNotFoundError: No module named 'old_helper'` numa loja

Depois de corrigir o incidente (1), uma execução em outra loja (`C:\edeployPOS`) rodou até o fim
normalmente, mas logou que não conseguiu conectar ao `FixingCstatCupons` por falta do módulo
`old_helper` — o `except Exception` em `_obter_fixing_cstat_cupons()` capturou isso e a venda foi
processada normalmente pelo fluxo padrão, só sem a correção automática de protocolo. Rodando
`diagnose_pypkg.py` nessa loja, confirmou-se que `edpcommon3.pypkg` **não existe** ali —
`old_helper`/`bustoken` continuam em `edpcommon.pypkg` (o pacote "antigo", cujo `.pyc` já é
compatível com Python 3). Corrigido em `fix_cupom_protocol.py`, `order_picture.py` e
`send_orderpaid_boh.py`: `sys.path` agora aponta para `edpcommon.pypkg` em vez de
`edpcommon3.pypkg`. Também identificado no mesmo diagnóstico: `mbcontextmessagehandler` e
`order_api` (usados por `backfill_missing_order.py`) não existem em nenhum `.pypkg` dessa loja —
esse script standalone pode não funcionar nela.

## O que ainda é dívida técnica / pendente de decisão

- `StandAlone` (`send_orderpaid_boh.py`) e `StandAlone_OrderPicture` (`order_picture.py`) não são
  chamadas em nenhum lugar ativo — decisão de negócio pendente sobre reativar o envio ao BOH em
  `time_direction` quando `order_statr == 5`.
- O ramo de inutilização incorreta dentro de `time_direction` (`order_disabled`/
  `xml_fiscal_disabled`) parece inatingível no código atual (as variáveis nunca recebem um valor
  que dispare esse bloco) — revisar se é intencional ou uma lacuna.
- `cElementTree` (alias legado) ainda é usado em vez de `xml.etree.ElementTree` em
  `fix_cupom_protocol.py`, `order_picture.py`, `send_orderpaid_boh.py` e
  `fiscal_reprocessa_nfeproc.py` — funciona, mas os scripts mais novos já usam o nome direto.
- `fiscal_reprocessa_nfeproc.py` tem nomes de tabela/coluna não confirmados em produção (ver
  aviso no próprio arquivo) — confirmar com `--list-tables`/`--describe-table` antes do primeiro
  uso em cada instalação.
- `key_pattern_fiscallog` (cStat 204, em `fix_cupom_protocol.py`) ainda busca um padrão de log
  antigo (`FiscalWrapper.log`, não `FiscalWrapperThread.log`) que provavelmente está desatualizado
  pelo mesmo motivo que o padrão de `find_key_pattern` estava — falta um exemplo real desse
  cenário para reescrever com segurança.
