from __future__ import (
    annotations,
)

import json
from typing import (
    Any,
    Dict,
    List,
    Optional,
    Tuple,
    Union,
)
from xml.etree import (
    ElementTree as eTree,
)

import requests
from application.model import (
    ApplierSubTypes,
    TotaledMessage,
    TranslatedMessage,
)
from application.model.configuration import (
    PROVIDER_DEFAULT,
    Configurations,
    Credential,
)
from application.model.customexception import (
    AlreadyUnlockedError,
    ClientCustomError,
    CommunicationError,
    ForbiddenError,
    GoneError,
    InUseError,
    NoResponseError,
    NotAllowedError,
    NotAvailableError,
    NotFound,
    NotFoundError,
    ProcessorError,
    ResponseError,
)
from application.model.orderinfo import (
    Order,
    OrderJsonEncoder,
)
from application.model.tokens import (
    NDiscountTokens,
)
from helper import (
    retry,
)
from messagebus import (
    Message,
    MessageBus,
    DataType,
    DefaultToken,
)
from msgbus import (
    FM_PARAM,
    TK_SYS_NAK,
)
from order_api.token import (
    OrderApiTokens,
)
from posentitiesformatter import (
    OrderFormatter,
    TableFormatter,
)
from requests import (
    Response,
)
from table_manager_api.token import (
    TK_CMP_MESSAGE,
)
from util import (
    get_applier_name_from_order,
    get_applier_sub_type_from_order,
    get_loyalty_provider_from_order,
)


class APIRepository(object):
    def __init__(
        self,
        configs: Configurations,
        message_bus: MessageBus,
    ) -> None:

        self.logger = configs.logger
        self.configs = configs
        self.message_bus = message_bus
        self.exception_map = {
            204: NoResponseError,
            206: NoResponseError,
            403: ForbiddenError,
            404: NotFoundError,
            405: NotAllowedError,
            410: GoneError,
            500: ProcessorError,
        }
        self.per_method_exception_map = {
            "lock": {
                404: NotFoundError,
                406: ClientCustomError,
                409: InUseError,
                500: ProcessorError,
            },
            "burn": {
                400: InUseError,
                406: NotAvailableError,
                409: AlreadyUnlockedError,
                500: ProcessorError,
            },
        }

    @staticmethod
    def _extract_benefit_from_response(payload: Dict) -> Dict:
        return payload.get("benefit", payload.get("benefits", payload))

    def _resolve_provider_from_order_picture(
        self,
        benefit_id: str,
        order_picture: str,
        provider_name: Optional[str],
    ) -> Optional[str]:

        resolved = provider_name or get_applier_name_from_order(
            benefit_id=benefit_id,
            order_picture=order_picture,
            logger=self.logger,
        )
        if resolved:
            return resolved

        return get_loyalty_provider_from_order(
            order_picture=order_picture,
            logger=self.logger,
        )

    def _resolve_request_context(
        self,
        provider_name: Optional[str],
        endpoint_path: str,
        applier_sub_type: str,
        add_content: bool = True,
        default_timeout: int = 20,
    ) -> Tuple[Optional[str], Dict, int]:

        resolved_provider = self.resolve_credentials_for_provider(provider_name=provider_name)
        if resolved_provider is not None:
            url = self._get_provider_url(
                provider_name=resolved_provider,
                endpoint_path=endpoint_path,
            )
            headers = self._get_provider_headers(
                provider_name=resolved_provider,
                add_content=add_content,
            )
            timeout = self._get_provider_timeout(provider_name=resolved_provider)
        else:
            base_url = self.configs.credentials[applier_sub_type].base_url
            if not base_url:
                return None, {}, default_timeout

            url = base_url + endpoint_path
            self.logger.info("Requesting from endpoint: {}".format(url))
            headers = self._get_headers(
                applier_sub_type=applier_sub_type,
                add_content=add_content,
            )
            timeout = default_timeout

        return url, headers, timeout

    def _get_provider_headers(
        self,
        provider_name: str,
        add_content: bool = True,
    ) -> Dict:

        credential = self.configs.providers[provider_name]
        return self._build_headers(
            credential=credential,
            add_content=add_content,
        )

    def _get_provider_url(
        self,
        provider_name: str,
        endpoint_path: str,
    ) -> str:

        provider = self.configs.providers[provider_name]
        full_url = provider.base_url + endpoint_path

        self.logger.info(
            "Requesting from provider '{}' endpoint: {}".format(provider_name, full_url),
        )

        return full_url

    def _get_provider_timeout(
        self,
        provider_name: str,
    ) -> int:

        return self.configs.providers[provider_name].timeout

    def retrieve_loyalty_customer_info_from_provider(
        self,
        loyalty_customer_id: str,
        pos_id: int,
        provider_name: str,
    ) -> Optional[str]:

        end_point_url = self.configs.endpoints.retrieve_loyalty_customer_info.format(
            customerId=loyalty_customer_id,
        )
        url = self._get_provider_url(
            provider_name=provider_name,
            endpoint_path=end_point_url,
        )
        headers = self._get_provider_headers(
            provider_name=provider_name,
            add_content=False,
        )
        timeout = self._get_provider_timeout(provider_name=provider_name)
        due_info = self._get_due_amount(pos_id=pos_id)

        errors_list = []

        response = retry(
            logger=self.logger,
            method_name="retrieve_loyalty_customer_info_from_provider",
            n=1,
            sleep_seconds=0,
            trying_to_do=lambda: requests.request(
                method="GET",
                url=url,
                params={"dueAmount": due_info["due_amount"]},
                headers=headers,
                timeout=timeout,
            ),
            is_success=lambda resp: resp.status_code == 200,
            success=lambda resp: resp,
            failed=lambda resp: errors_list.append((resp.status_code, resp)),
            on_exception=lambda ex: errors_list.append(ex),
        )

        if response is not None:
            return response.content

        response_error = self._get_response_error(errors_list)
        raise self._build_lock_custom_exception(
            status_code=response_error.status_code,
            response_error=response_error,
        )

    def retrieve_coupon_benefit_from_provider(
        self,
        pos_id: int,
        coupon_id: str,
        provider_name: str,
        order_picture: Optional[str] = None,
    ) -> Optional[str]:

        if not order_picture:
            order_picture = self.get_order_picture(pos_id=pos_id)
        if order_picture is None:
            return None

        table_info = self._get_table_info_associated_with_order_picture(
            pos_id=pos_id,
            order_picture=order_picture,
        )
        order_info = self._build_order_info(
            order_picture=order_picture,
            table_picture=table_info,
        )

        end_point_url = self.configs.endpoints.get_benefit.format(
            voucherId=coupon_id,
        )
        url = self._get_provider_url(
            provider_name=provider_name,
            endpoint_path=end_point_url,
        )
        headers = self._get_provider_headers(provider_name=provider_name)
        timeout = self._get_provider_timeout(provider_name=provider_name)
        errors_list = []

        response = retry(
            logger=self.logger,
            method_name="retrieve_coupon_benefit_from_provider",
            n=1,
            sleep_seconds=0,
            trying_to_do=lambda: requests.post(
                url=url,
                headers=headers,
                timeout=timeout,
                data=order_info,
            ),
            is_success=lambda resp: resp.status_code == 200,
            success=lambda resp: resp,
            failed=lambda resp: errors_list.append((resp.status_code, resp)),
            on_exception=lambda ex: errors_list.append(ex),
        )

        if not response:
            response_error = self._get_response_error(errors_list)
            raise self._build_lock_custom_exception(
                status_code=response_error.status_code,
                response_error=response_error,
            )

        self.logger.info("Json from provider '{}': {}".format(provider_name, response.content))
        benefit = self._extract_benefit_from_response(json.loads(response.content))

        notify = benefit.get("notify", False)
        benefit_id = benefit.get("id", None)
        if notify and benefit_id:
            lock_id = self.lock_benefit(
                benefit=benefit,
                pos_id=pos_id,
                applier_sub_type=ApplierSubTypes.COUPON,
                provider_name=provider_name,
            )
            benefit["lockId"] = lock_id

        benefit["applier"] = "Loyalty"
        benefit["applierSubType"] = ApplierSubTypes.COUPON
        benefit["applierName"] = provider_name
        return json.dumps(benefit)

    def resolve_credentials_for_provider(
        self,
        provider_name: Optional[str],
    ) -> Optional[str]:

        if not provider_name or provider_name == PROVIDER_DEFAULT:
            return None

        if self.configs.is_provider_active(provider_name=provider_name):
            return provider_name

        return None

    def _is_coupon_endpoint_configured(
        self,
        applier_sub_type: str,
        provider_name: Optional[str],
    ) -> bool:

        resolved_provider = self.resolve_credentials_for_provider(provider_name=provider_name)
        if resolved_provider is not None:
            return True

        return bool(self.configs.credentials[applier_sub_type].base_url)

    def retrieve_loyalty_customer_info(
        self,
        loyalty_customer_id: str,
        pos_id: int,
    ) -> Optional[str]:

        try:
            url = self._get_customer_url(loyalty_customer_id)
            if not url:
                self.logger.info("Loyalty customer info endpoint not configured - skipping")
                raise NotFound()
            headers = self._get_headers(
                applier_sub_type=ApplierSubTypes.LOYALTY,
                add_content=False,
            )
            due_info = self._get_due_amount(pos_id=pos_id)

            errors_list = []

            response = retry(
                logger=self.logger,
                method_name="retrieve_loyalty_customer_info",
                n=self.configs.partner_retry_policy.count,
                sleep_seconds=self.configs.partner_retry_policy.sleep,
                trying_to_do=lambda: requests.request(
                    method="GET",
                    url=url,
                    params={"dueAmount": due_info["due_amount"]},
                    headers=headers,
                    timeout=30,
                ),
                is_success=lambda resp: resp.status_code == 200,
                success=lambda resp: resp,
                failed=lambda resp: errors_list.append((resp.status_code, resp)),
                on_exception=lambda ex: errors_list.append(ex),
            )
            if response is not None:
                return response.content

            response_error = self._get_response_error(errors_list)
            raise self._build_lock_custom_exception(
                status_code=response_error.status_code,
                response_error=response_error,
            )
        except (KeyError, ValueError, TypeError) as ex:
            self.logger.error("Error on get_benefit: {}".format(str(ex)))
            raise

    def retrieve_coupon_benefit(
        self,
        pos_id: int,
        coupon_id: str,
        order_picture: Optional[str] = None,
    ) -> Optional[str]:

        if not order_picture:
            order_picture = self.get_order_picture(pos_id=pos_id)
        if order_picture is None:
            return None

        table_info = self._get_table_info_associated_with_order_picture(
            pos_id=pos_id,
            order_picture=order_picture,
        )
        order_info = self._build_order_info(
            order_picture=order_picture,
            table_picture=table_info,
        )

        self.logger.info("Order json sent on retrieve:\n{}".format(order_info))
        benefit_raw = self._get_coupon_benefit(
            benefit_id=coupon_id,
            order=order_info,
        )

        if not benefit_raw:
            self.logger.info("No benefit found")
            return None

        self.logger.info("Json from partner: {}".format(benefit_raw))
        benefit = self._extract_benefit_from_response(json.loads(benefit_raw))

        notify = benefit.get("notify", False)
        benefit_id = benefit.get("id", None)
        if notify and benefit_id:
            lock_id = self.lock_benefit(
                benefit=benefit,
                pos_id=pos_id,
                applier_sub_type=ApplierSubTypes.COUPON,
            )
            benefit["lockId"] = lock_id

        benefit["applier"] = "Loyalty"
        benefit["applierSubType"] = ApplierSubTypes.COUPON
        return json.dumps(benefit)

    def _get_table_info(
        self,
        pos_id: int,
        table_id: Union[str, int],
    ) -> Optional[str]:

        params = ("TABLE_INFO", pos_id, table_id)
        req_buf = "\0".join([str(p) for p in params])
        message = Message(
            token=TK_CMP_MESSAGE,
            data_type=FM_PARAM,
            data=req_buf,
        )
        msg = self.message_bus.send_message(
            component="TABLEMGR",
            message=message,
        )

        if msg.token != TK_SYS_NAK:
            return msg.data.decode("utf-8")

        return None

    def get_order_picture(
        self,
        pos_id: Union[str, int],
        order_id: Union[str, int] = "",
        no_cache: Optional[str] = None,
    ) -> Optional[str]:

        params = (pos_id, order_id, "true" if no_cache else "false")
        req_buf = "\x00".join((str(p) for p in params))

        message = Message(
            token=OrderApiTokens.TK_SLCTRL_OMGR_ORDERPICT,
            data_type=FM_PARAM,
            data=req_buf,
        )
        msg = self.message_bus.send_message(
            component="ORDERMGR" + str(pos_id),
            message=message,
        )

        if msg.token == TK_SYS_NAK:
            return None

        return msg.data.split(b"\0")[2].decode("utf-8")

    def _get_table_info_associated_with_order_picture(
        self,
        pos_id: int,
        order_picture: Optional[str],
    ) -> Optional[str]:

        if order_picture is None:
            return None

        order_xml = eTree.fromstring(order_picture)
        table_id_prop = order_xml.find("CustomOrderProperties/OrderProperty[@key='TableID']")
        if table_id_prop is None:
            return None

        table_id = table_id_prop.get("value")
        if table_id is None:
            return None

        return self._get_table_info(
            pos_id=pos_id,
            table_id=table_id,
        )

    def _build_order_info(
        self,
        order_picture: str,
        table_picture: Optional[str] = None,
        payment_info: Optional[Dict] = None,
    ) -> str:

        order_xml = eTree.fromstring(order_picture)
        order_info = OrderFormatter().get_order_picture_dict(order_picture=order_xml)
        self.fix_order_info_to_include_api_required_fields(order_info)

        table_info = None
        if table_picture:
            table_xml = eTree.fromstring(table_picture)
            table_info = TableFormatter().get_table_picture_dict(table_picture=table_xml)

        order = Order(
            store_id=self.configs.store_id,
            order_info=order_info,
            table_info=table_info,
            payment_info=payment_info,
        )
        return json.dumps(order, cls=OrderJsonEncoder)

    def _get_due_amount(
        self,
        pos_id: int,
    ) -> Dict[str, str]:

        order_picture = self.get_order_picture(pos_id=pos_id)
        if not order_picture:
            self.logger.warning("No order picture found for pos_id: {}".format(pos_id))
            return {"due_amount": "0"}

        try:
            order_xml = eTree.fromstring(order_picture)
            due_amount = order_xml.get("dueAmount", "0")
        except (KeyError, ValueError, TypeError) as ex:
            self.logger.error("Error parsing order XML: {}".format(ex))
            return {"due_amount": "0"}

        return {"due_amount": due_amount}

    @staticmethod
    def fix_order_info_to_include_api_required_fields(order_info):
        order_info["instance"] = 0
        order_info["priceBasis"] = "G"

    def burn_benefit(
        self,
        benefit_id: str,
        order_picture: str,
        table_picture: Optional[str] = None,
        provider_name: Optional[str] = None,
    ) -> None:

        applier_sub_type = get_applier_sub_type_from_order(
            benefit_id=benefit_id,
            order_picture=order_picture,
            logger=self.logger,
        )
        provider_name = self._resolve_provider_from_order_picture(
            benefit_id=benefit_id,
            order_picture=order_picture,
            provider_name=provider_name,
        )

        if not self._is_coupon_endpoint_configured(
            applier_sub_type=applier_sub_type,
            provider_name=provider_name,
        ):
            self.logger.info("Loyalty endpoint not configured - skipping burn_benefit")
            return

        endpoint_path = self.configs.endpoints.burn_benefit.format(benefitId=benefit_id)
        url, headers, _ = self._resolve_request_context(
            provider_name=provider_name,
            endpoint_path=endpoint_path,
            applier_sub_type=applier_sub_type,
        )
        errors_list = []

        body_json = self._build_order_info(
            order_picture=order_picture,
            table_picture=table_picture,
        )
        self.logger.debug("Order json sent on burn:\n{}".format(body_json))

        response = retry(
            logger=self.logger,
            method_name="burn_benefit",
            n=self.configs.partner_retry_policy.count,
            sleep_seconds=self.configs.partner_retry_policy.sleep,
            trying_to_do=lambda: requests.put(
                url=url,
                headers=headers,
                data=body_json,
                timeout=20,
            ),
            is_success=lambda resp: resp.status_code in [200, 204],
            success=lambda resp: resp,
            failed=lambda resp: errors_list.append((resp.status_code, resp)),
        )

        # TODO APED-22090: Treat burnId in case of 200
        if response is not None:
            return

        response_error = self._get_response_error(errors_list)
        raise self._build_unlock_burn_custom_exception(
            status_code=response_error.status_code,
            response_error=response_error,
        )

    def _get_coupon_benefit(
        self,
        benefit_id: str,
        order: str,
    ) -> Optional[str]:

        url = self._get_benefit_url(
            voucher_id=benefit_id,
            applier_sub_type=ApplierSubTypes.COUPON,
        )
        if not url:
            self.logger.info("Coupon endpoint not configured - skipping get benefit")
            return None

        headers = self._get_headers(applier_sub_type=ApplierSubTypes.COUPON)
        errors_list = []

        response = retry(
            logger=self.logger,
            method_name="get_benefit",
            n=1,
            sleep_seconds=1,
            trying_to_do=lambda: requests.post(
                url=url,
                headers=headers,
                timeout=20,
                data=order,
            ),
            is_success=lambda resp: resp.status_code == 200,
            success=lambda resp: resp,
            failed=lambda resp: errors_list.append((resp.status_code, resp)),
        )

        if response:
            return response.content
        else:
            if not errors_list:
                raise self._build_communication_error()

            response_error = self._get_response_error(errors_list)
            raise self._build_lock_custom_exception(
                status_code=response_error.status_code,
                response_error=response_error,
            )

    def lock_benefit(
        self,
        benefit: Dict[str, Any],
        pos_id: int,
        applier_sub_type: Optional[str] = None,
        payment_info: Optional[Dict[str, Any]] = None,
        provider_name: Optional[str] = None,
    ) -> str:

        benefit_id = benefit.get("id")
        resolved_applier_sub_type: str = applier_sub_type or benefit.get("applierSubType", "")
        provider_name = provider_name or benefit.get("applierName")

        order_picture = None
        if not provider_name:
            order_picture = self.get_order_picture(pos_id=pos_id)
            if order_picture is None:
                raise NotFound()
            provider_name = self._resolve_provider_from_order_picture(
                benefit_id=benefit_id,
                order_picture=order_picture,
                provider_name=None,
            )

        if not self._is_coupon_endpoint_configured(
            applier_sub_type=resolved_applier_sub_type,
            provider_name=provider_name,
        ):
            self.logger.info("Loyalty endpoint not configured - skipping lock_benefit")
            return ""

        endpoint_path = self.configs.endpoints.lock_benefit.format(benefitId=benefit_id)
        url, headers, _ = self._resolve_request_context(
            provider_name=provider_name,
            endpoint_path=endpoint_path,
            applier_sub_type=resolved_applier_sub_type,
        )

        errors_list = []

        if order_picture is None:
            order_picture = self.get_order_picture(pos_id=pos_id)
            if order_picture is None:
                raise NotFound()

        table_info = self._get_table_info_associated_with_order_picture(
            pos_id=pos_id,
            order_picture=order_picture,
        )

        body_json = self._build_order_info(
            order_picture=order_picture,
            table_picture=table_info,
            payment_info=payment_info,
        )

        response = retry(
            logger=self.logger,
            method_name="lock_benefit",
            n=1,
            sleep_seconds=1,
            trying_to_do=lambda: requests.put(
                url=url,
                headers=headers,
                data=body_json,
                timeout=20,
            ),
            is_success=lambda resp: resp.status_code in [200, 204],
            success=lambda resp: resp,
            failed=lambda resp: errors_list.append((resp.status_code, resp)),
        )

        if response:
            return self._get_lock_id_from_response(
                response=response,
            )

        if not errors_list:
            raise NotFound()

        response_error = self._get_response_error(errors_list=errors_list)
        raise self._build_lock_custom_exception(
            status_code=response_error.status_code,
            response_error=response_error,
        )

    def unlock_benefit(
        self,
        benefit_id: str,
        benefit: Dict[str, Any],
        order_picture: str,
        table_picture: str,
        provider_name: Optional[str] = None,
    ) -> None:

        resolved_applier_sub_type: str
        if benefit:
            resolved_applier_sub_type = benefit.get("applierSubType", "")
            provider_name = provider_name or benefit.get("applierName")
        else:
            resolved_applier_sub_type = get_applier_sub_type_from_order(
                benefit_id=benefit_id,
                order_picture=order_picture,
                logger=self.logger,
            )
            provider_name = self._resolve_provider_from_order_picture(
                benefit_id=benefit_id,
                order_picture=order_picture,
                provider_name=provider_name,
            )

        if not provider_name:
            provider_name = self._resolve_provider_from_order_picture(
                benefit_id=benefit_id,
                order_picture=order_picture,
                provider_name=None,
            )

        if not self._is_coupon_endpoint_configured(
            applier_sub_type=resolved_applier_sub_type,
            provider_name=provider_name,
        ):
            self.logger.info("Loyalty endpoint not configured - skipping unlock_benefit")
            return

        endpoint_path = self.configs.endpoints.unlock_benefit.format(benefitId=benefit_id)
        url, headers, _ = self._resolve_request_context(
            provider_name=provider_name,
            endpoint_path=endpoint_path,
            applier_sub_type=resolved_applier_sub_type,
        )

        errors_list = []

        body_json = self._build_order_info(
            order_picture=order_picture,
            table_picture=table_picture,
        )

        response = retry(
            logger=self.logger,
            method_name="unlock_benefit",
            n=self.configs.partner_retry_policy.count,
            sleep_seconds=self.configs.partner_retry_policy.sleep,
            trying_to_do=lambda: requests.put(
                url=url,
                data=body_json,
                headers=headers,
                timeout=20,
            ),
            is_success=lambda resp: resp.status_code in [200, 204],
            success=lambda resp: resp,
            failed=lambda resp: errors_list.append((resp.status_code, resp)),
        )

        if response is not None:
            return

        response_error = self._get_response_error(errors_list)
        raise self._build_unlock_burn_custom_exception(
            status_code=response_error.status_code,
            response_error=response_error,
        )

    def get_totaled_message(
        self,
        pos_id: int,
        customer_id: str,
        provider_name: Optional[str] = None,
        order_picture: Optional[str] = None,
    ) -> Optional[TotaledMessage]:

        try:
            endpoint_path = self.configs.endpoints.get_totaled_message.format(
                customerId=customer_id,
            )
            url, headers, timeout = self._resolve_request_context(
                provider_name=provider_name,
                endpoint_path=endpoint_path,
                applier_sub_type=ApplierSubTypes.LOYALTY,
                default_timeout=5,
            )
            if not url:
                return None

            errors_list = []

            if not order_picture:
                order_picture = self.get_order_picture(
                    pos_id=pos_id,
                )
            if order_picture is None:
                return None

            table_info = self._get_table_info_associated_with_order_picture(
                pos_id=pos_id,
                order_picture=order_picture,
            )

            body_json = self._build_order_info(
                order_picture=order_picture,
                table_picture=table_info,
            )

            self.logger.debug("Order json sent on get_totaled_message:\n{}".format(body_json))

            response = retry(
                logger=self.logger,
                method_name="get_totaled_message",
                n=self.configs.partner_retry_policy.count,
                sleep_seconds=self.configs.partner_retry_policy.sleep,
                trying_to_do=lambda: requests.post(
                    url=url,
                    data=body_json,
                    headers=headers,
                    timeout=timeout,
                ),
                is_success=lambda resp: resp.status_code in (200, 404),
                success=lambda resp: resp,
                failed=lambda resp: errors_list.append((resp.status_code, resp)),
                on_exception=lambda ex: errors_list.append(ex),
            )
            if response is not None:
                if response.status_code == 404:
                    return None
                response_dict = json.loads(response.content)
                translated_message = self._build_translated_message(
                    body_dict=response_dict,
                    message_field="totalizationMessage",
                )
                benefits = response_dict.get("benefits")
                return TotaledMessage(
                    totalization_message=translated_message,
                    benefits=benefits,
                )

            response_error = self._get_response_error(errors_list=errors_list)
            raise ResponseError(
                logger=self.logger,
                response=response_error,
            )
        except (KeyError, ValueError, TypeError) as ex:
            self.logger.error("Error on get_totaled_message: {}".format(ex))
            raise

    def get_benefit_on_payment(
        self,
        pos_id: int,
        loyalty_customer_id: str,
        payment_info: Dict[str, Union[str, int, float]],
        provider_name: Optional[str] = None,
        order_picture: Optional[str] = None,
    ) -> Optional[Dict]:

        endpoint_path = self.configs.endpoints.payment.format(
            customerId=loyalty_customer_id,
        )

        resolved_provider = self.resolve_credentials_for_provider(provider_name=provider_name)
        if resolved_provider is not None:
            url, headers, _ = self._resolve_request_context(
                provider_name=resolved_provider,
                endpoint_path=endpoint_path,
                applier_sub_type=ApplierSubTypes.PAYMENT,
            )
        else:
            url = self._get_payment_url(loyalty_customer_id=loyalty_customer_id)
            if not url:
                return None

            headers = self._get_headers(applier_sub_type=ApplierSubTypes.PAYMENT)

        errors_list = []

        if not order_picture:
            order_picture = self.get_order_picture(
                pos_id=pos_id,
            )
        if order_picture is None:
            return None

        table_info = self._get_table_info_associated_with_order_picture(
            pos_id=pos_id,
            order_picture=order_picture,
        )

        body_json = self._build_order_info(
            order_picture=order_picture,
            table_picture=table_info,
            payment_info=payment_info,
        )

        response = retry(
            logger=self.logger,
            method_name="payment",
            n=self.configs.partner_retry_policy.count,
            sleep_seconds=self.configs.partner_retry_policy.sleep,
            trying_to_do=lambda: requests.post(
                url=url,
                data=body_json,
                headers=headers,
                timeout=20,
            ),
            is_success=lambda resp: resp.status_code in (200, 204, 404),
            success=lambda resp: resp,
            failed=lambda resp: errors_list.append((resp.status_code, resp)),
            on_exception=lambda ex: errors_list.append(ex),
        )

        if response is not None:
            if response.status_code == 404:
                return {"_status": "CUSTOMER_NOT_FOUND"}
            if response.status_code == 204:
                return {"_status": "NO_CONTENT"}
            return json.loads(response.content)

        response_error = self._get_response_error(errors_list=errors_list)
        raise ResponseError(
            logger=self.logger,
            response=response_error,
        )

    def end_of_sale_notes(
        self,
        pos_id: int,
        order_id: int,
        provider_name: Optional[str] = None,
        order_picture: Optional[str] = None,
    ) -> Optional[List[Dict[str, str]]]:

        resolved_provider = self.resolve_credentials_for_provider(provider_name=provider_name)
        if resolved_provider is not None:
            end_point_url = self.configs.endpoints.end_of_sale_notes
            url = self._get_provider_url(
                provider_name=resolved_provider,
                endpoint_path=end_point_url,
            )
            headers = self._get_provider_headers(provider_name=resolved_provider)
        else:
            url_result = self._get_end_of_sale_notes_url()
            if not url_result:
                return None

            url = url_result
            headers = self._get_headers(applier_sub_type=ApplierSubTypes.MARKETING)
        errors_list = []

        if not order_picture:
            order_picture = self.get_order_picture(
                pos_id=pos_id,
                order_id=order_id,
            )
        if order_picture is None:
            return None

        body_json = self._build_order_info(order_picture=order_picture)
        self.logger.info("Order json sent on end of sale:\n{}".format(body_json))

        response = retry(
            logger=self.logger,
            method_name="end_of_sale_notes",
            n=1,
            sleep_seconds=self.configs.partner_retry_policy.sleep,
            trying_to_do=lambda: requests.post(
                url=url,
                data=body_json,
                headers=headers,
                timeout=self.configs.credentials[ApplierSubTypes.MARKETING].timeout,
            ),
            is_success=lambda resp: resp.status_code in [200, 204, 404],
            success=lambda resp: resp,
            failed=lambda resp: errors_list.append((resp.status_code, resp)),
            on_exception=lambda ex: errors_list.append(ex),
        )

        if response is not None:
            if response.status_code in [204, 404]:
                return None
            return json.loads(response.content)

        response_error = self._get_response_error(errors_list=errors_list)
        raise ResponseError(
            logger=self.logger,
            response=response_error,
        )

    def get_store_config(
        self,
        pos_id: int,
        provider: str,
        provider_name: Optional[str] = None,
    ) -> Optional[Dict]:

        resolved_provider = self.resolve_credentials_for_provider(provider_name=provider_name)
        if resolved_provider is not None:
            end_point_url = self.configs.endpoints.get_store_config
            url = self._get_provider_url(
                provider_name=resolved_provider,
                endpoint_path=end_point_url,
            )
            headers = self._get_provider_headers(provider_name=resolved_provider)
        else:
            url_result = self._get_store_config_url()
            if not url_result:
                return None

            url = url_result
            headers = self._get_headers(applier_sub_type=ApplierSubTypes.STORE_CONFIG)
        body = {
            "pos_id": pos_id,
            "provider": provider,
        }
        errors_list = []

        response = retry(
            logger=self.logger,
            method_name="get_store_config",
            n=1,
            sleep_seconds=self.configs.partner_retry_policy.sleep,
            trying_to_do=lambda: requests.request(
                method="POST",
                url=url,
                json=body,
                headers=headers,
                timeout=30,
            ),
            is_success=lambda resp: resp.status_code in [200, 204, 404],
            success=lambda resp: resp,
            failed=lambda resp: errors_list.append((resp.status_code, resp)),
            on_exception=lambda ex: errors_list.append(ex),
        )

        if response is not None:
            if response.status_code in [204, 404]:
                return None
            return response.content

        response_error = self._get_response_error(errors_list=errors_list)
        raise ResponseError(
            logger=self.logger,
            response=response_error,
        )

    def check_benefits(
        self,
        pos_id: int,
    ) -> Optional[str]:

        try:
            token = NDiscountTokens.TK_NDISCOUNT_CHECK_BENEFITS
            message = Message(
                token=token,
                data_type=DataType.string,
                data=json.dumps({"posId": str(pos_id)}).encode(),
            )
            response = self.message_bus.send_message(
                component="nDiscount",
                message=message,
            )
            if response.token != DefaultToken.TK_SYS_ACK:
                self.logger.warning("check_benefits: nDiscount returned NAK: {}".format(response.data))
                return ""

            return response.data.decode()
        except Exception as ex:
            self.logger.warning("check_benefits: failed to reach nDiscount: {}".format(ex))
            return None

    def _get_customer_url(
        self,
        loyalty_customer_id: str,
    ) -> Optional[str]:

        base_url = self.configs.credentials[ApplierSubTypes.LOYALTY].base_url
        if not base_url:
            return None

        end_point_url = self.configs.endpoints.retrieve_loyalty_customer_info.format(customerId=loyalty_customer_id)
        full_url = base_url + end_point_url

        self.logger.info("Requesting from get customer info endpoint: {}".format(full_url))

        return full_url

    def _get_benefit_url(
        self,
        voucher_id: str,
        applier_sub_type: str,
    ) -> Optional[str]:

        base_url = self.configs.credentials[applier_sub_type].base_url
        if not base_url:
            return None

        end_point_url = self.configs.endpoints.get_benefit.format(voucherId=voucher_id)
        full_url = base_url + end_point_url

        self.logger.info("Requesting from get benefit endpoint: {}".format(full_url))

        return full_url

    def _get_end_of_sale_notes_url(
        self,
    ) -> Optional[str]:

        base_url = self.configs.credentials[ApplierSubTypes.MARKETING].base_url
        if not base_url:
            return None

        end_point_url = self.configs.endpoints.end_of_sale_notes
        full_url = base_url + end_point_url

        return full_url

    def _get_store_config_url(
        self,
    ) -> Optional[str]:

        base_url = self.configs.credentials[ApplierSubTypes.STORE_CONFIG].base_url
        if not base_url:
            return None

        end_point_url = self.configs.endpoints.get_store_config
        full_url = base_url + end_point_url

        return full_url

    def _get_payment_url(
        self,
        loyalty_customer_id: str,
    ) -> str:

        base_url = self.configs.credentials[ApplierSubTypes.PAYMENT].base_url
        if not base_url:
            return ""

        end_point_url = self.configs.endpoints.payment.format(customerId=loyalty_customer_id)
        full_url = base_url + end_point_url

        self.logger.info("Requesting from payment endpoint: {}".format(full_url))

        return full_url

    def _get_headers(
        self,
        applier_sub_type: str,
        add_content: bool = True,
    ) -> Dict:

        credential = self.configs.credentials[applier_sub_type]
        return self._build_headers(
            credential=credential,
            add_content=add_content,
        )

    def _build_headers(
        self,
        credential: Credential,
        add_content: bool = True,
    ) -> Dict:

        store_id = self.configs.store_id

        headers = {
            "X-Api-Key": credential.api_key,
            "storeId": store_id,
        }

        if add_content:
            headers["Content-Type"] = "application/json; charset=UTF-8"

        if credential.loyalty_store_id:
            headers.update({"LoyaltyStoreId": credential.loyalty_store_id})

        return headers

    def _build_per_method_custom_exception(
        self,
        method_name: str,
        status_code: int,
        response_error: Response,
    ) -> Exception:

        exception_cls = self.exception_map.get(
            status_code,
            self.per_method_exception_map.get(method_name, ResponseError).get(status_code, ResponseError),
        )
        if exception_cls == ClientCustomError:
            return self._build_client_custom_error(response_error=response_error)

        return exception_cls(
            logger=self.logger,
            response=response_error,
        )

    def _build_communication_error(
        self,
    ) -> ProcessorError:

        error_message = "$ERROR_COMMUNICATION_COUPON"
        body = {
            "message": {
                "pt": error_message,
                "en": error_message,
                "es": error_message,
            },
        }

        return CommunicationError(
            message=self._build_translated_message(
                body_dict=body,
                message_field="message",
            ),
        )

    def _build_client_custom_error(
        self,
        response_error: Response,
    ) -> ClientCustomError:

        body = response_error.json()

        if not body:
            error_message = "$ERROR_COUPON_NOT_APPLY"
            body = {
                "message": {
                    "pt": error_message,
                    "en": error_message,
                    "es": error_message,
                },
            }

        return ClientCustomError(
            message=self._build_translated_message(
                body_dict=body,
                message_field="message",
            ),
        )

    def _build_translated_message(
        self,
        body_dict: Dict,
        message_field: str,
    ) -> TranslatedMessage:

        try:
            return TranslatedMessage(
                pt=body_dict[message_field].get("pt", ""),
                en=body_dict[message_field].get("en", ""),
                es=body_dict[message_field].get("es", ""),
            )
        except (KeyError, TypeError, ValueError) as ex:
            self.logger.exception(msg="Invalid response body from partner - {}".format(body_dict), exc_info=ex)
            return TranslatedMessage(
                pt="",
                en="",
                es="",
            )

    def _build_lock_custom_exception(
        self,
        status_code: int,
        response_error: Response,
    ) -> Exception:

        return self._build_per_method_custom_exception(
            method_name="lock",
            status_code=status_code,
            response_error=response_error,
        )

    def _build_unlock_burn_custom_exception(
        self,
        status_code: int,
        response_error: Response,
    ) -> Exception:

        return self._build_per_method_custom_exception(
            method_name="burn",
            status_code=status_code,
            response_error=response_error,
        )

    @staticmethod
    def _get_response_error(
        errors_list: List[Any],
    ) -> Response:

        for last_error in reversed(errors_list):
            if not isinstance(last_error, Exception):
                _, response = last_error
                return response

        last = errors_list[-1]
        if isinstance(last, Exception):
            raise last

        raise RuntimeError("Unexpected error in errors_list: {}".format(last))

    @staticmethod
    def _get_lock_id_from_response(
        response: Response,
    ) -> str:

        if response.status_code == 200:
            content = json.loads(response.content or "{}")
            return content.get("lockId")

        return ""
