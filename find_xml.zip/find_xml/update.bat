set INUTILIZACAO_DRY_RUN=1
C:\edeploypos\python\python.exe main.py update
pause
