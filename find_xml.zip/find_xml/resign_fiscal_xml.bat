@echo off
REM Dispara o token TK_FISCALWRAPPER_RE_SIGN_XML (0x03100014) direto no FiscalWrapper,
REM via mebuhi (HTTP -> Message Bus), sem passar pela tela de gerente do sui.
REM Equivalente a clicar no botao "Resign XML" (RESIGN_XML / doReSignXML).
REM
REM Pre-requisito: o sistema precisa estar de pe (start.bat) no mesmo host, com o
REM mebuhi escutando em MEBUHI_HOST:MEBUHI_PORT (default local: localhost:9494).
REM
REM So reassina XMLs que ja foram marcados via _mark_fiscal_xml_to_re_sign(), o que
REM depende de FiscalWrapper.TotalPreviousDaysReSignFiscalXml > 0 no loader_NFCE.cfg
REM (default = 0, ou seja, desabilitado).

setlocal

set MEBUHI_HOST=localhost
set MEBUHI_PORT=9494
set TOKEN=0x03100014
set SERVICE=FiscalWrapper

set URL=http://%MEBUHI_HOST%:%MEBUHI_PORT%/mwapp/services/%SERVICE%/%SERVICE%?token=%TOKEN%^&format=2^&timeout=30000^&isBase64=false

echo Chamando TK_FISCALWRAPPER_RE_SIGN_XML em %SERVICE% (%MEBUHI_HOST%:%MEBUHI_PORT%)...
curl -sS -X POST "%URL%" -d ""

if errorlevel 1 (
    echo.
    echo Falha ao chamar mebuhi. Verifique se o sistema esta rodando ^(start.bat^) e se
    echo MEBUHI_HOST/MEBUHI_PORT batem com data\server\bundles\mebuhi\loader.cfg.
    exit /b 1
)

echo.
echo Requisicao enviada. Confira data\server\bundles\fiscalwrapper\fiscalwrapper.log
echo para o resultado real do reassino ^("Starting XML Resign Event..."^).

endlocal
