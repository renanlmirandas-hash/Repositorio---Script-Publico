# find_xml — tratamento automático de venda (integração e-deploy / NFCe)

Este documento descreve o que cada script desta pasta faz, como se encaixam entre si, e o
contexto operacional (POS e-deploy, banco fiscal, SEFAZ) necessário para dar manutenção neles.
É complementar ao histórico de migração Python 2→3 (projeto "Tratamento de venda" no Claude,
doc `migracao-python3-find-xml.md`), que registra decisões e correções já aplicadas — este
arquivo foca em **o que o sistema faz hoje**, não no histórico de mudanças.

## Visão geral

**Atualizado em 31/08/2026: o `main.py` (e todos os módulos que ele importa) voltou a rodar com
o Python 2.7 da instalação (pasta `python\`, ao lado de `python3\`), não mais com `python3\`.**
Ver incidente de campo de 31/08/2026 no fim deste documento para o motivo.

O `main.py` é o script principal, disparado por `update.bat` (rodando com
`C:\edeploypos\python\python.exe` — o caminho real do interpretador varia por loja, ver seção
"Ambientes/instalações" abaixo) em cada terminal de loja. Ele lê um arquivo CSV
(`file_csv/bkoffice.csv`) contendo números de nota vindos do backoffice, localiza a venda
correspondente no banco local de pedidos do POS, verifica o estado fiscal dessa nota (autorizada,
em contingência, cancelada, etc.) e corrige inconsistências entre o banco de pedidos e o banco
fiscal (`fiscal_persistcomp.db`). Ao final, também roda uma rotina de atualização de componentes
do sistema (`fix_apply.py`).

Além do fluxo principal, a pasta reúne um conjunto de scripts standalone de suporte/correção —
recuperar pedidos apagados, preencher parâmetros fiscais faltantes, reconstruir o XML da NFC-e,
etc. — usados manualmente quando algo dá errado numa loja específica.

## Fluxo principal (`main.py`)

1. **Detecta a instalação** via `get_system_version()` (`consulte_csv.py`): procura, nessa
   ordem, `C:\mwpos`, `C:\edeployPOS`, `C:\edeploy-pos-structure` (Windows) ou
   `/home/administrador/edeployPOS` (Linux), caindo em `/home/administrador/mwpos_server` como
   default. Isso define os caminhos de banco de dados, backups e binários usados no resto do
   script.
2. **Lê `file_csv/bkoffice.csv`** (`ler_arquivo_csv` / `file_valor_sentto`, em `consulte_csv.py`):
   cada linha do CSV traz um número de nota (`numeronota`) separado por `;`.
3. **Localiza a venda no banco local** (`find_fiscal_id`, `sqlite_update.py`): varre os arquivos
   `order.db<N>` (um por POS/caixa) procurando, em `OrderCustomProperties`, a linha onde
   `Key = 'FISCAL_ID'` bate com o número de nota do CSV. Retorna `orderid`, `nota` e o caminho do
   banco onde a venda foi encontrada.
4. **Para cada venda encontrada, decide o que fazer** (`time_direction`, em `consulte_csv.py`) —
   ver seção dedicada abaixo, é o coração da lógica de negócio.
5. **Roda a atualização de componentes** (`main_fix()`, `fix_apply.py`) — sempre, independente do
   resultado do passo 4.
6. Loga início/fim em `system_script.log` (formato `timestamp - LEVEL - mensagem`, UTF-8).

### `time_direction` — a lógica de decisão fiscal

Recebe o histórico de estados de uma venda (`orderstatehistory`) e decide a ação com base na
combinação de estados:

- **Void + Paid presentes, void ocorreu ≥30min depois do paid**: marca a venda como "cancelada"
  no fluxo interno (`updater_aped_20805`, com status "cancelada") e não segue adiante — é uma
  venda cancelada normalmente, fora da janela de contingência.
- **Void + Paid presentes, void <30min depois do paid**: trata como cancelamento normal dentro da
  janela aceitável (`updater_aped_20805`, sem status).
- **Paid sem Void** (venda paga e não cancelada) — o caso mais importante:
  - Aguarda 7s (dar tempo do XML fiscal ser gravado) e lê a custom property `FISCAL_XML` da
    venda (XML da nota em base64).
  - Decodifica o `cStat` (código de status da SEFAZ) desse XML via `DecodeBase64`
    (`decode_base64.py`).
  - **Se `cStat` é 100 ou 150** (autorizada): compara com o `cStat` que está gravado no banco
    fiscal (`fiscal_persistcomp.db`, via `validate_status`). Se divergem, atualiza o banco fiscal
    com o XML mais recente (`update_xml_APED23848`) e retorna 5 (nota corrigida). Se já batem,
    apenas confirma e retorna 5.
  - **Se `cStat` indica contingência** ("Problemas de conexao com a SEFAZ" ou "Notas anteriores
    em contingencia"): antes de mais nada, tenta corrigir o protocolo automaticamente via
    `FixingCstatCupons.find_key_pattern` (ver seção "Correção de protocolo" abaixo). Depois,
    monta um registro `FiscalData` com os dados da venda e:
    - Se já existe registro fiscal para esse `orderid` (`sales_inquiry`), atualiza o XML
      (`update_xml_APED23848`).
    - Senão, insere um novo registro (`insert_fiscal_faltante`) — essa é a rotina que
      "recupera" notas que ficaram sem registro no banco fiscal.
  - Também existe um bloco (`order_disabled`/`xml_fiscal_disabled`) para tratar inutilização
    incorreta (`cStat` 206/256/102 quando deveria estar ativa) e corrigir a sequência fiscal
    (`seq_fiscal`/`seq_update`/`update_fiscal_order`) — mas hoje essas variáveis nunca são
    setadas como `True`/valor no código atual, então esse ramo é efetivamente inatingível como
    está escrito (possível dívida técnica/código morto a revisar).
- **Void sem Paid** (cancelada antes de ser paga): olha a custom property
  `DISABLED_FISCAL_XML`/`ORDER_DISABLED` e loga o motivo (cStat 563, 102, ou sequência quebrada
  via `ORDER_DISABLED`) — não faz alteração no banco além do log, é diagnóstico.
- **Nem Void nem Paid**: consulta o estado atual da venda (`consulte_orderid`) e só loga.
- **Estado 6 (recalled)**: interrompe o processamento dessa venda sem mais ação.

### Correção automática de protocolo (`FixingCstatCupons`, `fix_protocolo_cupons.py`)

**Atualizado em 31/08/2026: `FixingCstatCupons` mora agora só em `fix_protocolo_cupons.py`.**
Não existe mais `fix_cupom_protocol.py` (removido a pedido do usuário — a classe estava separada
do CLI em dois arquivos, e passou a viver num arquivo só, sem import cruzado entre eles).
`consulte_csv.py` e `main.py` foram atualizados para importar de `fix_protocolo_cupons.py`.

Quando uma venda está em contingência, o `main.py` tenta corrigir sozinho o protocolo da nota
antes de cair no fluxo manual de `FiscalData`. Como isso funciona:

- `FixingCstatCupons` abre uma conexão com o barramento e-deploy (`MBEasyContext`) e importa o
  SDK proprietário (`msgbus`, `cfgtools` de `common.pypkg`; `old_helper`, `bustoken` de
  `edpcommon.pypkg`) dentro da instalação. Essa conexão é cara de abrir, então o `main.py` a
  reaproveita durante toda a execução via `_obter_fixing_cstat_cupons()` (uma única instância em
  cache). Se a loja não for NFCE (não existe `loader_NFCE.cfg`) ou a conexão falhar por qualquer
  motivo, a correção fica marcada como indisponível pelo resto da execução e o fluxo normal
  continua sem ela.
  **Desde 31/08/2026 isso funciona de verdade dentro do `main.py`.** `old_helper.pyc`/
  `bustoken.pyc` (em `edpcommon.pypkg`) só existem compilados para **Python 2.7** (magic number
  62211) em qualquer instalação testada — não existe `edpcommon3.pypkg`. Como o `main.py` agora
  roda com o Python 2.7 da instalação (não mais Python 3), esses dois módulos resolvem
  normalmente e a correção automática por venda passa a funcionar de fato (antes, rodando em
  Python 3, o `except Exception` sempre capturava `ImportError` aqui — ver incidente de campo de
  28/08/2026 (2) para o histórico completo dessa investigação).
- `find_key_pattern(orderid)` varre o `FiscalWrapperThread.log` procurando a linha que o
  `nfce.py` (parte do SDK e-deploy) grava quando detecta e tenta corrigir sozinho um `cStat` 539
  (duplicidade de chave de acesso), 100, 150 ou 204 — do tipo:
  `"... nfce.py:...:_handle_duplicated_diff_key - Tratando 539 da order 000123413 ...
  Chave de Acesso <44 dígitos>"`. Extrai o `cStat` e a chave de acesso que a SEFAZ já reconhece
  para essa nota, e chama `fix_cstat` para essa nota específica. **Desde 31/08/2026 (2)**, também
  tenta um segundo formato como fallback quando o primeiro não bate na linha/arquivo: a SEFAZ às
  vezes manda a chave entre colchetes, prefixada por `chNFe:` (`"... Chave de Acesso
  [chNFe:<44 dígitos>]"`, em vez de `"... Chave de Acesso <44 dígitos>"` puro) —
  `RE_PATTERN_LOTE_CHNFE`, em `fix_protocolo_cupons.py`, cobre esse caso. O mesmo fallback existe
  em `encontrar_pendentes`/`corrigir_lote` (modo lote) e é usado tanto pela correção automática
  por venda quanto pelo CLI.
- `fix_cstat(orderid, key, cstat)` pega o `FISCAL_XML` atual da venda (via `get_order_picture`,
  mensagem ao barramento), troca a chave de acesso incorreta pela chave correta encontrada no
  log, remonta o XML com um protocolo de aceite (`cStat 204`, motivo "Duplicidade de NF-e") e
  grava de volta em `fiscal_persistcomp.db` (`update_fiscal_persist`). Retorna `True`/`False` (não
  levanta exceção) — assim tanto `find_key_pattern` (uma nota, chamado automaticamente pelo
  `main.py`) quanto `corrigir_lote` (várias notas, ver abaixo) conseguem seguir adiante sem se
  preocupar em capturar exceção nota a nota.
- **`encontrar_pendentes(order_ids=None, cstats_alvo=...)` e `corrigir_lote(order_ids=None,
  dry_run=False)`** (adicionados em 31/08/2026): a mesma lógica de `find_key_pattern`/`fix_cstat`,
  generalizada para várias notas de uma vez. `encontrar_pendentes` lê o(s)
  `FiscalWrapperThread.log*` **linha a linha** (nunca carrega o arquivo inteiro na memória) e do
  **mais novo pro mais antigo**; se `order_ids` for passado, para de abrir arquivos mais antigos
  assim que todos os pedidos já foram encontrados (early exit) — evita varrer o histórico inteiro
  quando já se sabe quais notas corrigir. `corrigir_lote` chama `fix_cstat` para cada nota
  encontrada e retorna `(total_encontrado, total_corrigido, total_falhou, nao_encontrados)`. Essas
  duas rotinas são o que o CLI no fim de `fix_protocolo_cupons.py` usa quando o arquivo é rodado
  direto (ver seção "Scripts standalone" abaixo) — é tudo o mesmo arquivo agora, sem duplicação.
- `process_resign` / `process_unused_orders` são rotinas mais amplas (não chamadas pelo
  `main.py` no fluxo atual, existem para execução manual/futura): a primeira varre um período de
  60 dias procurando notas pendentes de envio à SEFAZ e força reenvio; a segunda identifica
  pedidos indevidamente "não usados"/inutilizados e limpa a flag `ORDER_DISABLED`.

### Atualização de componentes (`fix_apply.py`)

Depois do processamento das vendas, `main_fix()` sempre roda: lê a versão instalada
(`get_version()`, em `util.py`, consulta `pos_updater.db`) e, se bater com uma das versões
mapeadas (`CORE:4.2.0|SRC:25.08.11`, `CORE:5.2.3|SRC:26.02.11`, `CORE:5.2.6|SRC:26.05.06`,
`CORE:5.3.0|SRC:26.05.12`), copia os bundles correspondentes da pasta `repository/<versão>/update/`
para `C:\edeploypos\genesis\src\` e `C:\edeploypos\src\` (removendo `.pyc` antigos antes, via
`distutils.dir_util.copy_tree` — voltou a ser `copy_tree` em vez de
`shutil.copytree(..., dirs_exist_ok=True)` porque `dirs_exist_ok` só existe a partir do Python
3.8 e o script agora roda em Python 2.7) e reinicia o componente afetado (`restart_component`,
via `hv -o <componente>`, usando os nomes `remoteorder`, `fiscalwrapper`, `npersistcomp`). Se a
versão instalada já tiver a correção (nenhuma das quatro acima), levanta `ValueError` e não faz
nada — é esse erro que aparece como "Unable to get system version" no log quando a máquina não é
um terminal POS real (não tem `pos_updater.db`).

## Módulos de apoio

- **`consulte_csv.py`**: núcleo da lógica de negócio (`time_direction`, detecção de instalação,
  leitura do CSV) — descrito acima.
- **`sqlite_update.py`**: toda a camada de acesso a SQLite usada pelo fluxo principal — consultas
  e updates em `order.db<N>` (pedidos), `fiscal_persistcomp.db` (dados fiscais) e
  `tblservice.db`. Inclui as funções de correção pontual `updater_aped_20805` (cancelamento),
  `updater_OXAP_5832`, `updater_aped_20805_unpaid` (várias delas nomeadas por número de chamado/
  bug interno — APED-xxxxx, OXAP-xxxx).
- **`decode_base64.py`**: `DecodeBase64` decodifica um XML de nota (base64) e extrai o `cStat` —
  seja de `protNFe/infProt/cStat` (nota normal), `cStat` direto (nota inutilizada) ou
  `infNFe/ide/xJust` (motivo de contingência/justificativa, quando não há cStat numérico ainda).
- **`util.py`**: `get_version()` lê a última atualização aplicada em `pos_updater.db`;
  `restart_component()` reinicia um componente via `hv -o`.
- **`time_hora.py`**: `datetime_to_float` converte timestamp de string para epoch (usado ao
  montar o registro `FiscalData`).
- **`xml_file.py`**: utilitário genérico de listagem recursiva de arquivos (`get_xmls_list`) —
  não está no caminho crítico do fluxo atual.
- **`order_picture.py`** (`StandAlone_OrderPicture`) e **`send_orderpaid_boh.py`**
  (`StandAlone`): classes para, dado um `orderid`, buscar o "order picture" completo da venda no
  barramento e-deploy e (no caso de `send_orderpaid_boh.py`) montar o payload e enviar ao BOH
  (back office) via HTTP (`POST /pump/sale/order-picture`). **Não são chamadas em nenhum ponto
  ativo do `main.py` hoje** — só há uma referência comentada em `time_direction`
  (`#StandAlone(xml_file.get("orderid"))` quando `order_statr == 5`). Ficam prontas para reativar
  quando for decisão de negócio enviar pedidos pagos ao BOH nesse ponto do fluxo.

## Scripts standalone (uso manual, sob demanda)

Não fazem parte do fluxo automático do `main.py` — são rodados manualmente quando uma loja
reporta um problema específico:

- **`fix_protocolo_cupons.py`** — **atualizado em 31/08/2026: é o único arquivo, contém tanto a
  classe `FixingCstatCupons` quanto o CLI por cima dela** (antes eram dois arquivos, um deles
  `fix_cupom_protocol.py`, removido). Quando importado (por `consulte_csv.py`, para a correção
  automática por venda) só a classe é usada; quando rodado direto (`python fix_protocolo_cupons.py
  ...`), o CLI no fim do arquivo decide **quais** notas corrigir e chama os métodos da classe.
  Roda com o Python 2.7 da instalação (`python\python.exe`) — igual ao `main.py`, já que os dois
  usam o mesmo arquivo/classe agora. Flags de seleção do CLI (uma obrigatória, mutuamente
  exclusivas):
  - `--order-ids ID1 [ID2 ...]` — corrige só essas notas específicas.
  - `--order-ids-file ARQUIVO` — corrige as notas listadas num arquivo (um orderid por linha,
    `#` comenta a linha).
  - `--all-pendentes` — corrige TODAS as notas com cStat corrigível encontradas no log.
  - `--listar` — só lista as notas pendentes (todas, ou as de `--order-ids`/`--order-ids-file`),
    sem corrigir nada.

  Mais `--dry-run` (mostra sem gravar), `-y`/`--yes` (não pede confirmação) e `--app-path` (força
  o caminho da instalação — sem isso, o CLI importa `get_system_version` de `consulte_csv.py` só
  na hora de rodar, para não criar import circular com o uso automático pelo `main.py`). Loga em
  `fix_protocolo_cupons.log` (mesmo `getLogger("FixingCstatCupons")` que a classe usa) + console.
  Uso:
  `C:\edeploy-pos-structure\python\python.exe fix_protocolo_cupons.py --order-ids 123413 123999 [--dry-run] [--yes]`.
  O CLI não está integrado ao fluxo automático do `main.py` por venda (decisão deliberada,
  28/08/2026) — roda manualmente ou agendado, pra lidar com acúmulo de notas presas. Existe um
  `cstat_539.bat` na pasta (criado pelo usuário) que chama esse script com `--order-ids` — **hoje
  está sem os números de nota depois da flag**, então precisa ser completado antes de rodar
  (`argparse` vai recusar com "expected at least one argument" do jeito que está).
- **`backfill_fiscal_params_from_order.py`**: quando um produto não tem parâmetro fiscal
  cadastrado em `fiscal_params.db` (NCM, CFOP, CST_ICMS, CST_PIS, CST_COFINS, CSOSN, CEST) e isso
  impede reconstruir o XML de uma nota, este script lê o `FISCAL_XML` já aceito pela SEFAZ de uma
  nota existente e usa esses valores oficiais para preencher os parâmetros faltantes — nunca
  sobrescreve o que já existe. Faz backup do banco antes de gravar. Uso:
  `python backfill_fiscal_params_from_order.py <numero_nota> [--dry-run] [--yes]`.
- **`restore_order_from_backup.py`**: dado um ou mais números de nota (`FISCAL_ID`), procura o
  pedido primeiro nas bases correntes (`order.db<N>`), depois nos backups mensais
  (`orders_*.db`), e em último caso reconstrói o pedido a partir do `OrderPicture` salvo no
  próprio registro fiscal (`FiscalData`) — essa reconstrução é best-effort e não recupera
  histórico de cancelamento nem taxas de delivery. Também garante/restaura o registro fiscal
  correspondente. Sempre faz backup antes de gravar. Uso:
  `python restore_order_from_backup.py <notas...> [--pos N] [--backup-file NOME] [--dry-run] [--yes]`.
- **`backfill_missing_order.py`**: usa o SDK novo do e-deploy (`common3.pypkg`,
  `mbcontextmessagehandler`, `order_api`) para buscar pedidos direto do serviço de pedidos
  (`OrderService`) por `orderid` e inserir/backfillar entradas no audit log
  (`auditlogger_services`) quando ainda não constam lá — usado para recuperar eventos de
  voided/stored que não chegaram a ser auditados. Uso:
  `run_backfill_missing_order.bat <ORDER_ID> [ORDER_ID2 ...] [--force]` (o `.bat` já resolve o
  caminho do `python3` e a pasta de saída do audit log).
- **`fiscal_reprocessa_nfeproc.py`**: reconstrói o XML `nfeProc` completo (envelope com
  `<NFe>` + `<protNFe>`) de uma nota já autorizada, juntando o XML de venda salvo em
  `fiscal_persistcomp.db` com a chave de acesso e `cStat` encontrados no log do fiscalwrapper
  (padrão `"Order <n>: chave autorizada <44 dígitos> retornou cStat 100"`). Salva um backup local
  em `output_nfeproc/` antes de gravar de volta no banco. Os nomes de tabela/coluna
  (`fiscaldata`/`orderid`/`xmlrequest`) são um "melhor palpite" documentado no próprio arquivo —
  usar `--list-tables`/`--describe-table` para confirmar antes de rodar em uma instalação nova.

## Ambientes / instalações reconhecidas

O código reconhece três variações de instalação e-deploy, cada uma com seu próprio caminho base
(detectado por `get_system_version()` em `consulte_csv.py`, ou fixo como default nos scripts
standalone via `DEFAULT_DB_DIR`/`DB_PATH`):

| Instalação | Caminho base | Observação |
|---|---|---|
| `mwpos` | `C:\mwpos` ou `/home/administrador/mwpos_server` | default quando nada mais é encontrado |
| `edeployPOS` | `C:\edeployPOS` | usado como default nos scripts standalone (`DEFAULT_DB_DIR`) |
| `edeploy-pos-structure` | `C:\edeploy-pos-structure` | instalação mais recente |

**Atenção**: desde 31/08/2026 o `main.py` roda com `python\python.exe` (2.7), não mais com
`python3\python.exe` — ver incidente de campo de 31/08/2026. Toda instalação testada até agora
tem as duas pastas (`python\` e `python3\`) lado a lado; `python3\` continua existindo mas não é
mais usada pelo `main.py`. Se um erro mencionar `ImportError`/`bad magic number`, suspeitar
primeiro de estar rodando com o interpretador errado antes de assumir bug de lógica.

## Bancos de dados envolvidos

- **`order.db<N>`** (um por POS/caixa, `N` = número do caixa): tabelas `Orders`,
  `OrderCustomProperties` (incluindo `FISCAL_ID`, `FISCAL_XML`, `DISABLED_FISCAL_XML`,
  `ORDER_DISABLED`), `OrderStateHistory`, `OrderItem`, `OrderTax`, `OrderTender`, etc.
- **`fiscal_persistcomp.db`**: tabela `FiscalData` (`PosId`, `OrderId`, `XMLRequest`,
  `NumeroNota`, `SentToNfce`, `OrderPicture`, `DataNota`, ...) e `sequencer` (sequência do
  `FiscalId`).
- **`tblservice.db`**: tabela `serviceorders` (relaciona `orderid`/`posid` para pedidos remotos/
  delivery).
- **`pos_updater.db`**: tabela `updatescontroller`, usada só por `util.get_version()` para saber
  a última atualização de sistema aplicada.
- **`fiscal_params.db`**: tabela `FiscalParameter` (catálogo de classificação tributária por
  produto), usado só por `backfill_fiscal_params_from_order.py`.

## Log

Tudo grava em `system_script.log`, na pasta do script, formato
`timestamp - LEVEL - mensagem`, UTF-8. `FixingCstatCupons` usa um `getLogger("FixingCstatCupons")`
que propaga para esse mesmo log (só serve para identificar a origem das linhas, não abre arquivo
separado).

## Diagnóstico de `.pypkg`

`diagnose_pypkg.py` (nesta pasta) abre cada `.pypkg` da instalação (são arquivos zip, mesmo sem
extensão `.zip`) e procura em qual deles cada módulo do SDK (`old_helper`, `msgbus`, `bustoken`,
`cfgtools`, `mbcontextmessagehandler`, `order_api`) realmente está — sem precisar importar nada
(evita efeitos colaterais de conectar no barramento e-deploy). Útil sempre que um `ModuleNotFoundError`
aparecer envolvendo esses módulos, já que o layout dos `.pypkg` varia entre instalações. Uso:
`<python3 da loja> diagnose_pypkg.py`.

## Incidentes de campo conhecidos

### 28/08/2026 (1) — `ValueError: Unrecognised argument(s): encoding` ao rodar `main.py` numa loja

O `logging.basicConfig(..., encoding='utf-8')` original só funciona em Python 3.9+. Uma loja
tinha `python3\python.exe` numa versão anterior a 3.9, o que quebrava o script antes mesmo de
processar qualquer venda. Corrigido substituindo o `basicConfig` por configuração manual do
handler (`logging.FileHandler(log_filename, encoding='utf-8')` + `addHandler`), que produz o
mesmo resultado mas funciona em qualquer Python 3.x. Recomenda-se checar
`python3\python.exe --version` nas demais lojas para saber quantas ainda estão com runtime
desatualizado.

### 28/08/2026 (2) — `ModuleNotFoundError: No module named 'old_helper'` numa loja — causa raiz revista

Depois de corrigir o incidente (1), uma execução em outra loja (`C:\edeployPOS`) rodou até o fim
normalmente, mas logou que não conseguiu conectar ao `FixingCstatCupons` por falta do módulo
`old_helper` — o `except Exception` em `_obter_fixing_cstat_cupons()` capturou isso e a venda foi
processada normalmente pelo fluxo padrão, só sem a correção automática de protocolo.

Rodando `diagnose_pypkg.py` nessa loja, confirmou-se que `edpcommon3.pypkg` **não existe** ali —
`old_helper`/`bustoken` continuam em `edpcommon.pypkg` (o pacote "antigo"). Primeira correção
aplicada: `sys.path` no arquivo que continha `FixingCstatCupons` na época (`fix_cupom_protocol.py`,
depois removido em 31/08 — ver incidente próprio abaixo) /`order_picture.py`/`send_orderpaid_boh.py`
passou a apontar para `edpcommon.pypkg` em vez do inexistente `edpcommon3.pypkg`.

**Essa correção resolveu o caminho errado, mas não o problema de fundo.** Investigando mais a
fundo numa instalação de teste (`C:\edeploy-pos-structure`) onde o mesmo erro persistiu mesmo com
o caminho certo, comparei o magic number dos `.pyc` dentro de cada `.pypkg`:

| Pacote | Módulo | Magic number | Versão real do bytecode |
|---|---|---|---|
| `common3.pypkg` | `msgbus`, `cfgtools` | 3413 | Python 3.8 (build 3 de verdade) |
| `common.pypkg` | `msgbus`, `cfgtools` | 62211 | Python 2.7 |
| `edpcommon.pypkg` | `old_helper`, `bustoken` | 62211 | **Python 2.7** |

Ou seja: **`old_helper`/`bustoken` só existem compilados para Python 2.7, em todas as instalações
testadas até agora — não existe build Python 3 desses dois módulos em lugar nenhum** (diferente de
`msgbus`/`cfgtools`, que têm build 3 de verdade em `common3.pypkg`). Isso significa que
`FixingCstatCupons`, chamado a partir do `main.py` (Python 3), **nunca vai conseguir conectar** —
não é um problema de `sys.path`, é uma peça que falta no SDK do e-deploy para Python 3. O
`except Exception` que já existia em `_obter_fixing_cstat_cupons()` está certo em continuar
capturando esse erro e deixar a venda seguir pelo fluxo normal — isso não é um bug a mais para
corrigir, é o comportamento esperado enquanto essa build não existir.

**Decisão tomada (28/08/2026)**: em vez de tentar forçar isso a funcionar em Python 3, criado o
`fix_protocolo_cupons.py` — um script separado que roda com o Python 2.7 da própria instalação
(pasta `python\`, que existe ao lado de `python3\` em toda instalação e-deploy testada até agora)
e corrige as notas em lote, já que a correção manual nota a nota não escala quando acumula várias.
Ver seção própria em "Scripts standalone" acima. Decisão explícita: **não** integrar isso ao fluxo
automático do `main.py` via subprocess por venda (avaliado e descartado por enquanto — adicionaria
latência por venda) — o script roda manualmente ou agendado.

Também identificado no mesmo diagnóstico: `mbcontextmessagehandler` e `order_api` (usados por
`backfill_missing_order.py`) não existem em nenhum `.pypkg` da loja testada — esse script
standalone pode não funcionar nela.

### 31/08/2026 — `main.py` volta a rodar em Python 2.7; correção de protocolo consolidada

Decisão explícita do usuário: em vez de manter `fix_protocolo_cupons.py` como um script separado
duplicando ~200 linhas de `FixingCstatCupons` (a única forma de ter a correção automática por
venda funcionando de verdade, já que `old_helper`/`bustoken` só existem em Python 2.7 — ver
incidente de 28/08/2026 (2) acima), o `main.py` e todos os módulos que ele importa voltaram a
rodar com o Python 2.7 da instalação (pasta `python\`, ao lado de `python3\`). Isso faz a
correção automática de protocolo por venda (`_tentar_corrigir_protocolo_cupom`, em
`consulte_csv.py`) funcionar nativamente pela primeira vez em produção, sem precisar de
subprocess nem de rodar um Python separado por venda.

Mudanças aplicadas:
- `fix_apply.py`: `shutil.copytree(..., dirs_exist_ok=True)` → `distutils.dir_util.copy_tree`
  (`dirs_exist_ok` só existe a partir do Python 3.8).
- `fix_cupom_protocol.py` (na época), `order_picture.py`, `send_orderpaid_boh.py`: `sys.path`
  voltou a apontar para `common.pypkg` (em vez de `common3.pypkg`) — com o interpretador agora
  sendo 2.7, usar a build 3.8 de `msgbus`/`cfgtools` quebraria com "bad magic number".
  `edpcommon.pypkg` já estava certo (é a build 2.7, não mudou).
- `find_key_pattern` usava `open(file, encoding="utf-8", errors="replace")` — o `open()` nativo
  do Python 2.7 não aceita esses parâmetros (só existem no `open()` built-in a partir do Python
  3). Trocado por `io.open`, que aceita `encoding`/`errors` em ambas as versões. Esse era um bug
  latente que só ia aparecer quando o script voltasse a rodar em 2.7 de verdade.
- `FixingCstatCupons.fix_cstat` agora retorna `True`/`False` em vez de relançar a exceção (o
  traceback completo continua indo pro log via `self.logger.exception`) — necessário para
  `corrigir_lote` conseguir seguir para a próxima nota quando uma falha, sem interromper o lote
  inteiro.
- **Primeira rodada de consolidação ("integrar a correção do protocolo para não ficar em 1
  arquivo só")**: `encontrar_pendentes`/`corrigir_lote` (que antes existiam só em
  `CorrecaoProtocoloLote`, dentro de `fix_protocolo_cupons.py`) foram movidos para dentro de
  `FixingCstatCupons` (então ainda em `fix_cupom_protocol.py`), junto com `find_key_pattern`/
  `fix_cstat`/`get_order_picture`/`application_conn`, que já estavam lá. **Essa primeira rodada
  deixou dois arquivos** (`fix_cupom_protocol.py` com a classe, `fix_protocolo_cupons.py` como
  CLI fino por cima dela) — removido logo depois, no mesmo dia, ver incidente seguinte.
- `update.bat` também precisou mudar: `C:\edeploypos\python3\python.exe main.py update` →
  `C:\edeploypos\python\python.exe main.py update`.

### 31/08/2026 (2) — `fix_cupom_protocol.py` removido; tudo em `fix_protocolo_cupons.py`

Pedido explícito do usuário, no mesmo dia da mudança acima: *"Vamos remover esse
fix_cupom_protocol.py e deixa o arquivo novo fix_protocolo_cupons.py"*. A classe
`FixingCstatCupons` (com todos os métodos: `application_conn`, `find_key_pattern`,
`key_pattern_fiscallog`, `fix_cstat`, `encontrar_pendentes`, `corrigir_lote`, `process_resign`,
`process_unused_orders`, etc.) foi movida de `fix_cupom_protocol.py` para dentro de
`fix_protocolo_cupons.py`, junto com o CLI que já estava lá. `fix_cupom_protocol.py` foi
substituído por um stub de texto avisando que pode ser apagado (não consigo apagar arquivos na
máquina do usuário remotamente — só sobrescrever conteúdo).

Ajustes de import necessários:
- `consulte_csv.py`: `from fix_cupom_protocol import FixingCstatCupons` →
  `from fix_protocolo_cupons import FixingCstatCupons`.
- `main.py`: tinha um `from fix_cupom_protocol import *` que não usava nada diretamente (o
  `FixingCstatCupons` que o `main.py` eventualmente precisa já chega via `from consulte_csv import
  *`, que reexporta o nome). Removido em vez de repontar, pra não poluir o namespace do `main.py`
  com nomes do CLI (`argparse`, `parse_args`, `main`, etc.) que um `import *` de
  `fix_protocolo_cupons.py` traria.
- Dentro do próprio `fix_protocolo_cupons.py`: o `import` de `get_system_version` (de
  `consulte_csv.py`, usado só pelo CLI quando `--app-path` não é passado) foi movido para dentro
  da função `main()` do CLI, em vez de ficar no topo do arquivo — um import de nível de módulo
  criaria um import circular real (`consulte_csv.py` importa `fix_protocolo_cupons.py` no topo, e
  se `fix_protocolo_cupons.py` importasse `consulte_csv.py` de volta no topo também, o Python
  quebraria tentando resolver `get_system_version` antes dela existir). Como import circular só
  ocorre se as duas pontas importam a outra no nível de módulo, e o CLI só roda quando o arquivo é
  executado direto (não quando é importado como biblioteca), um import atrasado (dentro da função)
  resolve sem problema.

**Não consegui testar isso rodando Python 2.7 de verdade** (não existe mais nos repositórios
usados por este ambiente) — revisão foi manual, com `py_compile` sob Python 3 como checagem de
sintaxe (não prova compatibilidade de runtime 2.7, só ausência de erro de sintaxe). Recomendado
testar numa loja de homologação antes de depender disso em produção.

### 31/08/2026 (3) — `RE_PATTERN_LOTE` não cobre o formato `"[chNFe:...]"` que a SEFAZ manda

Pedido do usuário (com diff pronto) apontando que, em produção, o `xMotivo` da SEFAZ às vezes vem
com a chave de acesso entre colchetes e prefixada por `chNFe:` (`"... Chave de Acesso
[chNFe:52260817261661005566650010001226111137067129]"`), em vez do formato "puro" que o regex
original esperava (`"... Chave de Acesso 52260817261661005566650010001226111137067129"`). O `[`
logo depois de `"Chave de Acesso "` faz o grupo `([0-9]{44})` falhar de cara nesse caso, então
essas linhas nunca batiam — nem no `find_key_pattern` (correção automática por venda) nem em
`encontrar_pendentes`/`corrigir_lote` (modo lote).

Corrigido adicionando um segundo padrão (`RE_PATTERN_LOTE_CHNFE` no nível do módulo, e o
equivalente `re_pattern_chnfe` construído por orderid dentro de `find_key_pattern`) usado como
**fallback**: primeiro tenta o formato clássico, e só tenta o formato com colchete/label se o
primeiro não encontrar nada naquele arquivo/linha. Aplicado nos três lugares que faziam essa
varredura (`find_key_pattern`, `encontrar_pendentes`, e por consequência `corrigir_lote`/CLI, que
chamam `encontrar_pendentes`) — sem duplicar a lógica de fallback em cada um, só o padrão
alternativo em si.

### 31/08/2026 (4) — `SyntaxError: Non-ASCII character` ao rodar `main.py update` de verdade em Python 2.7

Usuário reportou (com print do terminal) que `main.py update` quebrava assim que rodado de fato
com o Python 2.7 da instalação (`C:\edeploypos\python\python.exe`, pasta `C:\edeployPOS\find_xml`):

```
File "C:\edeployPOS\find_xml\send_orderpaid_boh.py", line 18
SyntaxError: Non-ASCII character '\xc3' in file ... but no encoding declared
```

**Causa raiz**: PEP 263 — todo arquivo-fonte Python 2.7 que contém bytes não-ASCII precisa
declarar o encoding na 1ª ou 2ª linha (`# -*- coding: utf-8 -*-`); sem isso o interpretador recusa
o arquivo assim que encontra o primeiro byte não-ASCII. Python 3 não tem essa exigência (assume
UTF-8 por padrão), então esse tipo de bug fica invisível em qualquer checagem feita sob Python 3 —
inclusive o `py_compile` usado neste ambiente para validar sintaxe, que **não** pega esse
problema porque ele mesmo roda em Python 3. Só aparece rodando com um interpretador 2.7 de
verdade, como o usuário fez.

`order_picture.py` e `send_orderpaid_boh.py` ganharam comentários em português com acentos durante
o trabalho de volta pro Python 2.7 (28-31/08/2026) mas ficaram sem a declaração de encoding — os
dois quebravam. Corrigido adicionando `# -*- coding: utf-8 -*-` como primeira linha dos dois.
Também adicionada preventivamente em `fix_apply.py` e `decode_base64.py` (hoje só ASCII, mas sem a
declaração — um futuro comentário acentuado quebraria os dois do mesmo jeito, silenciosamente).

Checagem feita varrendo os 12 arquivos principais em busca da declaração e de bytes não-ASCII;
confirmado que os 4 arquivos corrigidos agora têm a declaração e passam em `py_compile`.

**Importante — alcance da correção**: os 4 arquivos corrigidos foram commitados no repositório git
(`C:\Automação\Git - Privado\Script---Privado\xml_venda\find_xml`), que é a pasta conectada a esta
sessão. A pasta onde o erro realmente aconteceu, `C:\edeployPOS\find_xml`, **não está conectada a
esta sessão** — a correção não chega lá sozinha. É preciso levar os arquivos corrigidos
(`order_picture.py`, `send_orderpaid_boh.py`, `fix_apply.py`, `decode_base64.py`) manualmente até
`C:\edeployPOS\find_xml` (cópia direta, git pull, ou conectando essa pasta a uma sessão) antes de
testar de novo lá.

**Achado à parte, ainda não sincronizado**: `C:\edeploy-pos-structure\find_xml` (uma das pastas
conectadas) está com uma cópia antiga, de ~28/08/2026, anterior a toda a volta pro Python 2.7 e à
consolidação do `fix_protocolo_cupons.py` — inclusive ainda tem o `fix_cupom_protocol.py` antigo,
nunca tocado. É uma terceira instalação, separada tanto do repo git quanto do `C:\edeployPOS`. Não
mexi nela ainda; fica registrado aqui até decidirmos se/como sincronizar.

### 31/08/2026 (5) — `UnicodeDecodeError: 'ascii' codec ...` ao logar mensagem com acento (rodando com `C:\Python27\python.exe`)

Depois do fix do item (4), usuário testou rodando `main.py` direto com um Python 2.7 diferente
(`C:\Python27\python.exe`, não o `C:\edeploypos\python\python.exe` da instalação — parece um
Python 2.7 do sistema/IDE, rodando a partir da própria pasta do repo git) e bateu num erro
diferente, agora dentro do próprio `logging`:

```
File "C:\Python27\lib\logging\__init__.py", line 891, in emit
    stream.write(fs % msg.encode("UTF-8"))
UnicodeDecodeError: 'ascii' codec can't decode byte 0xc3 in position 53: ordinal not in range(128)
Logged from file main.py, line 54
```

**Causa raiz**: `main.py` linha 19 configurava o handler de log assim:
`logging.FileHandler(log_filename, encoding='utf-8')`. Passar `encoding=` faz o `FileHandler`
abrir o arquivo via `codecs.open()`, cujo `stream.write()` só aceita `unicode` — se receber um
`str` comum (bytes), tenta decodificá-lo primeiro com o codec padrão (`ascii`) antes de
recodificar. Em Python 2.7, uma string literal como `"Validando as informações do arquivo
bkoffice.csv"` (linha 54 do `main.py`) é um `str` já em bytes UTF-8 (por causa do `# -*- coding:
utf-8 -*-` no topo do arquivo) — não é `unicode`. Assim que essa mensagem chega no
`stream.write()` do handler, o Python tenta decodificá-la como ASCII e quebra no primeiro byte
não-ASCII (`0xc3`, o primeiro byte de "ç" em "informações"). Conferido: o deslocamento de byte 53
apontado no erro bate exatamente com a posição do primeiro `0xc3` na linha de log já formatada
(`"<data> - INFO - Validando as informações do arquivo bkoffice.csv"`), confirmando o diagnóstico.

Isso não derruba o processo (o próprio `logging` captura o erro internamente em `handleError()` e
só imprime esse traceback no stderr como diagnóstico — é o mesmo texto que aparece sempre que um
handler falha ao emitir um registro), mas é sinal de que a linha nunca é gravada no
`system_script.log`, e o comportamento poderia variar dependendo do stream/console.

Mesmo padrão (`logging.FileHandler(..., encoding="utf-8")`) existia também em
`fix_protocolo_cupons.py` (`_configurar_log()`, usado pelo CLI), com o mesmo risco assim que
qualquer mensagade logada tivesse acento (ex: mensagens de erro/aviso em português).

**Corrigido** removendo o parâmetro `encoding=` dos dois `FileHandler` (`main.py` e
`fix_protocolo_cupons.py`). Sem esse parâmetro, o `FileHandler` abre o arquivo como um arquivo
binário comum — `stream.write()` aceita `str` (bytes) diretamente, sem tentar decodificar nada. O
`.log` final continua sendo texto UTF-8 válido (porque as mensagens já chegam como bytes UTF-8),
só que sem a camada `codecs` no meio que provocava a decodificação implícita em ASCII.
`send_orderpaid_boh.py` (`StandAlone.__init__`, ainda não chamado em nenhum ponto ativo) usa
`logging.basicConfig(..., filename=...)` sem `encoding=` — não tem esse problema, então não
precisou de alteração.

Commitado no repositório git (a pasta conectada a esta sessão) — mesma ressalva do incidente
(4): ainda não chega em `C:\edeployPOS\find_xml` sozinho, precisa ser levado manualmente pra lá
(ou pra qualquer outra instalação onde o usuário for testar, como a pasta local onde rodou esse
teste com `C:\Python27\python.exe`).

## O que ainda é dívida técnica / pendente de decisão

- **Python 2.7 está fora de suporte desde janeiro/2020 (sem patch de segurança)** — voltar a
  rodar o `main.py` inteiro nele (decisão de 31/08/2026) reintroduz esse risco, especialmente
  para `send_orderpaid_boh.py` (`StandAlone`), que faz chamadas HTTPS ao servidor BOH. Mitigado
  parcialmente porque `StandAlone` não é chamada em nenhum ponto ativo hoje (ver item abaixo) —
  mas se for reativada, vale reavaliar.
- `cstat_539.bat` (criado pelo usuário) chama `fix_protocolo_cupons.py --order-ids` sem números de
  nota depois da flag — precisa ser completado com os orderids antes de rodar.
- `StandAlone` (`send_orderpaid_boh.py`) e `StandAlone_OrderPicture` (`order_picture.py`) não são
  chamadas em nenhum lugar ativo — decisão de negócio pendente sobre reativar o envio ao BOH em
  `time_direction` quando `order_statr == 5`.
- O ramo de inutilização incorreta dentro de `time_direction` (`order_disabled`/
  `xml_fiscal_disabled`) parece inatingível no código atual (as variáveis nunca recebem um valor
  que dispare esse bloco) — revisar se é intencional ou uma lacuna.
- `cElementTree` (alias legado) ainda é usado em vez de `xml.etree.ElementTree` em
  `fix_protocolo_cupons.py`, `order_picture.py`, `send_orderpaid_boh.py` e
  `fiscal_reprocessa_nfeproc.py` — funciona, mas os scripts mais novos já usam o nome direto.
- `fiscal_reprocessa_nfeproc.py` tem nomes de tabela/coluna não confirmados em produção (ver
  aviso no próprio arquivo) — confirmar com `--list-tables`/`--describe-table` antes do primeiro
  uso em cada instalação.
- `key_pattern_fiscallog` (cStat 204, em `fix_protocolo_cupons.py`) ainda busca um padrão de log
  antigo (`FiscalWrapper.log`, não `FiscalWrapperThread.log`) que provavelmente está desatualizado
  pelo mesmo motivo que o padrão de `find_key_pattern` estava — falta um exemplo real desse
  cenário para reescrever com segurança.
- `fix_cupom_protocol.py` ainda existe fisicamente na pasta como um stub de texto (não consigo
  apagar arquivos remotamente) — o usuário pode apagá-lo quando quiser, nada mais importa dele.
