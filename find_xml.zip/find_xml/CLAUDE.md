# find_xml — tratamento automático de venda (integração e-deploy / NFCe)

Este documento descreve o que cada script desta pasta faz, como se encaixam entre si, e o
contexto operacional (POS e-deploy, banco fiscal, SEFAZ) necessário para dar manutenção neles.
É complementar ao histórico de migração Python 2→3 (projeto "Tratamento de venda" no Claude,
doc `migracao-python3-find-xml.md`), que registra decisões e correções já aplicadas — este
arquivo foca em **o que o sistema faz hoje**, não no histórico de mudanças.

## Visão geral

**Atualizado em 31/08/2026: o `main.py` (e todos os módulos que ele importa) voltou a rodar com
o Python 2.7 da instalação (pasta `python\`, ao lado de `python3\`), não mais com `python3\`.**
Ver incidente de campo de 31/08/2026 no fim deste documento para o motivo. **Desde 04/09/2026**,
"todos os módulos que ele importa" passou a incluir também `restore_order_from_backup.py` (ver
seção "Restauração de pedido ausente via backup" abaixo) — que antes só rodava standalone via
Python 3 e por isso nunca precisou dessa restrição.

O `main.py` é o script principal, disparado por `update.bat` (rodando com
`C:\edeploypos\python\python.exe` — o caminho real do interpretador varia por loja, ver seção
"Ambientes/instalações" abaixo) em cada terminal de loja. Ele lê um arquivo CSV
(`file_csv/bkoffice.csv`) contendo números de nota vindos do backoffice, localiza a venda
correspondente no banco local de pedidos do POS, verifica o estado fiscal dessa nota (autorizada,
em contingência, cancelada, etc.) e corrige inconsistências entre o banco de pedidos e o banco
fiscal (`fiscal_persistcomp.db`). Ao final, também roda uma rotina de atualização de componentes
do sistema (`fix_apply.py`).

Além do fluxo principal, a pasta reúne um conjunto de scripts standalone de suporte/correção —
recuperar pedidos apagados, preencher parâmetros fiscais faltantes, reconstruir o XML da NFC-e,
etc. — usados manualmente quando algo dá errado numa loja específica.

## Fluxo principal (`main.py`)

1. **Detecta a instalação** via `get_system_version()` (`consulte_csv.py`): procura, nessa
   ordem, `C:\mwpos`, `C:\edeployPOS`, `C:\edeploy-pos-structure` (Windows) ou
   `/home/administrador/edeployPOS` (Linux), caindo em `/home/administrador/mwpos_server` como
   default. Isso define os caminhos de banco de dados, backups e binários usados no resto do
   script.
2. **Lê `file_csv/bkoffice.csv`** (`ler_arquivo_csv` / `file_valor_sentto`, em `consulte_csv.py`):
   cada linha do CSV traz um número de nota (`numeronota`) separado por `;`.
3. **Localiza a venda no banco local** (`find_fiscal_id`, `sqlite_update.py`): varre os arquivos
   `order.db<N>` (um por POS/caixa) procurando, em `OrderCustomProperties`, a linha onde
   `Key = 'FISCAL_ID'` bate com o número de nota do CSV. Retorna `orderid`, `nota` e o caminho do
   banco onde a venda foi encontrada. **Desde 04/09/2026**, se não encontrar em nenhum
   `order.db<N>`, tenta restaurar/importar a nota do backup antes de desistir (ver seção
   "Restauração de pedido ausente via backup" abaixo).
4. **Para cada venda encontrada, decide o que fazer** (`time_direction`, em `consulte_csv.py`) —
   ver seção dedicada abaixo, é o coração da lógica de negócio.
5. **Roda a atualização de componentes** (`main_fix()`, `fix_apply.py`) — sempre, independente do
   resultado do passo 4.
6. Loga início/fim em `system_script.log` (formato `timestamp - LEVEL - mensagem`, UTF-8).

### `time_direction` — a lógica de decisão fiscal

Recebe o histórico de estados de uma venda (`orderstatehistory`) e decide a ação com base na
combinação de estados:

- **Void + Paid presentes, void ocorreu ≥30min depois do paid**: marca a venda como "cancelada"
  no fluxo interno (`updater_aped_20805`, com status "cancelada") e não segue adiante — é uma
  venda cancelada normalmente, fora da janela de contingência.
- **Void + Paid presentes, void <30min depois do paid**: trata como cancelamento normal dentro da
  janela aceitável (`updater_aped_20805`, sem status).
- **Paid sem Void** (venda paga e não cancelada) — o caso mais importante:
  - Aguarda 7s (dar tempo do XML fiscal ser gravado) e lê a custom property `FISCAL_XML` da
    venda (XML da nota em base64).
  - Decodifica o `cStat` (código de status da SEFAZ) desse XML via `DecodeBase64`
    (`decode_base64.py`).
  - **Se `cStat` é 100 ou 150** (autorizada): compara com o `cStat` que está gravado no banco
    fiscal (`fiscal_persistcomp.db`, via `validate_status`). Se divergem, atualiza o banco fiscal
    com o XML mais recente (`update_xml_APED23848`) e retorna 5 (nota corrigida). Se já batem,
    apenas confirma e retorna 5.
  - **Se `cStat` indica contingência** ("Problemas de conexao com a SEFAZ" ou "Notas anteriores
    em contingencia"): antes de mais nada, tenta corrigir o protocolo automaticamente via
    `FixingCstatCupons.find_key_pattern` (ver seção "Correção de protocolo" abaixo). Depois,
    monta um registro `FiscalData` com os dados da venda e:
    - Se já existe registro fiscal para esse `orderid` (`sales_inquiry`), atualiza o XML
      (`update_xml_APED23848`).
    - Senão, insere um novo registro (`insert_fiscal_faltante`) — essa é a rotina que
      "recupera" notas que ficaram sem registro no banco fiscal.
  - Também existe um bloco (`order_disabled`/`xml_fiscal_disabled`) para tratar inutilização
    incorreta (`cStat` 206/256/102 quando deveria estar ativa) e corrigir a sequência fiscal
    (`seq_fiscal`/`seq_update`/`update_fiscal_order`) — mas hoje essas variáveis nunca são
    setadas como `True`/valor no código atual, então esse ramo é efetivamente inatingível como
    está escrito (possível dívida técnica/código morto a revisar).
- **Void sem Paid** (cancelada antes de ser paga): olha a custom property
  `DISABLED_FISCAL_XML`/`ORDER_DISABLED` e loga o motivo (cStat 563, 102, ou sequência quebrada
  via `ORDER_DISABLED`) — não faz alteração no banco além do log, é diagnóstico.
- **Nem Void nem Paid**: consulta o estado atual da venda (`consulte_orderid`) e só loga.
- **Estado 6 (recalled)**: interrompe o processamento dessa venda sem mais ação.

### Correção automática de protocolo (`FixingCstatCupons`, `fix_protocolo_cupons.py`)

**Atualizado em 31/08/2026: `FixingCstatCupons` mora agora só em `fix_protocolo_cupons.py`.**
Não existe mais `fix_cupom_protocol.py` (removido a pedido do usuário — a classe estava separada
do CLI em dois arquivos, e passou a viver num arquivo só, sem import cruzado entre eles).
`consulte_csv.py` e `main.py` foram atualizados para importar de `fix_protocolo_cupons.py`.

Quando uma venda está em contingência, o `main.py` tenta corrigir sozinho o protocolo da nota
antes de cair no fluxo manual de `FiscalData`. Como isso funciona:

- `FixingCstatCupons` abre uma conexão com o barramento e-deploy (`MBEasyContext`) e importa o
  SDK proprietário (`msgbus`, `cfgtools` de `common.pypkg`; `old_helper`, `bustoken` de
  `edpcommon.pypkg`) dentro da instalação. Essa conexão é cara de abrir, então o `main.py` a
  reaproveita durante toda a execução via `_obter_fixing_cstat_cupons()` (uma única instância em
  cache). Se a loja não for NFCE (não existe `loader_NFCE.cfg`) ou a conexão falhar por qualquer
  motivo, a correção fica marcada como indisponível pelo resto da execução e o fluxo normal
  continua sem ela.
  **Desde 31/08/2026 isso funciona de verdade dentro do `main.py`.** `old_helper.pyc`/
  `bustoken.pyc` (em `edpcommon.pypkg`) só existem compilados para **Python 2.7** (magic number
  62211) em qualquer instalação testada — não existe `edpcommon3.pypkg`. Como o `main.py` agora
  roda com o Python 2.7 da instalação (não mais Python 3), esses dois módulos resolvem
  normalmente e a correção automática por venda passa a funcionar de fato (antes, rodando em
  Python 3, o `except Exception` sempre capturava `ImportError` aqui — ver incidente de campo de
  28/08/2026 (2) para o histórico completo dessa investigação).
- `find_key_pattern(orderid)` varre o `FiscalWrapperThread.log` procurando a linha que o
  `nfce.py` (parte do SDK e-deploy) grava quando detecta e tenta corrigir sozinho um `cStat` 539
  (duplicidade de chave de acesso), 100, 150 ou 204 — do tipo:
  `"... nfce.py:...:_handle_duplicated_diff_key - Tratando 539 da order 000123413 ...
  Chave de Acesso <44 dígitos>"`. Extrai o `cStat` e a chave de acesso que a SEFAZ já reconhece
  para essa nota, e chama `fix_cstat` para essa nota específica. **Desde 31/08/2026 (2)**, também
  tenta um segundo formato como fallback quando o primeiro não bate na linha/arquivo: a SEFAZ às
  vezes manda a chave entre colchetes, prefixada por `chNFe:` (`"... Chave de Acesso
  [chNFe:<44 dígitos>]"`, em vez de `"... Chave de Acesso <44 dígitos>"` puro) —
  `RE_PATTERN_LOTE_CHNFE`, em `fix_protocolo_cupons.py`, cobre esse caso. O mesmo fallback existe
  em `encontrar_pendentes`/`corrigir_lote` (modo lote) e é usado tanto pela correção automática
  por venda quanto pelo CLI. **Desde 04/09/2026**, existe ainda um TERCEIRO formato, tentado só
  se os dois primeiros não baterem: a chave entre colchetes SEM o label `chNFe:` (com um `.` antes
  do colchete), seguida de um segundo colchete com o protocolo/recibo da SEFAZ (`"... Chave de
  Acesso. [<44 dígitos>][nRec:<número>]"`) — `RE_PATTERN_LOTE_COLCHETE` cobre esse caso. O `nRec`
  (protocolo) é capturado e logado (`"Protocolo (nRec) encontrado no log - orderid: ... nRec:
  ..."`) só para diagnóstico — `fix_cstat` continua corrigindo com base apenas na chave de acesso,
  não usa o `nRec` na correção.
- `fix_cstat(orderid, key, cstat)` pega o `FISCAL_XML` atual da venda (via `get_order_picture`,
  mensagem ao barramento), troca a chave de acesso incorreta pela chave correta encontrada no
  log, remonta o XML com um protocolo de aceite (`cStat 204`, motivo "Duplicidade de NF-e") e
  grava de volta em `fiscal_persistcomp.db` (`update_fiscal_persist`). Retorna `True`/`False` (não
  levanta exceção) — assim tanto `find_key_pattern` (uma nota, chamado automaticamente pelo
  `main.py`) quanto `corrigir_lote` (várias notas, ver abaixo) conseguem seguir adiante sem se
  preocupar em capturar exceção nota a nota.
- **`encontrar_pendentes(order_ids=None, cstats_alvo=...)` e `corrigir_lote(order_ids=None,
  dry_run=False)`** (adicionados em 31/08/2026): a mesma lógica de `find_key_pattern`/`fix_cstat`,
  generalizada para várias notas de uma vez. `encontrar_pendentes` lê o(s)
  `FiscalWrapperThread.log*` **linha a linha** (nunca carrega o arquivo inteiro na memória) e do
  **mais novo pro mais antigo**; se `order_ids` for passado, para de abrir arquivos mais antigos
  assim que todos os pedidos já foram encontrados (early exit) — evita varrer o histórico inteiro
  quando já se sabe quais notas corrigir. `corrigir_lote` chama `fix_cstat` para cada nota
  encontrada e retorna `(total_encontrado, total_corrigido, total_falhou, nao_encontrados)`. Essas
  duas rotinas são o que o CLI no fim de `fix_protocolo_cupons.py` usa quando o arquivo é rodado
  direto (ver seção "Scripts standalone" abaixo) — é tudo o mesmo arquivo agora, sem duplicação.
- `process_resign` / `process_unused_orders` são rotinas mais amplas (não chamadas pelo
  `main.py` no fluxo atual, existem para execução manual/futura): a primeira varre um período de
  60 dias procurando notas pendentes de envio à SEFAZ e força reenvio; a segunda identifica
  pedidos indevidamente "não usados"/inutilizados e limpa a flag `ORDER_DISABLED`.

### Restauração de pedido ausente via backup (`restaurar_nota`, `restore_order_from_backup.py`)

**Adicionado em 04/09/2026.** Antes dessa mudança, quando `find_fiscal_id` não achava a nota em
nenhum `order.db<N>` corrente, `main.py` só logava `"Nota não identificada no banco {}"` e seguia
adiante sem essa venda. Agora, antes de desistir de vez, `main.py` chama `restaurar_nota` (função
nova em `restore_order_from_backup.py`, que já existia como script standalone - ver seção
"Scripts standalone" abaixo) para tentar localizar e importar essa nota a partir do backup:

1. Procura nas bases correntes de novo (redundante com o `find_fiscal_id` que já falhou, mas é o
   próprio `process_note` de `restore_order_from_backup.py` que faz essa checagem por conta
   própria - inofensivo, só um pouco de trabalho repetido).
2. Se não achar, procura no backup mensal de pedidos (`orders_*.db`, do mês mais recente pro mais
   antigo) e, se achar, copia o pedido inteiro (`Orders` + tabelas filhas) pro `order.db<N>` de
   destino certo (resolvido a partir do `OriginatorId` do pedido no backup).
3. Se não achar nem no backup de pedidos, tenta reconstruir o pedido a partir do `OrderPicture`
   (XML em base64) salvo em `FiscalData` (`fiscal_persistcomp.db` ou `fiscal_*.db` de backup) -
   melhor esforço, não recupera `OrderVoidHistory` nem taxas de delivery fee.
4. Em qualquer um dos casos acima que resolver a nota, também garante que o registro fiscal
   (`FiscalData`) esteja presente no banco corrente - se não estiver, procura em `fiscal_*.db` de
   backup e importa de lá. Dados fiscais são legalmente imutáveis, então nunca são fabricados do
   zero - se não existir em nenhum backup, só avisa.

Se `restaurar_nota` conseguir resolver a nota (retorna a lista de `OrderId`s resolvidos, não
vazia), `main.py` chama `find_fiscal_id` de novo pra essa nota - agora que o pedido foi
copiado/reconstruído em `order.db<N>`, ela deve aparecer, e a venda segue pro resto do fluxo
(`xml_bin`, `time_direction`) normalmente, como se tivesse sido encontrada de primeira. Faz uma
chamada de `find_fiscal_id` por nota restaurada, não a varredura inteira de novo - mais barato do
que reprocessar `retorno_archilo` do zero.

`restaurar_nota` sempre roda com `yes=True` (não pede confirmação `[s/N]` como o CLI manual faz
por padrão) e cria uma cópia de segurança (`.bkp`, timestamped) do `order.db<N>` de destino antes
de gravar - mesma lógica do CLI standalone, só embrulhada pra não precisar montar um
`argparse.Namespace` na mão. `path_orders_backup` (diretório de backup) só é definido hoje para
as instalações `C:\edeployPOS` e `C:\edeploy-pos-structure` (ver "Ambientes/instalações" abaixo) -
se a instalação detectada for outra e essa variável não existir, `main.py` pula a tentativa de
restaurar (loga e segue) em vez de quebrar com `NameError`. Qualquer exceção inesperada dentro de
`restaurar_nota` também é capturada e logada, sem derrubar o processamento das outras notas.

**Atenção Python 2.7**: `restore_order_from_backup.py` sempre foi um dos três scripts
"nativamente Python 3" desta pasta (ver `## Visão geral`) - mas isso só era verdade porque ele
só era chamado standalone via `python3 restore_order_from_backup.py ...`, nunca importado por algo
rodando em 2.7. Agora que `main.py` faz `from restore_order_from_backup import restaurar_nota`, o
arquivo passa a ser **parseado pelo Python 2.7 também**. Ele já era escrito de forma compatível
com as duas versões (só `.format()`, sem f-string nem type hints) - a única mudança necessária foi
adicionar `# -*- coding: utf-8 -*-` (PEP 263) por precaução, mesmo sem nenhum acento hoje (ver
incidente de campo de 31/08/2026 (4) para o motivo). Isso significa que **qualquer alteração
futura em `restore_order_from_backup.py` precisa continuar evitando sintaxe exclusiva de Python
3** (f-string, type hints com `->`/`: tipo`, argumentos somente-por-nome após `*`, etc.) - deixou
de ser "só" um script Python 3 isolado.

### Inutilização automática de notas "órfãs" (`inutilizar_numeros_orfaos.py`)

**Adicionado em 09/09/2026.** Antes dessa mudança, quando uma nota do CSV esgotava a busca no
banco corrente (`find_fiscal_id`) E a tentativa de restauração do backup (`restaurar_nota`, ver
seção acima), `main.py` só logava `"Nota {} não encontrada em nenhum backup - segue não
identificada"` e seguia adiante sem essa nota - um número de NFC-e ficava "aberto" (reservado
junto à SEFAZ, sem venda nenhuma por trás), sem nenhuma ação de correção. Isso é o mesmo cenário
que `inutilizar_numeros_orfaos.py` já existia para tratar manualmente (criado antes desta
integração, para o incidente do bug de dupla alocação em `_set_fiscal_id_on_custom_property`,
`eventhandler.py`, na loja `osaka.boh.e-deploy.com.br-0001` - números "queimados" sem order
associada).

Agora, nesse ponto, `main.py` chama `_tentar_inutilizar_nota_orfa(numero_nota)` (função nova em
`consulte_csv.py`), que:

1. **Pede confirmação manual ao operador** via `raw_input()` (`"Deseja inutilizar esse número
   junto à SEFAZ? [s/N]"`). Diferente de `restaurar_nota` (que só mexe no banco local e roda sem
   perguntar, `yes=True`), inutilização é uma ação **irreversível** junto à SEFAZ - decisão
   explícita do usuário (09/09/2026) de sempre exigir revisão humana antes de mandar isso pra
   valer, mesmo que isso faça `main.py` bloquear esperando resposta quando aparecer uma nota
   órfã (deveria ser raro). Rodando sem terminal interativo (ex: agendado/silencioso, sem console
   anexado), `raw_input()` levanta `EOFError` - capturado pelo mesmo `except Exception` que
   envolve o `raw_input`, então a inutilização automática vira efetivamente um no-op nesse caso
   (a nota só fica "não identificada" no log, igual ao comportamento de antes desta mudança) -
   só funciona de fato com alguém na frente do terminal.
2. Se confirmado, chama `inutilizar_nota_orfa(numero_nota, app_path=...)` (função nova em
   `inutilizar_numeros_orfaos.py`) - a mesma lógica do CLI em lote deste arquivo (`NfceDisabler`
   e afins, `build_synthetic_order_xml`), mas para **um único número por vez**. Retorna
   `(sucesso, mensagem)`, mesmo formato de `corrigir_protocolo()` (`corrigir_protocolo.py`), só
   pra manter os dois usos simétricos em `consulte_csv.py`.

Decisões tomadas com o usuário nessa integração:

- **Série da NFC-e**: o CSV do backoffice só traz o número da nota, não a série - mas a
  inutilização exige as duas. O usuário confirmou que a série **sempre deve ser lida
  dinamicamente do `loader_NFCE.cfg` da própria loja** (chave
  `<key name="serie"><string>N</string></key>`, ex: série `2` numa das lojas testadas), nunca
  fixa/hardcoded - `load_loader_config` (em `inutilizar_numeros_orfaos.py`) foi atualizada para
  ler essa chave junto com `cUF`/`cnpj`/`versao_ws`/`ambiente`/etc., e `inutilizar_nota_orfa` usa
  `cfg["serie"]` como padrão (só aceita um valor explícito por parâmetro pra sobrescrever, caso
  precise reprocessar uma nota de uma série antiga).
- **`--bundle-dir`** (onde ficam `loader_NFCE.cfg`/`nfce_urls.xml`/certificados): derivado
  automaticamente como `<app_path>\data\server\bundles\fiscalwrapper` - mesmo caminho que
  `FixingCstatCupons` (`fix_protocolo_cupons.py`) já usa pra achar `loader_NFCE.cfg`
  (`self.nfce_loader`). Não precisou perguntar ao usuário.
- **`--fiscalwrapper-src`** (pasta com o código-fonte do próprio componente fiscalwrapper -
  `nfcedisabler.py`, `models.py`, `nfcebuilder/`, `comp_exceptions.py` - importados via
  `sys.path.insert` pra reaproveitar as mesmas classes que o fiscalwrapper usa pra inutilizar):
  **AINDA NÃO CONFIRMADO numa instalação real**. Os bundles em `repository/` (pasta conectada a
  esta sessão) só têm os arquivos que foram atualizados em cada patch do `fix_apply.py`
  (`nfce.py`, `eventhandler.py`, `fiscalpersistence.py`, `adapter/sqlite_adapter.py` - ver
  listagem em `repository/26.05.12/update/fiscalwrapper/`), não o componente inteiro -
  `nfcedisabler`/`models`/`comp_exceptions` não aparecem em nenhum desses bundles. O usuário
  pediu para assumir a mesma convenção de destino que `fix_apply.py` já usa pra copiar bundles
  atualizados (`repository/<versão>/update/<componente>` → `<app_path>\src\<componente>\`, ver
  seção "Atualização de componentes" abaixo) - `default_fiscalwrapper_src()`, em
  `inutilizar_numeros_orfaos.py`, retorna `<app_path>\src\fiscalwrapper\src`. **Testar numa loja
  de homologação antes de confiar em produção** - se o caminho real for outro, o `ImportError`
  resultante vai aparecer só na hora de tentar inutilizar de verdade (dentro do
  `except Exception` de `inutilizar_nota_orfa`, que devolve `(False, mensagem)` sem derrubar o
  resto do `main.py`).

A lógica de montar o `NfceDisabler` (ler config/certificados, instanciar signer/enveloper/builders)
foi fatorada em `_montar_disabler`/`_criar_nfce_disabler`, compartilhada pelo CLI em lote
(`main()`, uso manual a partir de um `missing_numbers.json`) e por `inutilizar_nota_orfa` (uso
automático, uma nota por vez) - sem duplicar essa lógica em dois lugares, mesmo princípio já
seguido no resto desta pasta.

**Idempotência (09/09/2026) — não repetir a mesma nota órfã a cada execução**: o usuário
perguntou se a inutilização grava alguma informação nos bancos, pra não tentar a mesma nota de
novo numa próxima execução do `main.py`. Resposta: **não grava nada em `fiscal_persistcomp.db`
nem em `order.db<N>`** — não existe nenhuma linha nessas tabelas pra associar a um número "órfão"
(sem order nenhuma por trás). O `ProcInutNfeSaver` (já parte do fiscalwrapper, não mudou aqui)
salva o XML do protocolo de inutilização em disco, na pasta `InutilizacaoManual` do `bundle_dir` —
mas isso não é consultado de volta pra saber "já processei esse número".

Em vez disso, `inutilizar_nota_orfa`/`nota_ja_processada` reaproveitam o **mesmo mecanismo de
arquivo de estado JSON** que o CLI em lote já usava (`--state-file`/`load_state`/`save_state`),
só que com um caminho fixo (`default_state_file()`, ao lado deste próprio arquivo -
`inutilizacao_notas_orfas.state.json`, caminho **absoluto** baseado em `__file__`, não relativo ao
cwd - importante porque o cwd muda durante a execução do `main.py`, ver incidente de campo de
31/08/2026 (6)) e chave mais simples (só `str(numero_nota)`, sem série - o CSV do backoffice só
tem o número mesmo). `consulte_csv.py` (`_tentar_inutilizar_nota_orfa`) chama
`nota_ja_processada(numero_nota)` **antes** de sequer perguntar pro operador — se já tem desfecho
gravado, nem pergunta nem tenta de novo.

Só desfechos **terminais** são gravados (senão uma nota genuinamente impossível de inutilizar
ficaria sendo tentada pra sempre, mas uma falha temporária nunca seria re-tentada):
- `"disabled (serie N)"` — inutilizada com sucesso.
- `"skipped_by_sefaz (serie N): ..."` — a própria SEFAZ respondeu que o número já estava
  tratado/usado (`FiscalSkippableWarning`).
- `"permanent_error (serie N): ..."` — erro permanente (`FiscalInutilizationPermanentError`), ex:
  número fora da faixa autorizada.

**NÃO são gravados** (pra serem tentados de novo na próxima execução do `main.py`):
`FiscalInutilizationRetryableError` (SEFAZ fora do ar), qualquer exceção inesperada de config/
certificado/SDK (`except Exception` mais externo), e `confirm=False` (dry-run, só um preview).

**Testado em produção (09/09/2026 a 10/09/2026) — ver incidentes de campo "No module named
pos_model" e "cannot import name TenderType" abaixo.** As duas primeiras tentativas reais de
`inutilizar_nota_orfa()` numa loja quebraram por `ImportError` dentro de `_montar_disabler`, antes
de sequer chegar a falar com a SEFAZ — corrigido nas duas rodadas descritas nesses incidentes.
Ainda não há confirmação de uma inutilização bem-sucedida de ponta a ponta (chegando a mandar o
pedido pra SEFAZ e receber resposta) — só que os imports agora resolvem. Continua recomendado
acompanhar de perto o próximo teste em produção, e ainda existe o risco (não confirmado) de
`iso8601` (usado por `_ProcInutNfeSaver.save_proc_inut_nfe_xml`, chamado de verdade por este
fluxo) não estar instalado em alguma loja — não foi encontrado em `src/fiscalwrapper/lib/` na
instalação testada.

### Atualização de componentes (`fix_apply.py`)

Depois do processamento das vendas, `main_fix()` sempre roda: lê a versão instalada
(`get_version()`, em `util.py`, consulta `pos_updater.db`) e, se bater com uma das versões
mapeadas (`CORE:4.2.0|SRC:25.08.11`, `CORE:5.2.3|SRC:26.02.11`, `CORE:5.2.6|SRC:26.05.06`,
`CORE:5.3.0|SRC:26.05.12`), copia os bundles correspondentes da pasta `repository/<versão>/update/`
para `C:\edeploypos\genesis\src\` e `C:\edeploypos\src\` (removendo `.pyc` antigos antes, via
`distutils.dir_util.copy_tree` — voltou a ser `copy_tree` em vez de
`shutil.copytree(..., dirs_exist_ok=True)` porque `dirs_exist_ok` só existe a partir do Python
3.8 e o script agora roda em Python 2.7) e reinicia o componente afetado (`restart_component`,
via `hv -o <componente>`, usando os nomes `remoteorder`, `fiscalwrapper`, `npersistcomp`). Se a
versão instalada já tiver a correção (nenhuma das quatro acima), levanta `ValueError` e não faz
nada — é esse erro que aparece como "Unable to get system version" no log quando a máquina não é
um terminal POS real (não tem `pos_updater.db`).

## Módulos de apoio

- **`consulte_csv.py`**: núcleo da lógica de negócio (`time_direction`, detecção de instalação,
  leitura do CSV) — descrito acima.
- **`sqlite_update.py`**: toda a camada de acesso a SQLite usada pelo fluxo principal — consultas
  e updates em `order.db<N>` (pedidos), `fiscal_persistcomp.db` (dados fiscais) e
  `tblservice.db`. Inclui as funções de correção pontual `updater_aped_20805` (cancelamento),
  `updater_OXAP_5832`, `updater_aped_20805_unpaid` (várias delas nomeadas por número de chamado/
  bug interno — APED-xxxxx, OXAP-xxxx).
- **`decode_base64.py`**: `DecodeBase64` decodifica um XML de nota (base64) e extrai o `cStat` —
  seja de `protNFe/infProt/cStat` (nota normal), `cStat` direto (nota inutilizada) ou
  `infNFe/ide/xJust` (motivo de contingência/justificativa, quando não há cStat numérico ainda).
- **`util.py`**: `get_version()` lê a última atualização aplicada em `pos_updater.db`;
  `restart_component()` reinicia um componente via `hv -o`.
- **`time_hora.py`**: `datetime_to_float` converte timestamp de string para epoch (usado ao
  montar o registro `FiscalData`).
- **`xml_file.py`**: utilitário genérico de listagem recursiva de arquivos (`get_xmls_list`) —
  não está no caminho crítico do fluxo atual.
- **`order_picture.py`** (`StandAlone_OrderPicture`) e **`send_orderpaid_boh.py`**
  (`StandAlone`): classes para, dado um `orderid`, buscar o "order picture" completo da venda no
  barramento e-deploy e (no caso de `send_orderpaid_boh.py`) montar o payload e enviar ao BOH
  (back office) via HTTP (`POST /pump/sale/order-picture`). **Não são chamadas em nenhum ponto
  ativo do `main.py` hoje** — só há uma referência comentada em `time_direction`
  (`#StandAlone(xml_file.get("orderid"))` quando `order_statr == 5`). Ficam prontas para reativar
  quando for decisão de negócio enviar pedidos pagos ao BOH nesse ponto do fluxo.

## Scripts standalone (uso manual, sob demanda)

Não fazem parte do fluxo automático do `main.py` — são rodados manualmente quando uma loja
reporta um problema específico:

- **`fix_protocolo_cupons.py`** — **atualizado em 31/08/2026: é o único arquivo, contém tanto a
  classe `FixingCstatCupons` quanto o CLI por cima dela** (antes eram dois arquivos, um deles
  `fix_cupom_protocol.py`, removido). Quando importado (por `consulte_csv.py`, para a correção
  automática por venda) só a classe é usada; quando rodado direto (`python fix_protocolo_cupons.py
  ...`), o CLI no fim do arquivo decide **quais** notas corrigir e chama os métodos da classe.
  Roda com o Python 2.7 da instalação (`python\python.exe`) — igual ao `main.py`, já que os dois
  usam o mesmo arquivo/classe agora. Flags de seleção do CLI (uma obrigatória, mutuamente
  exclusivas):
  - `--order-ids ID1 [ID2 ...]` — corrige só essas notas específicas.
  - `--order-ids-file ARQUIVO` — corrige as notas listadas num arquivo (um orderid por linha,
    `#` comenta a linha).
  - `--all-pendentes` — corrige TODAS as notas com cStat corrigível encontradas no log.
  - `--listar` — só lista as notas pendentes (todas, ou as de `--order-ids`/`--order-ids-file`),
    sem corrigir nada.

  Mais `--dry-run` (mostra sem gravar), `-y`/`--yes` (não pede confirmação) e `--app-path` (força
  o caminho da instalação — sem isso, o CLI importa `get_system_version` de `consulte_csv.py` só
  na hora de rodar, para não criar import circular com o uso automático pelo `main.py`). Loga em
  `fix_protocolo_cupons.log` (mesmo `getLogger("FixingCstatCupons")` que a classe usa) + console.
  Uso:
  `C:\edeploy-pos-structure\python\python.exe fix_protocolo_cupons.py --order-ids 123413 123999 [--dry-run] [--yes]`.
  O CLI não está integrado ao fluxo automático do `main.py` por venda (decisão deliberada,
  28/08/2026) — roda manualmente ou agendado, pra lidar com acúmulo de notas presas. Existe um
  `cstat_539.bat` na pasta (criado pelo usuário) que chama esse script com `--order-ids` — **hoje
  está sem os números de nota depois da flag**, então precisa ser completado antes de rodar
  (`argparse` vai recusar com "expected at least one argument" do jeito que está).
- **`backfill_fiscal_params_from_order.py`**: quando um produto não tem parâmetro fiscal
  cadastrado em `fiscal_params.db` (NCM, CFOP, CST_ICMS, CST_PIS, CST_COFINS, CSOSN, CEST) e isso
  impede reconstruir o XML de uma nota, este script lê o `FISCAL_XML` já aceito pela SEFAZ de uma
  nota existente e usa esses valores oficiais para preencher os parâmetros faltantes — nunca
  sobrescreve o que já existe. Faz backup do banco antes de gravar. Uso:
  `python backfill_fiscal_params_from_order.py <numero_nota> [--dry-run] [--yes]`.
- **`restore_order_from_backup.py`**: dado um ou mais números de nota (`FISCAL_ID`), procura o
  pedido primeiro nas bases correntes (`order.db<N>`), depois nos backups mensais
  (`orders_*.db`), e em último caso reconstrói o pedido a partir do `OrderPicture` salvo no
  próprio registro fiscal (`FiscalData`) — essa reconstrução é best-effort e não recupera
  histórico de cancelamento nem taxas de delivery. Também garante/restaura o registro fiscal
  correspondente. Sempre faz backup antes de gravar. Uso:
  `python restore_order_from_backup.py <notas...> [--pos N] [--backup-file NOME] [--dry-run] [--yes]`.
  **Desde 04/09/2026, não é mais só standalone** — `main.py` também chama esse arquivo
  diretamente (`from restore_order_from_backup import restaurar_nota`) quando uma nota não
  aparece em nenhum `order.db<N>` corrente durante o processamento automático, para tentar
  restaurar/importar do backup sem intervenção manual. Ver seção "Restauração de pedido ausente
  via backup" acima para os detalhes dessa integração (inclusive a mudança de premissa sobre
  compatibilidade com Python 2.7).
- **`backfill_missing_order.py`**: usa o SDK novo do e-deploy (`common3.pypkg`,
  `mbcontextmessagehandler`, `order_api`) para buscar pedidos direto do serviço de pedidos
  (`OrderService`) por `orderid` e inserir/backfillar entradas no audit log
  (`auditlogger_services`) quando ainda não constam lá — usado para recuperar eventos de
  voided/stored que não chegaram a ser auditados. Uso:
  `run_backfill_missing_order.bat <ORDER_ID> [ORDER_ID2 ...] [--force]` (o `.bat` já resolve o
  caminho do `python3` e a pasta de saída do audit log).
- **`fiscal_reprocessa_nfeproc.py`**: reconstrói o XML `nfeProc` completo (envelope com
  `<NFe>` + `<protNFe>`) de uma nota já autorizada, juntando o XML de venda salvo em
  `fiscal_persistcomp.db` com a chave de acesso e `cStat` encontrados no log do fiscalwrapper
  (padrão `"Order <n>: chave autorizada <44 dígitos> retornou cStat 100"`). Salva um backup local
  em `output_nfeproc/` antes de gravar de volta no banco. Os nomes de tabela/coluna
  (`fiscaldata`/`orderid`/`xmlrequest`) são um "melhor palpite" documentado no próprio arquivo —
  usar `--list-tables`/`--describe-table` para confirmar antes de rodar em uma instalação nova.

## Ambientes / instalações reconhecidas

O código reconhece três variações de instalação e-deploy, cada uma com seu próprio caminho base
(detectado por `get_system_version()` em `consulte_csv.py`, ou fixo como default nos scripts
standalone via `DEFAULT_DB_DIR`/`DB_PATH`):

| Instalação | Caminho base | Observação |
|---|---|---|
| `mwpos` | `C:\mwpos` ou `/home/administrador/mwpos_server` | default quando nada mais é encontrado |
| `edeployPOS` | `C:\edeployPOS` | usado como default nos scripts standalone (`DEFAULT_DB_DIR`) |
| `edeploy-pos-structure` | `C:\edeploy-pos-structure` | instalação mais recente |

**Atenção**: desde 31/08/2026 o `main.py` roda com `python\python.exe` (2.7), não mais com
`python3\python.exe` — ver incidente de campo de 31/08/2026. Toda instalação testada até agora
tem as duas pastas (`python\` e `python3\`) lado a lado; `python3\` continua existindo mas não é
mais usada pelo `main.py`. Se um erro mencionar `ImportError`/`bad magic number`, suspeitar
primeiro de estar rodando com o interpretador errado antes de assumir bug de lógica.

## Bancos de dados envolvidos

- **`order.db<N>`** (um por POS/caixa, `N` = número do caixa): tabelas `Orders`,
  `OrderCustomProperties` (incluindo `FISCAL_ID`, `FISCAL_XML`, `DISABLED_FISCAL_XML`,
  `ORDER_DISABLED`), `OrderStateHistory`, `OrderItem`, `OrderTax`, `OrderTender`, etc.
- **`fiscal_persistcomp.db`**: tabela `FiscalData` (`PosId`, `OrderId`, `XMLRequest`,
  `NumeroNota`, `SentToNfce`, `OrderPicture`, `DataNota`, ...) e `sequencer` (sequência do
  `FiscalId`).
- **`tblservice.db`**: tabela `serviceorders` (relaciona `orderid`/`posid` para pedidos remotos/
  delivery).
- **`pos_updater.db`**: tabela `updatescontroller`, usada só por `util.get_version()` para saber
  a última atualização de sistema aplicada.
- **`fiscal_params.db`**: tabela `FiscalParameter` (catálogo de classificação tributária por
  produto), usado só por `backfill_fiscal_params_from_order.py`.

## Log

Tudo grava em `system_script.log`, na pasta do script, formato
`timestamp - LEVEL - mensagem`, UTF-8. `FixingCstatCupons` usa um `getLogger("FixingCstatCupons")`
que propaga para esse mesmo log (só serve para identificar a origem das linhas, não abre arquivo
separado).

## Diagnóstico de `.pypkg`

`diagnose_pypkg.py` (nesta pasta) abre cada `.pypkg` da instalação (são arquivos zip, mesmo sem
extensão `.zip`) e procura em qual deles cada módulo do SDK (`old_helper`, `msgbus`, `bustoken`,
`cfgtools`, `mbcontextmessagehandler`, `order_api`) realmente está — sem precisar importar nada
(evita efeitos colaterais de conectar no barramento e-deploy). Útil sempre que um `ModuleNotFoundError`
aparecer envolvendo esses módulos, já que o layout dos `.pypkg` varia entre instalações. Uso:
`<python3 da loja> diagnose_pypkg.py`.

## Incidentes de campo conhecidos

### 28/08/2026 (1) — `ValueError: Unrecognised argument(s): encoding` ao rodar `main.py` numa loja

O `logging.basicConfig(..., encoding='utf-8')` original só funciona em Python 3.9+. Uma loja
tinha `python3\python.exe` numa versão anterior a 3.9, o que quebrava o script antes mesmo de
processar qualquer venda. Corrigido substituindo o `basicConfig` por configuração manual do
handler (`logging.FileHandler(log_filename, encoding='utf-8')` + `addHandler`), que produz o
mesmo resultado mas funciona em qualquer Python 3.x. Recomenda-se checar
`python3\python.exe --version` nas demais lojas para saber quantas ainda estão com runtime
desatualizado.

### 28/08/2026 (2) — `ModuleNotFoundError: No module named 'old_helper'` numa loja — causa raiz revista

Depois de corrigir o incidente (1), uma execução em outra loja (`C:\edeployPOS`) rodou até o fim
normalmente, mas logou que não conseguiu conectar ao `FixingCstatCupons` por falta do módulo
`old_helper` — o `except Exception` em `_obter_fixing_cstat_cupons()` capturou isso e a venda foi
processada normalmente pelo fluxo padrão, só sem a correção automática de protocolo.

Rodando `diagnose_pypkg.py` nessa loja, confirmou-se que `edpcommon3.pypkg` **não existe** ali —
`old_helper`/`bustoken` continuam em `edpcommon.pypkg` (o pacote "antigo"). Primeira correção
aplicada: `sys.path` no arquivo que continha `FixingCstatCupons` na época (`fix_cupom_protocol.py`,
depois removido em 31/08 — ver incidente próprio abaixo) /`order_picture.py`/`send_orderpaid_boh.py`
passou a apontar para `edpcommon.pypkg` em vez do inexistente `edpcommon3.pypkg`.

**Essa correção resolveu o caminho errado, mas não o problema de fundo.** Investigando mais a
fundo numa instalação de teste (`C:\edeploy-pos-structure`) onde o mesmo erro persistiu mesmo com
o caminho certo, comparei o magic number dos `.pyc` dentro de cada `.pypkg`:

| Pacote | Módulo | Magic number | Versão real do bytecode |
|---|---|---|---|
| `common3.pypkg` | `msgbus`, `cfgtools` | 3413 | Python 3.8 (build 3 de verdade) |
| `common.pypkg` | `msgbus`, `cfgtools` | 62211 | Python 2.7 |
| `edpcommon.pypkg` | `old_helper`, `bustoken` | 62211 | **Python 2.7** |

Ou seja: **`old_helper`/`bustoken` só existem compilados para Python 2.7, em todas as instalações
testadas até agora — não existe build Python 3 desses dois módulos em lugar nenhum** (diferente de
`msgbus`/`cfgtools`, que têm build 3 de verdade em `common3.pypkg`). Isso significa que
`FixingCstatCupons`, chamado a partir do `main.py` (Python 3), **nunca vai conseguir conectar** —
não é um problema de `sys.path`, é uma peça que falta no SDK do e-deploy para Python 3. O
`except Exception` que já existia em `_obter_fixing_cstat_cupons()` está certo em continuar
capturando esse erro e deixar a venda seguir pelo fluxo normal — isso não é um bug a mais para
corrigir, é o comportamento esperado enquanto essa build não existir.

**Decisão tomada (28/08/2026)**: em vez de tentar forçar isso a funcionar em Python 3, criado o
`fix_protocolo_cupons.py` — um script separado que roda com o Python 2.7 da própria instalação
(pasta `python\`, que existe ao lado de `python3\` em toda instalação e-deploy testada até agora)
e corrige as notas em lote, já que a correção manual nota a nota não escala quando acumula várias.
Ver seção própria em "Scripts standalone" acima. Decisão explícita: **não** integrar isso ao fluxo
automático do `main.py` via subprocess por venda (avaliado e descartado por enquanto — adicionaria
latência por venda) — o script roda manualmente ou agendado.

Também identificado no mesmo diagnóstico: `mbcontextmessagehandler` e `order_api` (usados por
`backfill_missing_order.py`) não existem em nenhum `.pypkg` da loja testada — esse script
standalone pode não funcionar nela.

### 31/08/2026 — `main.py` volta a rodar em Python 2.7; correção de protocolo consolidada

Decisão explícita do usuário: em vez de manter `fix_protocolo_cupons.py` como um script separado
duplicando ~200 linhas de `FixingCstatCupons` (a única forma de ter a correção automática por
venda funcionando de verdade, já que `old_helper`/`bustoken` só existem em Python 2.7 — ver
incidente de 28/08/2026 (2) acima), o `main.py` e todos os módulos que ele importa voltaram a
rodar com o Python 2.7 da instalação (pasta `python\`, ao lado de `python3\`). Isso faz a
correção automática de protocolo por venda (`_tentar_corrigir_protocolo_cupom`, em
`consulte_csv.py`) funcionar nativamente pela primeira vez em produção, sem precisar de
subprocess nem de rodar um Python separado por venda.

Mudanças aplicadas:
- `fix_apply.py`: `shutil.copytree(..., dirs_exist_ok=True)` → `distutils.dir_util.copy_tree`
  (`dirs_exist_ok` só existe a partir do Python 3.8).
- `fix_cupom_protocol.py` (na época), `order_picture.py`, `send_orderpaid_boh.py`: `sys.path`
  voltou a apontar para `common.pypkg` (em vez de `common3.pypkg`) — com o interpretador agora
  sendo 2.7, usar a build 3.8 de `msgbus`/`cfgtools` quebraria com "bad magic number".
  `edpcommon.pypkg` já estava certo (é a build 2.7, não mudou).
- `find_key_pattern` usava `open(file, encoding="utf-8", errors="replace")` — o `open()` nativo
  do Python 2.7 não aceita esses parâmetros (só existem no `open()` built-in a partir do Python
  3). Trocado por `io.open`, que aceita `encoding`/`errors` em ambas as versões. Esse era um bug
  latente que só ia aparecer quando o script voltasse a rodar em 2.7 de verdade.
- `FixingCstatCupons.fix_cstat` agora retorna `True`/`False` em vez de relançar a exceção (o
  traceback completo continua indo pro log via `self.logger.exception`) — necessário para
  `corrigir_lote` conseguir seguir para a próxima nota quando uma falha, sem interromper o lote
  inteiro.
- **Primeira rodada de consolidação ("integrar a correção do protocolo para não ficar em 1
  arquivo só")**: `encontrar_pendentes`/`corrigir_lote` (que antes existiam só em
  `CorrecaoProtocoloLote`, dentro de `fix_protocolo_cupons.py`) foram movidos para dentro de
  `FixingCstatCupons` (então ainda em `fix_cupom_protocol.py`), junto com `find_key_pattern`/
  `fix_cstat`/`get_order_picture`/`application_conn`, que já estavam lá. **Essa primeira rodada
  deixou dois arquivos** (`fix_cupom_protocol.py` com a classe, `fix_protocolo_cupons.py` como
  CLI fino por cima dela) — removido logo depois, no mesmo dia, ver incidente seguinte.
- `update.bat` também precisou mudar: `C:\edeploypos\python3\python.exe main.py update` →
  `C:\edeploypos\python\python.exe main.py update`.

### 31/08/2026 (2) — `fix_cupom_protocol.py` removido; tudo em `fix_protocolo_cupons.py`

Pedido explícito do usuário, no mesmo dia da mudança acima: *"Vamos remover esse
fix_cupom_protocol.py e deixa o arquivo novo fix_protocolo_cupons.py"*. A classe
`FixingCstatCupons` (com todos os métodos: `application_conn`, `find_key_pattern`,
`key_pattern_fiscallog`, `fix_cstat`, `encontrar_pendentes`, `corrigir_lote`, `process_resign`,
`process_unused_orders`, etc.) foi movida de `fix_cupom_protocol.py` para dentro de
`fix_protocolo_cupons.py`, junto com o CLI que já estava lá. `fix_cupom_protocol.py` foi
substituído por um stub de texto avisando que pode ser apagado (não consigo apagar arquivos na
máquina do usuário remotamente — só sobrescrever conteúdo).

Ajustes de import necessários:
- `consulte_csv.py`: `from fix_cupom_protocol import FixingCstatCupons` →
  `from fix_protocolo_cupons import FixingCstatCupons`.
- `main.py`: tinha um `from fix_cupom_protocol import *` que não usava nada diretamente (o
  `FixingCstatCupons` que o `main.py` eventualmente precisa já chega via `from consulte_csv import
  *`, que reexporta o nome). Removido em vez de repontar, pra não poluir o namespace do `main.py`
  com nomes do CLI (`argparse`, `parse_args`, `main`, etc.) que um `import *` de
  `fix_protocolo_cupons.py` traria.
- Dentro do próprio `fix_protocolo_cupons.py`: o `import` de `get_system_version` (de
  `consulte_csv.py`, usado só pelo CLI quando `--app-path` não é passado) foi movido para dentro
  da função `main()` do CLI, em vez de ficar no topo do arquivo — um import de nível de módulo
  criaria um import circular real (`consulte_csv.py` importa `fix_protocolo_cupons.py` no topo, e
  se `fix_protocolo_cupons.py` importasse `consulte_csv.py` de volta no topo também, o Python
  quebraria tentando resolver `get_system_version` antes dela existir). Como import circular só
  ocorre se as duas pontas importam a outra no nível de módulo, e o CLI só roda quando o arquivo é
  executado direto (não quando é importado como biblioteca), um import atrasado (dentro da função)
  resolve sem problema.

**Não consegui testar isso rodando Python 2.7 de verdade** (não existe mais nos repositórios
usados por este ambiente) — revisão foi manual, com `py_compile` sob Python 3 como checagem de
sintaxe (não prova compatibilidade de runtime 2.7, só ausência de erro de sintaxe). Recomendado
testar numa loja de homologação antes de depender disso em produção.

### 31/08/2026 (3) — `RE_PATTERN_LOTE` não cobre o formato `"[chNFe:...]"` que a SEFAZ manda

Pedido do usuário (com diff pronto) apontando que, em produção, o `xMotivo` da SEFAZ às vezes vem
com a chave de acesso entre colchetes e prefixada por `chNFe:` (`"... Chave de Acesso
[chNFe:52260817261661005566650010001226111137067129]"`), em vez do formato "puro" que o regex
original esperava (`"... Chave de Acesso 52260817261661005566650010001226111137067129"`). O `[`
logo depois de `"Chave de Acesso "` faz o grupo `([0-9]{44})` falhar de cara nesse caso, então
essas linhas nunca batiam — nem no `find_key_pattern` (correção automática por venda) nem em
`encontrar_pendentes`/`corrigir_lote` (modo lote).

Corrigido adicionando um segundo padrão (`RE_PATTERN_LOTE_CHNFE` no nível do módulo, e o
equivalente `re_pattern_chnfe` construído por orderid dentro de `find_key_pattern`) usado como
**fallback**: primeiro tenta o formato clássico, e só tenta o formato com colchete/label se o
primeiro não encontrar nada naquele arquivo/linha. Aplicado nos três lugares que faziam essa
varredura (`find_key_pattern`, `encontrar_pendentes`, e por consequência `corrigir_lote`/CLI, que
chamam `encontrar_pendentes`) — sem duplicar a lógica de fallback em cada um, só o padrão
alternativo em si.

### 31/08/2026 (4) — `SyntaxError: Non-ASCII character` ao rodar `main.py update` de verdade em Python 2.7

Usuário reportou (com print do terminal) que `main.py update` quebrava assim que rodado de fato
com o Python 2.7 da instalação (`C:\edeploypos\python\python.exe`, pasta `C:\edeployPOS\find_xml`):

```
File "C:\edeployPOS\find_xml\send_orderpaid_boh.py", line 18
SyntaxError: Non-ASCII character '\xc3' in file ... but no encoding declared
```

**Causa raiz**: PEP 263 — todo arquivo-fonte Python 2.7 que contém bytes não-ASCII precisa
declarar o encoding na 1ª ou 2ª linha (`# -*- coding: utf-8 -*-`); sem isso o interpretador recusa
o arquivo assim que encontra o primeiro byte não-ASCII. Python 3 não tem essa exigência (assume
UTF-8 por padrão), então esse tipo de bug fica invisível em qualquer checagem feita sob Python 3 —
inclusive o `py_compile` usado neste ambiente para validar sintaxe, que **não** pega esse
problema porque ele mesmo roda em Python 3. Só aparece rodando com um interpretador 2.7 de
verdade, como o usuário fez.

`order_picture.py` e `send_orderpaid_boh.py` ganharam comentários em português com acentos durante
o trabalho de volta pro Python 2.7 (28-31/08/2026) mas ficaram sem a declaração de encoding — os
dois quebravam. Corrigido adicionando `# -*- coding: utf-8 -*-` como primeira linha dos dois.
Também adicionada preventivamente em `fix_apply.py` e `decode_base64.py` (hoje só ASCII, mas sem a
declaração — um futuro comentário acentuado quebraria os dois do mesmo jeito, silenciosamente).

Checagem feita varrendo os 12 arquivos principais em busca da declaração e de bytes não-ASCII;
confirmado que os 4 arquivos corrigidos agora têm a declaração e passam em `py_compile`.

**Importante — alcance da correção**: os 4 arquivos corrigidos foram commitados no repositório git
(`C:\Automação\Git - Privado\Script---Privado\xml_venda\find_xml`), que é a pasta conectada a esta
sessão. A pasta onde o erro realmente aconteceu, `C:\edeployPOS\find_xml`, **não está conectada a
esta sessão** — a correção não chega lá sozinha. É preciso levar os arquivos corrigidos
(`order_picture.py`, `send_orderpaid_boh.py`, `fix_apply.py`, `decode_base64.py`) manualmente até
`C:\edeployPOS\find_xml` (cópia direta, git pull, ou conectando essa pasta a uma sessão) antes de
testar de novo lá.

**Achado à parte, ainda não sincronizado**: `C:\edeploy-pos-structure\find_xml` (uma das pastas
conectadas) está com uma cópia antiga, de ~28/08/2026, anterior a toda a volta pro Python 2.7 e à
consolidação do `fix_protocolo_cupons.py` — inclusive ainda tem o `fix_cupom_protocol.py` antigo,
nunca tocado. É uma terceira instalação, separada tanto do repo git quanto do `C:\edeployPOS`. Não
mexi nela ainda; fica registrado aqui até decidirmos se/como sincronizar.

### 31/08/2026 (5) — `UnicodeDecodeError: 'ascii' codec ...` ao logar mensagem com acento (rodando com `C:\Python27\python.exe`)

Depois do fix do item (4), usuário testou rodando `main.py` direto com um Python 2.7 diferente
(`C:\Python27\python.exe`, não o `C:\edeploypos\python\python.exe` da instalação — parece um
Python 2.7 do sistema/IDE, rodando a partir da própria pasta do repo git) e bateu num erro
diferente, agora dentro do próprio `logging`:

```
File "C:\Python27\lib\logging\__init__.py", line 891, in emit
    stream.write(fs % msg.encode("UTF-8"))
UnicodeDecodeError: 'ascii' codec can't decode byte 0xc3 in position 53: ordinal not in range(128)
Logged from file main.py, line 54
```

**Causa raiz**: `main.py` linha 19 configurava o handler de log assim:
`logging.FileHandler(log_filename, encoding='utf-8')`. Passar `encoding=` faz o `FileHandler`
abrir o arquivo via `codecs.open()`, cujo `stream.write()` só aceita `unicode` — se receber um
`str` comum (bytes), tenta decodificá-lo primeiro com o codec padrão (`ascii`) antes de
recodificar. Em Python 2.7, uma string literal como `"Validando as informações do arquivo
bkoffice.csv"` (linha 54 do `main.py`) é um `str` já em bytes UTF-8 (por causa do `# -*- coding:
utf-8 -*-` no topo do arquivo) — não é `unicode`. Assim que essa mensagem chega no
`stream.write()` do handler, o Python tenta decodificá-la como ASCII e quebra no primeiro byte
não-ASCII (`0xc3`, o primeiro byte de "ç" em "informações"). Conferido: o deslocamento de byte 53
apontado no erro bate exatamente com a posição do primeiro `0xc3` na linha de log já formatada
(`"<data> - INFO - Validando as informações do arquivo bkoffice.csv"`), confirmando o diagnóstico.

Isso não derruba o processo (o próprio `logging` captura o erro internamente em `handleError()` e
só imprime esse traceback no stderr como diagnóstico — é o mesmo texto que aparece sempre que um
handler falha ao emitir um registro), mas é sinal de que a linha nunca é gravada no
`system_script.log`, e o comportamento poderia variar dependendo do stream/console.

Mesmo padrão (`logging.FileHandler(..., encoding="utf-8")`) existia também em
`fix_protocolo_cupons.py` (`_configurar_log()`, usado pelo CLI), com o mesmo risco assim que
qualquer mensagade logada tivesse acento (ex: mensagens de erro/aviso em português).

**Corrigido** removendo o parâmetro `encoding=` dos dois `FileHandler` (`main.py` e
`fix_protocolo_cupons.py`). Sem esse parâmetro, o `FileHandler` abre o arquivo como um arquivo
binário comum — `stream.write()` aceita `str` (bytes) diretamente, sem tentar decodificar nada. O
`.log` final continua sendo texto UTF-8 válido (porque as mensagens já chegam como bytes UTF-8),
só que sem a camada `codecs` no meio que provocava a decodificação implícita em ASCII.
`send_orderpaid_boh.py` (`StandAlone.__init__`, ainda não chamado em nenhum ponto ativo) usa
`logging.basicConfig(..., filename=...)` sem `encoding=` — não tem esse problema, então não
precisou de alteração.

Commitado no repositório git (a pasta conectada a esta sessão) — mesma ressalva do incidente
(4): ainda não chega em `C:\edeployPOS\find_xml` sozinho, precisa ser levado manualmente pra lá
(ou pra qualquer outra instalação onde o usuário for testar, como a pasta local onde rodou esse
teste com `C:\Python27\python.exe`).

### 31/08/2026 (6) — `ImportError: Could not find library 'libaprutil-1'` ao corrigir protocolo de verdade via `main.py` (mas não rodando o script standalone) — causa raiz: `os.chdir` restaurado cedo demais

Depois do fix do item (5), usuário rodou `main.py` de verdade com `C:\edeploypos\python\python.exe`
(o interpretador certo da instalação) e a correção automática de protocolo chegou a funcionar até
`fix_cstat` — achou o cStat 539, leu o orderpicture, montou o XML novo — mas quebrou na hora de
**gravar** (`update_fiscal_persist`), com uma exceção capturada e logada (não derruba o processo,
o resto do `main.py` continua):

```
File "C:\edeployPOS\find_xml\fix_protocolo_cupons.py", line 441, in fix_cstat
    self.update_fiscal_persist(orderid, new_request)
File "C:\edeployPOS\find_xml\fix_protocolo_cupons.py", line 407, in update_fiscal_persist
    self.base_repository(self.mbcontext).execute_with_connection(inner_func, service_name="FiscalPersistence")
File "...\edpcommon\dist\old_helper.py", line 337, in execute_with_connection
File "...\wrappers\python\persistence.py", line 249, in __init__
File "...\persistence.py", line 206, in _init_dll
File "...\persistence.py", line 188, in _load_native
ImportError: Could not find library 'libaprutil-1'.
```

Investigação por eliminação, com a ajuda do usuário:
- Confirmado (busca no Explorer) que `libaprutil-1.dll` **existe**, exatamente em `C:\edeployPOS\bin`
  — a mesma pasta que `FixingCstatCupons.application_conn()` usa como `BINPATH` e faz `os.chdir()`
  antes de importar `old_helper`. Junto dela, também confirmadas `libapr-1.dll` e
  `libapriconv-1.dll` (as dependências dela) — todas presentes, mesma pasta, mesma data. Descarta
  DLL faltando ou pasta errada.
- Usuário rodou o **script standalone** (`fix_protocolo_cupons_bkp.py`, a versão de 28/08, antes da
  consolidação, com sua própria classe `CorrecaoProtocoloLote`) pro mesmo orderid, com o mesmo
  `python.exe` — **funcionou sem erro nenhum**. Essa foi a pista decisiva: alguma diferença entre
  rodar via `main.py` e rodar esse script isolado estava causando o problema, já que a lógica de
  `application_conn()`/`fix_cstat`/`update_fiscal_persist` é essencialmente a mesma nos dois.

**Causa raiz encontrada**: `consulte_csv.py`, `_obter_fixing_cstat_cupons()` (a função que
constrói e cacheia o `FixingCstatCupons`, adicionada na reversão de 31/08 pra reaproveitar a
conexão entre vendas) tinha:

```python
cwd_original = os.getcwd()
try:
    ...
    _fixing_cstat_cupons = FixingCstatCupons(app_path)
    return _fixing_cstat_cupons
except SystemExit:
    ...
except Exception as ex:
    ...
finally:
    os.chdir(cwd_original)     # <- rodava SEMPRE, inclusive quando dava certo
```

O `finally` roda mesmo quando o `try` já deu `return` — então, IMEDIATAMENTE depois de
`FixingCstatCupons.__init__()` → `application_conn()` fazer `os.chdir(BINPATH)` (de propósito,
pra o SDK achar seus módulos/DLLs), esse `finally` desfazia isso, devolvendo o cwd pro que era
antes de `_obter_fixing_cstat_cupons()` ser chamada.

Isso por si só não quebraria nada se o carregamento da DLL nativa acontecesse na hora de conectar
— mas o SDK (`old_helper.py`/`persistence.py`) carrega `libaprutil-1.dll` de forma **lazy**: só na
primeira vez que uma conexão de escrita de verdade é aberta (`BaseRepository(mbcontext)`, chamado
de dentro de `update_fiscal_persist`), não no `__init__`/`application_conn()`. Ou seja, o cwd
certo (`BINPATH`) só precisava estar em vigor bem mais tarde, no `fix_cstat` — mas àquela altura já
tinha sido desfeito pelo `finally`.

E pra completar: o `cwd_original` capturado no início de `_obter_fixing_cstat_cupons()` quase nunca
era o diretório "neutro" que se esperaria — o `main.py`, antes de chegar em `time_direction()`
(onde a correção é tentada), já rodou `find_fiscal_id()` (em `sqlite_update.py`) pra cada nota do
CSV, e essa função faz `os.chdir(file_orders)` seguido de `os.chdir(".")` — o segundo chdir é um
no-op (fica no mesmo lugar), então NUNCA restaura o cwd original; ele fica parado em `file_orders`
(uma pasta de banco de dados) pelo resto da execução. Então o `finally` não só desfazia o
`chdir(BINPATH)`, como devolvia o processo pra essa pasta de banco de dados errada - onde a DLL
obviamente não está - explicando o `ImportError`.

O script standalone nunca tinha esse problema porque não tem esse `finally`/wrapper nenhum: o
`os.chdir(BINPATH)` do `application_conn()` fica valendo pelo resto do processo, sem ninguém
desfazer.

**Corrigido** em `consulte_csv.py`: o `os.chdir(cwd_original)` só roda agora nos ramos de
**falha** (`except SystemExit`/`except Exception`) — não mais no sucesso. Depois que
`FixingCstatCupons` conecta com sucesso, o cwd fica parado em `BINPATH` pelo resto da execução do
`main.py`. Conferido que isso é seguro: nenhuma outra função usada no restante do
`time_direction()` (`update_xml_APED23848`, `FiscalData`, `validate_status`) depende de caminho
relativo — todas recebem o caminho absoluto do banco via parâmetro. Só `find_fiscal_id` e
`not_order_picture` dependem do cwd (usam `glob.glob()` relativo), e as duas já fazem o próprio
`os.chdir` logo antes de usar, então funcionam a partir de qualquer cwd anterior.

Deixei também um log de diagnóstico temporário em `fix_protocolo_cupons.py` (`update_fiscal_persist`,
adicionado durante a investigação deste incidente, antes de achar a causa raiz) que imprime o cwd e
se a DLL é visível dali - útil pra confirmar no próximo teste que o cwd realmente ficou em `BINPATH`
dessa vez. Pode ser removido depois de confirmado.

**Ainda não testado de ponta a ponta** com essa correção - só a hipótese foi validada por
eliminação (DLL existe, standalone funciona, o único `finally` que desfazia o chdir era esse).
Commitado no repositório git; falta levar `consulte_csv.py` (e o `fix_protocolo_cupons.py` com o
log de diagnóstico) pra `C:\edeployPOS\find_xml` e testar de novo.

### 04/09/2026 — `RE_PATTERN_LOTE`/`RE_PATTERN_LOTE_CHNFE` não cobrem um terceiro formato de
`"Chave de Acesso"` (colchete sem label `chNFe:`, com protocolo `nRec` junto)

Usuário reportou um caso real (orderid 000023819, cStat 539) em que a linha do
`FiscalWrapperThread.log` vem num formato diferente dos dois já tratados:

```
Tratando 539 da order 000023819. xMotivo SEFAZ: Duplicidade de NF-e, com diferenca na Chave de
Acesso. [41260858283002000387650010000231931538413398][nRec:926001464373585]
```

Diferenças em relação aos formatos já cobertos: tem um `.` antes do colchete (`"Chave de Acesso.
["`, não `"Chave de Acesso ["`), a chave vem entre colchetes mas **sem** o label `chNFe:`, e logo
em seguida vem um **segundo** colchete com o protocolo/recibo da SEFAZ (`nRec`) — algo que os dois
formatos anteriores não tinham. Nem `RE_PATTERN_LOTE` (espera a chave "pura", sem colchete) nem
`RE_PATTERN_LOTE_CHNFE` (exige o label `chNFe:` dentro do colchete) batiam nessa linha.

**Corrigido** adicionando um terceiro padrão, `RE_PATTERN_LOTE_COLCHETE` (módulo) e o equivalente
`re_pattern_colchete` (construído por orderid dentro de `find_key_pattern`), tentado como último
fallback — só se nem o clássico nem o `[chNFe:...]` encontrarem nada na linha/arquivo. O regex
aceita o `.` antes do colchete opcionalmente (`Chave de Acesso\.?\s*\[...\]`), então também cobre
um eventual formato futuro sem o `.`. O segundo colchete (`[nRec:<dígitos>]`) é capturado num
grupo à parte e opcional — quando presente, é só logado (`"Protocolo (nRec) encontrado no log -
orderid: ... nRec: ..."`) para diagnóstico; `fix_cstat` continua usando somente a chave de acesso
para corrigir o XML, o `nRec` do log não é usado na correção em si (o `end_xml` de `fix_cstat`
já grava um `nRec` fixo/placeholder no protocolo reconstruído — ver `fix_cstat`, isso não mudou
aqui).

Aplicado nos três lugares que fazem essa varredura (`find_key_pattern`, `encontrar_pendentes`, e
por consequência `corrigir_lote`/CLI, que chama `encontrar_pendentes`) — mesmo padrão de fallback
em cascata já usado para `RE_PATTERN_LOTE_CHNFE`. Testado com `re.findall`/`py_compile` (Python 3,
só checagem de sintaxe e do próprio regex — não valida em runtime 2.7 de verdade, mesma ressalva
de sempre para mudanças nesta pasta). **Ainda não testado em produção** contra o log real da loja.

Commitado no repositório git (pasta conectada a esta sessão); ainda não levado para
`C:\edeployPOS\find_xml` nem para as demais instalações — mesma ressalva dos incidentes
anteriores (git ≠ instalação em produção).

### 04/09/2026 (2) — Integração de `restore_order_from_backup.py` em `main.py` para notas ausentes do banco de pedidos

Pedido do usuário: quando `find_fiscal_id` não acha a nota em nenhum `order.db<N>` corrente (loga
`"Nota não identificada no banco {}"` e segue sem essa venda), tentar restaurar do backup antes de
desistir, usando `restore_order_from_backup.py` (script standalone já existente nesta pasta,
criado antes da consolidação de 28-31/08, nunca integrado ao fluxo automático).

**Adicionada** a função `restaurar_nota(fiscal_id, db_dir=None, backup_dir=None, ...,
yes=True)` em `restore_order_from_backup.py` — versão programática de `process_note()` (a mesma
lógica do CLI: bases correntes → backup de pedidos → reconstrução via `OrderPicture`), que monta
o `argparse.Namespace` internamente em vez de exigir linha de comando, com `yes=True` por padrão
(diferente do CLI) porque não tem ninguém pra responder ao prompt `[s/N]` numa chamada automática.
`process_note` passou a `return resolved_order_ids` no final (antes não retornava nada) para quem
chama programaticamente saber se a nota foi resolvida — não muda o CLI (`main()`, que ignora esse
retorno).

`main.py` (`main()`) agora: (1) faz a primeira varredura com `find_fiscal_id` normalmente,
guardando as notas não encontradas numa lista; (2) para cada uma dessas, chama `restaurar_nota`
(usando `path_orders`/`path_orders_backup`, já detectados no topo de `main.py` pela instalação);
(3) se `restaurar_nota` resolveu alguma coisa (lista de `OrderId`s não vazia), chama
`find_fiscal_id` de novo só pra essa nota e, se agora aparecer, adiciona em `xml_bin` como se
tivesse sido encontrada de primeira — o resto do fluxo (`time_direction` etc.) não precisou de
nenhuma mudança, porque recebe exatamente o mesmo formato de dado de antes.

**Testado functionalmente** (Python 3, fora deste repositório): criado um `order.db1` vazio e um
`orders_202601.db` de backup com uma nota fictícia, chamado `restaurar_nota` diretamente — a nota
foi corretamente localizada no backup, copiada pro `order.db1` (com backup de segurança `.bkp`
criado antes de gravar), e uma segunda consulta ao `order.db1` confirmou a linha importada. Isso
valida a lógica de `restaurar_nota`/`process_note`, mas **não** substitui testar de verdade
integrado ao `main.py` rodando em produção (Python 2.7, bases reais).

**Mudança de premissa importante**: `restore_order_from_backup.py` era um dos três scripts
"nativamente Python 3" (ver `## Visão geral`), e por só rodar standalone nunca precisou ser
compatível com o Python 2.7 que `main.py` usa. Agora que `main.py` o importa, ele é parseado
pelo Python 2.7 também. Revisado o arquivo inteiro: não usa f-string, type hints, nem nenhuma
outra sintaxe exclusiva de Python 3 (só `.format()`, igual ao resto da pasta) — a única mudança
foi adicionar `# -*- coding: utf-8 -*-` (PEP 263) por precaução (nenhum acento no arquivo hoje,
mas evita repetir o incidente de 31/08/2026 (4) se um comentário acentuado for adicionado no
futuro). Ponto de atenção que **não** foi alterado: `process_note`/`process_fiscal_data` usam
`input()` para confirmação quando `yes=False` e `dry_run=False` — em Python 2, `input()` faz
`eval()` do texto digitado (diferente do `raw_input()` que o resto da pasta usa) — mas
`restaurar_nota` sempre chama com `yes=True` na integração com `main.py`, então esse caminho não
é exercitado por ela (só importa se alguém rodar o CLI manual com `python\python.exe` 2.7 sem
`--yes`, o que já seria incomum já que o uso documentado é com `python3`).

**Achado à parte, não corrigido (pré-existente, fora do escopo deste pedido)**: `path_orders` (e
agora também `path_orders_backup`) só são definidos em `main.py` para as instalações
`C:\edeployPOS` e `C:\edeploy-pos-structure` — a instalação `/home/administrador/mwpos_server`
(Linux) não define nenhuma das duas. Isso já quebraria `main()` com `NameError` na primeira
chamada de `find_fiscal_id`, antes mesmo de chegar no código novo — não é algo que esta mudança
introduziu, mas voltou a ficar visível ao mexer nessa função. Registrado como item novo em "O que
ainda é dívida técnica" abaixo.

Commitado no repositório git (pasta conectada a esta sessão); mesma ressalva de sempre — ainda
não testado de ponta a ponta com Python 2.7 real nem levado para `C:\edeployPOS\find_xml`.

### 09/09/2026 (2) — `inutilizar_nota_orfa()` quebra em produção: `ImportError: No module named pos_model`

Primeira tentativa real de `inutilizar_nota_orfa()` numa loja (nota 122611) falhou:

```
Inutilização da nota 122611 - sucesso: False, mensagem: Erro ao inutilizar
numero 122611 (serie None): No module named pos_model
```

O `"serie None"` no log confirma que a falha aconteceu **dentro de `_montar_disabler`**, antes da
linha que lê `cfg["serie"]` — ou seja, `default_bundle_dir()`/`default_fiscalwrapper_src()`
(pendência registrada no item de dívida técnica de 09/09/2026, abaixo) na verdade **estavam
certos** (confirmado direto na instalação real, `C:\edeploy-pos-structure` —
`loader_NFCE.cfg`/`nfce_urls.xml` ficam exatamente em `default_bundle_dir()`, e
`nfcedisabler`/`models`/`comp_exceptions` ficam exatamente em `default_fiscalwrapper_src()`).
Reproduzido numa segunda instalação (10/09/2026) — não era coisa de uma loja específica.

**Causa raiz**: `nfcedisabler/__init__.py` (arquivo do PRÓPRIO fiscalwrapper, não deste script)
importa incondicionalmente, além das classes de baixo nível que este arquivo usa (`NfceDisabler`,
`NfceDisablerParameters`/`RequestBuilder`/`ResponseParser`, `ProcInutNfeBuilder`/`Saver`), duas
classes que não existiam quando esta integração foi escrita: `OrderRepository` e `OrderDisabler`
(`_OrderRepository.py`/`_OrderDisabler.py`) — usadas pelo fluxo "inutilizar tudo que estiver
pendente, varrendo todos os POS/orders" do próprio fiscalwrapper (disparado de dentro do processo
real, conectado ao msgbus, quando alguém aciona o evento `DisableNfceOrder` — ver
`FixingCstatCupons.process_unused_orders` em `fix_protocolo_cupons.py`). Esses dois módulos fazem
`from pos_model import (OrderKey, PosConnection)` e `from posot import OrderTakerException` —
módulos do SDK e-deploy que só existem carregados **dentro do processo real** do fiscalwrapper
(msgbus com lista de POS de verdade) e que não existem como arquivo em lugar nenhum da instalação
(confirmado varrendo `bin/*.pypkg`, `src/fiscalwrapper/lib/` e `src/fiscalwrapper/src/` inteiros —
nenhum tem `pos_model` nem `posot`). Como Python executa `__init__.py` por INTEIRO ao importar
qualquer submódulo de um pacote, o simples `from nfcedisabler import NfceDisabler` (em
`_montar_disabler`) já dispara essa cadeia de import e quebra, mesmo essa função nunca usando
`OrderRepository`/`OrderDisabler`.

(O script original desta pasta — `xml_venda/inutilizacao/inutilizar_numeros_orfaos.py`, usado
manualmente no incidente da loja osaka — faz o mesmo import e não quebrava: rodou contra uma
versão mais antiga do fiscalwrapper, de antes do e-deploy adicionar `_OrderRepository.py`/
`_OrderDisabler.py` ao componente. As instalações testadas agora já receberam esse patch — não é
regressão desta integração.)

**Corrigido** registrando stubs mínimos para `pos_model`/`posot` em `sys.modules` (função
`_stub_pos_model_dependencies`, chamada logo antes do primeiro `from nfcedisabler import ...` em
`_montar_disabler`) — só o suficiente para `nfcedisabler/__init__.py` rodar até o fim (os stubs
nunca são efetivamente usados por este arquivo). Confirmado, lendo o código-fonte de
`_NfceDisabler`/`_NfceDisablerRequestBuilder`/`_NfceDisablerResponseParser`/
`_ProcInutNfeBuilder`/`_ProcInutNfeSaver`/`_NfceDisablerParameters` (as classes que este arquivo
de fato instancia), que nenhuma delas depende de `pos_model`/`posot` para nada — seguro stubar.

**Lição à parte, sobre o processo de aplicar a correção**: a correção só foi commitada na pasta
git conectada a esta sessão (`...\Script---Privado\xml_venda\find_xml\`) — a instalação real
rodando (`C:\edeploy-pos-structure\find_xml\`) é uma pasta **separada**, que não recebe as
mudanças automaticamente (mesmo padrão já documentado em "Atualização de componentes" acima, só
que para este script específico, que não passa pelo `fix_apply.py`). O usuário reportou o mesmo
erro persistindo mesmo depois da correção "aplicada" — a causa era essa desincronia, não a
correção em si. **Sempre que este arquivo for alterado, ele precisa ser copiado manualmente para
CADA instalação real em uso, além de commitado no git.**

### 10/09/2026 — Mesma família de erro, mais nomes do SDK: `cannot import name TenderType`

Depois da correção acima, a mesma nota de teste (122611) avançou e quebrou de novo:

```
Inutilização da nota 122611 - sucesso: False, mensagem: Erro ao inutilizar
numero 122611 (serie None): cannot import name TenderType
```

O import chegou a executar `nfcedisabler/__init__.py` até o fim (o stub anterior resolveu isso),
mas quebrou num import **seguinte**, ainda em `from models import NfModel` (a primeira linha
depois de `_stub_pos_model_dependencies()` em `_montar_disabler`) — `models/__init__.py` importa
`_PosTenderToNfeTender.py`, que faz `from pos_model import TenderType`. O erro mudou de "No
module named pos_model" para "cannot import name TenderType" porque `pos_model` já existia em
`sys.modules` (por causa do stub anterior), só sem o atributo `TenderType`.

Varrendo desta vez **todo** `src/fiscalwrapper/src/` (`models/`, `services/`, `nfcebuilder/`,
`comp_exceptions/`, `adapter/`) para não repetir o ciclo de "corrigir um nome por vez a cada
teste em produção" (cada teste aqui é uma inutilização de verdade, irreversível), mapeado o
conjunto completo de nomes de SDK que faltam no grafo de imports alcançável por
`_montar_disabler`:
- `pos_model`: além de `OrderKey`/`PosConnection` (já cobertos), faltavam `TenderType`
  (`models/_PosTenderToNfeTender.py`), `OrderTender` (`services/_TPagService.py`), e — por
  varredura mais ampla dos demais arquivos de `models/`/`nfcebuilder/` — `Order`, `SaleItem`,
  `TaxItem`, `Fee`, `OrderParser`.
- `old_helper`: `round_half_away_from_zero`, `remove_punctuation`, `remove_xml_namespace`,
  `OrderTaker`.
- `helper` (módulo **diferente** de `old_helper`): `remove_accents`, `is_valid_cnpj` — este
  **existe de verdade** em `src/fiscalwrapper/lib/helper.py` (ao lado das libs vendorizadas
  `cryptography`/`lxml`/`signxml`/`requests` que `NfeSigner`/`XmlEnveloper` usam de verdade), só
  não estava em `sys.path`.

Confirmado (lendo cada classe usada de fato: `NfceDisabler` e colaboradores) que nenhuma delas usa
essas constantes/funções para nada além de comparação/formatação que este fluxo nunca exercita —
seguro stubar `pos_model`/`old_helper`, com uma ressalva: **`old_helper` já apareceu como módulo
real** em `edpcommon.pypkg` em outra instalação (ver incidente 28/08/2026 (2) acima) — não existe
nesta instalação especificamente, mas por precaução o stub só é registrado se um `import
old_helper` de verdade falhar primeiro (mesmo padrão do `helper`, que é resolvível de verdade
nesta instalação).

**Corrigido**: `_stub_pos_model_dependencies()` expandida para cobrir os quatro módulos acima,
usando um stub genérico "AnyAttr" (metaclasse `_AnyAttrMeta` cujo qualquer atributo de classe,
ex: `TenderType.cash`, devolve um valor sentinela) para os nomes que funcionam como
enum/constante, em vez de listar cada valor manualmente. `_montar_disabler` também passou a
adicionar `<fiscalwrapper_src>/../lib` ao `sys.path` **antes** de chamar
`_stub_pos_model_dependencies()`, para que `helper`/`old_helper` resolvam de verdade quando
existirem (correção real, não stub) — só cai no stub como fallback.

Aplicada a mesma lição do incidente anterior: a correção foi commitada tanto na pasta git
conectada (`...\Script---Privado\xml_venda\find_xml\`) quanto copiada manualmente para a
instalação real (`C:\edeploy-pos-structure\find_xml\`).

**Ainda não confirmado**: uma inutilização chegando de fato a conversar com a SEFAZ (só os imports
foram testados até agora). Risco identificado mas não confirmado: `_ProcInutNfeSaver.save_proc_
inut_nfe_xml` (chamada de verdade por este fluxo) importa `iso8601`, pacote não encontrado em
`src/fiscalwrapper/lib/` nesta instalação — se realmente faltar, seria um `ImportError` real (não
stubável sem risco, já que é usado de verdade), só vai aparecer no próximo teste.

### 10/09/2026 (2) — Terceiro erro consecutivo (`No module named modelcommon.model`) — troca de estratégia: finder genérico em vez de mapear nome por nome

Depois da correção acima, a mesma nota de teste (122611) quebrou **pela terceira vez**:

```
Inutilização da nota 122611 - sucesso: False, mensagem: Erro ao inutilizar
numero 122611 (serie None): No module named modelcommon.model
```

Isso é um import de **dois níveis** (`modelcommon.model`, não só `modelcommon`) — `nfcebuilder/
_IdeBuilder.py`, `_EmitBuilder.py` e `_TranspBuilder.py` fazem `from modelcommon.model import
Store`, e esses três builders são importados incondicionalmente por `nfcebuilder/__init__.py`
(disparado por `from nfcebuilder.nfceutil import ...`, em `_montar_disabler`) — mesmo padrão dos
dois incidentes anteriores, só que num pacote diferente (`nfcebuilder`, não `nfcedisabler`).

**Achado mais importante desta rodada**: varrendo `import`/`from` em **todo** `src/fiscalwrapper/
src/` de uma vez (não só os arquivos já mapeados), ficou claro que essa árvore de imports não tem
fim natural — `_OrderDisabler.py` (já stubado por causa de `pos_model`/`posot`/`old_helper`) faz
`from services import OrderService`, o que força **todo** o pacote `services/` a carregar, que por
sua vez importa `common` (outro pacote, que tem `modelcommon.fiscalwrapper` dentro),
`repository`, `fiscalpersistence`, `cfgtools`, `pem` — cada um potencialmente um novo nome faltando
descoberto só no próximo teste real em produção (irreversível, com confirmação manual). Continuar
respondendo um nome por vez (a estratégia dos dois incidentes anteriores) não escala.

**Correção — mudança de estratégia**: em vez de listar manualmente cada nome do SDK que falta,
criado `_AutoStubImportFinder` (um finder de import, `sys.meta_path`), instalado só durante a
janela de `_importar_modulos_fiscalwrapper()` (nova função que concentra os imports do próprio
fiscalwrapper, chamada por `_montar_disabler`) e removido logo depois. Ele tenta o import de
verdade primeiro (via `__import__`, que passa por zipimport — cobre módulos dentro de `.pypkg`,
diferente de só checar arquivos em disco) e só registra um stub genérico (`_AutoStubModule`, que
responde a qualquer atributo/submódulo dotted) se esse import real falhar — cobre `pos_model`,
`posot`, `old_helper`, `modelcommon.model`, e qualquer outro nome que aparecer no futuro, sem
precisar de mais uma rodada de mapeamento manual. `_stub_pos_model_dependencies()` e a lista
manual de atributos por módulo foram **removidas** — o finder genérico cobre os mesmos casos.

**Duas salvaguardas importantes**:
- O finder só intercepta um nome **depois** que a tentativa de import real falhar — nunca compete
  com um módulo genuíno (mesmo comportamento de antes com `helper`/`old_helper`, generalizado).
- `_NUNCA_STUBAR_IMPORT` (lista curta e explícita: `iso8601`, `cryptography`, `lxml`, `signxml`,
  `requests`) marca os poucos módulos que este fluxo usa **de verdade** em tempo de execução (não
  só em definição de classe) — nunca são interceptados, mesmo que o import real falhe; um
  `ImportError` nesses sobe normalmente, sinalizando um problema real de instalação em vez de ser
  mascarado silenciosamente.

Cada nome efetivamente stubado numa execução é logado (`logger.warning`) — nunca silencioso.

Testado isoladamente (Python 3, fora deste repositório): confirmado que o finder resolve
corretamente um nome dotted totalmente inexistente (simulando `modelcommon.model`), que não
intercepta um módulo real (`json`), e que deixa o `ImportError` subir normalmente para um nome da
lista `_NUNCA_STUBAR_IMPORT` mesmo genuinamente ausente. `py_compile` passou; commitado tanto na
pasta git conectada quanto copiado manualmente para a instalação real
(`C:\edeploy-pos-structure\find_xml\`) — mesma lição dos dois incidentes anteriores.

**Ainda não confirmado**: uma inutilização chegando de fato a conversar com a SEFAZ. Com o finder
genérico em vigor, um quarto nome de módulo faltando (se aparecer) deve resolver sozinho sem
precisar de mais uma correção — o próximo teste real deve avançar além dos `ImportError`s de uma
vez, e só então falhar por outro motivo (config/certificado/rede/SEFAZ), ou finalmente ter sucesso.

**Falha no próprio processo de aplicar esta correção**: o usuário testou de novo logo depois desta
correção "aplicada" e reportou o **mesmo** erro (`No module named modelcommon.model`) — a
ferramenta usada pra copiar o arquivo corrigido pra `C:\edeploy-pos-structure\find_xml\` (e pra
pasta git) reportou sucesso (`"written"`), mas checando o arquivo de volta logo depois (listagem
direta do diretório, com tamanho/timestamp do arquivo — não só confiar na resposta da ferramenta),
os dois locais ainda tinham a versão **anterior** (a do incidente "cannot import name TenderType",
42035 bytes), sem o finder genérico. Recommitado e desta vez **confirmado por listagem direta do
diretório** (49241 bytes, timestamp novo, nos dois locais) antes de pedir um novo teste ao
usuário. **Lição**: depois de qualquer commit remoto neste arquivo, sempre conferir o tamanho/
timestamp do arquivo de volta via listagem de diretório — a resposta de sucesso da ferramenta de
commit, sozinha, não é garantia suficiente de que o conteúdo realmente mudou no disco.

Achado à parte: `C:\edeploy-pos-structure\find_xml\inutilizar_numeros_orfaos.pyc` existe (do
Python já ter rodado o script antes) — não deveria causar problema, porque o Python 2.7 compara o
mtime do `.py` embutido no cabeçalho do `.pyc` com o mtime atual do `.py` e recompila sozinho se
não bater (e agora não bate, já que o `.py` acabou de ser sobrescrito) — mas fica registrado como
possível suspeito se o mesmo erro aparecer de novo depois desta correção.

### 10/09/2026 (3) — Bug crítico no `_AutoStubImportFinder`: módulos REAIS (logging, os, time, requests, xml, enum...) sendo stubados por engano — corrigido

A correção anterior (finder genérico) de fato resolveu o `modelcommon.model` — o log do próximo
teste mostrou `serie 2` (não mais `None`), ou seja, o fluxo avançou de verdade além dos imports do
SDK pela primeira vez. Mas o mesmo log trouxe um `logger.warning` alarmante, listando **mais de 50
nomes stubados automaticamente** numa única execução — entre eles `nfcedisabler.logging`,
`nfcedisabler.os`, `nfcedisabler.time`, `nfcedisabler.base64`, `nfcedisabler.requests`,
`nfcedisabler.xml`, `nfcedisabler.xml.etree`, `nfcebuilder.xml.etree`, `nfcebuilder.datetime`,
`nfcebuilder.json`, `nfcebuilder.hashlib`, `nfcebuilder.six`, `nfcebuilder.typing`,
`nfcebuilder.dateutil`, `models.enum`, `models.typing` — e a execução terminou com um erro NOVO,
bem diferente de um `ImportError`: `'int' object has no attribute 'value'`.

**Causa raiz**: Python 2 (sem `from __future__ import absolute_import` no arquivo que importa)
tenta, para QUALQUER `import X` feito de dentro de um pacote, uma variante **relativa** primeiro —
o pacote atual (que pode ter vários níveis, ex: `nfcebuilder.nfceutil`) prefixado ao nome escrito
no código (ex: `import logging` dentro de `nfcedisabler/_NfceDisabler.py` primeiro tenta
`nfcedisabler.logging`) — e só tenta o nome absoluto (`logging`, sem prefixo) **depois** que essa
tentativa relativa falha. O `_AutoStubImportFinder` da correção anterior via essas tentativas
relativas (`nfcedisabler.logging`, `nfcebuilder.xml.etree`, `models.enum`, etc.), confirmava que
elas realmente "não existem" (de fato não existe nenhum arquivo `nfcedisabler/logging.py`) e as
stubava — sem nunca deixar o Python tentar o nome absoluto de verdade (`logging`, `xml.etree`,
`enum`), que teria funcionado normalmente. Ou seja: o finder estava STUBANDO módulos reais da
stdlib/terceiros, substituindo-os por objetos genéricos fake, só porque a *primeira* tentativa
(a relativa) falhava — sem saber que havia uma segunda tentativa (a absoluta) que teria
funcionado. Isso explica o `'int' object has no attribute 'value'`: com `enum` (o módulo real da
stdlib) substituído por um stub fake, uma classe do próprio fiscalwrapper que herda de
`enum.Enum` (ex: `NfceCstatCode`) parou de criar membros de Enum de verdade — os "membros"
viraram inteiros comuns, sem o atributo `.value` que o código genuíno espera.

**Correção**: antes de stubar um nome, o finder agora verifica se **qualquer sufixo** do nome
(cortando 1, 2, ... componentes do início — cobre pacotes aninhados em vários níveis, ex:
`nfcebuilder.nfceutil.OpenSSL` → sufixo `OpenSSL`) resolve de verdade como import absoluto; se
resolver, o finder recusa (`return None`), deixando o mecanismo normal do Python cair pro nome
absoluto sozinho — sem precisar do finder pra nada nesse caso. Só stuba de fato quando NENHUM
sufixo resolve (o caso genuíno, tipo `modelcommon.model`). Também adicionado: a checagem da lista
`_NUNCA_STUBAR_IMPORT` agora olha **qualquer componente** do nome (não só o primeiro) — cobre o
caso de `nfcedisabler.iso8601` (variante relativa de um nome que nunca deve ser mascarado), e
`OpenSSL` (pyOpenSSL, usado de verdade por `NfeSigner`/`XmlEnveloper` via `nfceutil` — apareceu
stubado como `nfcebuilder.nfceutil.OpenSSL` no mesmo log) foi adicionado à lista.

Um segundo bug (mais simples) foi encontrado e corrigido durante a validação desta correção: a
implementação inicial de `find_module` esquecia o `return self` no final — depois de checar todos
os sufixos sem achar nenhum resolvível, a função "caía pro fim" e devolvia `None` implicitamente
(Python sempre devolve `None` de uma função sem `return` explícito), fazendo o finder nunca
conseguir stubar NADA, nem os casos genuinamente ausentes (`pos_model`, `posot`,
`modelcommon.model`). Corrigido adicionando o `return self` que faltava.

**Testado exaustivamente** (Python 3, fora deste repositório, com testes automatizados cobrindo os
três cenários): (1) todos os nomes que apareceram stubados por engano no log real (`nfcedisabler.
logging`, `nfcedisabler.requests`, `nfcebuilder.xml.etree`, `models.enum`, etc.) agora devolvem
`None` (não são mais interceptados); (2) nomes genuinamente ausentes (`modelcommon.model`,
`pos_model`, `posot`, um pacote totalmente inventado) continuam sendo stubados corretamente; (3)
a lista `_NUNCA_STUBAR_IMPORT` (`iso8601`, `cryptography`, `lxml`, `signxml`, `requests`,
`OpenSSL`) continua nunca sendo interceptada, mesmo em variante relativa e mesmo genuinamente
ausente neste ambiente de teste. `py_compile` passou; commitado e **confirmado por listagem direta
do diretório** (52626 bytes, timestamp novo) nos dois locais, seguindo a lição do incidente
anterior.

**Risco deste bug já ter afetado o teste anterior**: como o teste que reportou "sucesso: False,
mensagem: ... 'int' object has no attribute 'value'" rodou com o finder ainda com o bug (módulos
reais substituídos por fakes), não dá pra saber se algum dado real (ex: uma chamada HTTP via
`requests`, que também estava fake nessa execução) chegou a ser afetada de forma silenciosa antes
do erro aparecer — mas como a inutilização em si retornou `sucesso: False` (nunca chegou a
efetivamente enviar/confirmar nada junto à SEFAZ, dado que quebrou antes disso, na montagem do
`NfceDisabler`), não há indício de que algo tenha sido enviado incorretamente pra SEFAZ nesse
teste.

### 10/09/2026 (4) — Novo recurso: modo "só print" (`INUTILIZACAO_DRY_RUN`) no fluxo automático, para testar numa loja antes de ligar 100% automático

Pedido do usuário: rodar `main.py` numa loja de verdade, com notas órfãs reais, e ver exatamente o
que o fluxo automático de inutilização faria — sem perguntar nada pro operador e sem mandar nada de
verdade pra SEFAZ — antes de confiar no modo totalmente automático (com confirmação interativa).

**O que já existia**: `inutilizar_nota_orfa(..., confirm=False)` (em `inutilizar_numeros_orfaos.py`)
já era usado pelo modo lote manual da CLI (`--confirm`) — monta o XML de requisição completo, mas
nunca chama `disable_fiscal_number` (nunca fala de verdade com a SEFAZ) e nunca grava no arquivo de
estado (idempotência). Faltava um jeito de acionar esse mesmo comportamento a partir do fluxo
automático (`consulte_csv.py`), que hoje só roda em dois modos: pedir confirmação (`raw_input`,
`[s/N]`) ou (se não confirmado) deixar a nota como não identificada.

**Correção**: adicionada uma variável de ambiente nova, `INUTILIZACAO_DRY_RUN`, lida em
`_tentar_inutilizar_nota_orfa` (`consulte_csv.py`). Valores considerados "ligado" (não sensível a
maiúsculas/minúsculas): `1`, `true`, `sim`, `s`, `yes`. Quando ligada:
- **Não pergunta nada ao operador** (pula o `raw_input`/`[s/N]` inteiramente).
- Chama `inutilizar_nota_orfa(..., confirm=False)` — monta a requisição completa (inclusive
  passando pelos mesmos imports/finder do fiscalwrapper, então também serve pra validar que o
  import está funcionando numa loja real), mas **nunca envia nada de verdade pra SEFAZ**.
- **Nunca grava no arquivo de estado** de idempotência — rodar em modo dry-run não marca a nota
  como "já processada", então depois de desligar o dry-run a mesma nota ainda vai ser tratada
  (pedindo confirmação de verdade, ou sendo inutilizada de verdade em lote manual).
- Loga uma linha `[DRY-RUN] ...` explícita antes de simular, e o resultado normal (`sucesso`/
  `mensagem`) depois — inclusive o `[DRY-RUN]` já vem prefixado na mensagem de retorno de
  `inutilizar_nota_orfa`.

A checagem de idempotência (`nota_ja_processada`) no topo da função continua rodando igual, antes
de decidir entre dry-run/confirmação — uma nota já processada em execução anterior continua sendo
pulada normalmente mesmo em dry-run.

**Como usar numa loja**: definir a variável de ambiente `INUTILIZACAO_DRY_RUN=1` no Windows antes
de rodar `main.py` (ou no `update.bat`/serviço, dependendo de como o processo é disparado nessa
loja), rodar o fluxo normal contra os dados reais da loja, e conferir o log: pra cada nota órfã
real que aparecer, deve sair uma linha `[DRY-RUN]` seguida do resultado simulado (série lida de
`loader_NFCE.cfg`, sucesso/mensagem), sem nenhum prompt `[s/N]` e sem nada indo pra SEFAZ. Depois de
validar o comportamento no log, é só remover/desativar a variável de ambiente pra voltar ao modo
normal (com confirmação manual antes de qualquer inutilização de verdade).

`py_compile` passou; commitado e **confirmado por listagem direta do diretório** (20893 bytes,
timestamp novo) nos dois locais, seguindo a mesma lição de sempre verificar depois de commitar.

### 10/09/2026 (5) — Primeiro teste em modo dry-run numa loja: `sqlalchemy` sendo mascarado por engano, causa provável de `Type <class 'sqlalchemy.engine.interfaces.Connectable'> is already registered`

Primeiro teste real com `INUTILIZACAO_DRY_RUN=1` numa loja: o modo dry-run funcionou como esperado
(nenhum prompt `[s/N]`, log `[DRY-RUN] ...` apareceu), e o finder genérico corrigido na rodada
anterior **não** voltou a mascarar módulos reais como `enum`/`logging`/`requests` — mas apareceu um
erro NOVO, diferente de um `ImportError`: `Erro ao inutilizar numero 122611 (serie None): Type
<class 'sqlalchemy.engine.interfaces.Connectable'> is already registered`. `serie None` indica que
a exceção aconteceu ANTES de `serie = serie or pecas['cfg']['serie']` rodar, ou seja, ainda dentro
de `_montar_disabler`/`_importar_modulos_fiscalwrapper`.

**Investigação**: o `logger.warning` desse teste, pela primeira vez, não incluiu mais `nfcedisabler.
adapter`/`nfcedisabler.adapter.sqlite_adapter` na lista de nomes stubados — ou seja, com a correção
da rodada anterior (suffix-check), o finder passou a deixar `adapter.sqlite_adapter` (um arquivo
REAL do fiscalwrapper, usado de verdade pelo `NfceDisabler`) carregar de verdade pela primeira vez,
em vez de mascará-lo. Conferindo `adapter/sqlite_adapter.py` (nos arquivos de referência já
levantados nesta sessão): ele importa `sqlalchemy` de verdade. Isso é o esperado e correto — o
problema é o que aconteceu DEPOIS: o mesmo log mostra `sqlalchemy.cprocessors`,
`sqlalchemy.cresultproxy` e `sqlalchemy.cutils` (submódulos C **opcionais** do próprio sqlalchemy —
o sqlalchemy já faz `try/except ImportError` em volta deles e cai para uma implementação pura
Python quando não estão compilados, uma situação normal e esperada) sendo **stubados** pelo nosso
finder com classes fake, em vez de deixar o `ImportError` real subir e o próprio mecanismo de
fallback do sqlalchemy funcionar. Ou seja: o sqlalchemy passou a receber um "processor"/"resultproxy"
FAKE como se fosse o de verdade, o que muito provavelmente contribuiu para (ou causou) o erro de
registro duplicado do `Connectable`.

**Limitação encontrada durante o diagnóstico**: o `except Exception` de `inutilizar_nota_orfa` só
guardava `str(exc)` na mensagem de retorno — sem o traceback, não dá pra confirmar em que
arquivo/linha exata o erro `Connectable already registered` foi levantado, só inferir pelo
`logger.warning` de nomes stubados. Ficou registrado como risco: futuras mensagens de erro deste
tipo continuam sendo diagnosticadas "às cegas" sem essa informação.

**Correção**: adicionado `"sqlalchemy"` à `_NUNCA_STUBAR_IMPORT` — nenhum submódulo de sqlalchemy
(incluindo os aceleradores C `cprocessors`/`cresultproxy`/`cutils`) é mascarado, mesmo que a
tentativa de import real falhe; um `ImportError` real sobe normalmente, permitindo o fallback do
próprio sqlalchemy funcionar como projetado. Também adicionado `import traceback` e, no
`except Exception` final de `inutilizar_nota_orfa`, uma chamada a `logger.error` com o traceback
completo (`traceback.format_exc()`) antes de retornar — a mensagem de retorno continua curta (mesmo
formato de sempre, mais o nome da classe da exceção), mas o log agora carrega o traceback inteiro,
pra qualquer próximo erro parecido ser diagnosticado direto pela linha exata, sem precisar inferir
pela lista de módulos stubados.

`py_compile` passou; commitado e **confirmado por listagem direta do diretório** (54307 bytes,
timestamp novo) nos dois locais. **Ainda não confirmado**: se essa era de fato a causa raiz
completa do erro `Connectable already registered` — só o próximo teste real (agora com traceback
completo no log, se o erro persistir) vai confirmar.

### 10/09/2026 (6) — Traceback completo confirmou a correção do `sqlalchemy` e revelou a mesma família de bug com `fcntl`/`termios` (via alembic)

O próximo teste (ainda em dry-run) confirmou duas coisas: o erro `Connectable already registered`
**sumiu** (a correção do `sqlalchemy` funcionou), e o traceback completo (novo, adicionado na
rodada anterior) finalmente mostrou a causa raiz exata de um erro seguinte, sem precisar adivinhar:

```
File ".../alembic/util/messaging.py", line 26, in <module>
    _h, TERMWIDTH, _hp, _wp = struct.unpack("HHHH", ioctl)
error: unpack requires a string argument of length 8
```

Cadeia completa até aqui: `_DetFeeBuilder` (nfcebuilder) importa `services.FeeService`, que puxa
`services -> _SequencerService -> repository -> _BaseRepository -> adapter.sqlite_adapter -> alembic`
— nada disso é usado de verdade pela inutilização, é carregado de carona só porque
`nfcebuilder/__init__.py` importa todos os builders incondicionalmente. Conferido o código real do
alembic (via `pip install alembic` e `inspect.getsource`): `alembic/util/messaging.py` faz
`try: import fcntl, termios, struct; ... except (ImportError, OSError): TERMWIDTH = None` só pra
descobrir a largura do terminal (cosmético, pra formatar mensagens de linha de comando). `fcntl`/
`termios` são módulos só-Unix, genuinamente ausentes no Windows — o alembic já sabe lidar com isso.
Mas o finder criava stubs fake pra eles em vez de deixar o `ImportError` real acontecer; o
`import fcntl, termios, struct` "passava" (sem erro), e `fcntl.ioctl(...)` (uma classe fake,
chamável, que só devolve uma instância fake) virou argumento de `struct.unpack`, que espera bytes
de verdade — daí o `struct.error`, que o `except (ImportError, OSError)` do alembic não pega
(porque não é nenhum dos dois).

**Mesma família de bug do incidente anterior (sqlalchemy)**: uma biblioteca real já trata a
ausência de uma dependência opcional com try/except, mas o finder mascara essa ausência com um
stub fake em vez de deixar o `ImportError` de verdade acontecer.

**Correção, dessa vez mais ampla** (pra não continuar corrigindo nome por nome a cada teste):
`_NUNCA_STUBAR_IMPORT` agora inclui uma categoria inteira de módulos de baixo nível específicos de
UM sistema operacional, que bibliotecas bem escritas já esperam que possam faltar: `alembic` (a
própria, já que resolve de verdade e é necessária pra `nfcebuilder/__init__.py` carregar),
`fcntl`, `termios`, `tty`, `pty` (só Unix), `msvcrt`, `winreg`, `_winreg` (só Windows), `resource`,
`grp`, `pwd`, `curses` (só Unix) — cobrindo preventivamente a mesma família de risco antes que
apareça de novo com outro nome num próximo teste.

Testado isoladamente (Python 3): confirmado que `fcntl`/`termios`/etc. agora são recusados pelo
finder (`find_module` devolve `None`) tanto na forma direta quanto prefixada
(`nfcedisabler.fcntl`). `py_compile` passou; commitado e **confirmado por listagem direta do
diretório** (56663 bytes, timestamp novo) nos dois locais.

## O que ainda é dívida técnica / pendente de decisão

- **CONFIRMADO (09/09/2026 (2), numa instalação real)**: `default_fiscalwrapper_src()`
  (`inutilizar_numeros_orfaos.py`) retorna o caminho certo — `loader_NFCE.cfg`/`nfce_urls.xml`
  ficam em `default_bundle_dir()` e `nfcedisabler`/`models`/`comp_exceptions` ficam exatamente em
  `default_fiscalwrapper_src()`, em `C:\edeploy-pos-structure`. Ver incidente de campo
  "09/09/2026 (2)" acima.
- **(novo, 10/09/2026) `iso8601` pode faltar em alguma loja** — `_ProcInutNfeSaver.
  save_proc_inut_nfe_xml` (do próprio fiscalwrapper, chamado de verdade por
  `inutilizar_nota_orfa`) importa `iso8601`, não encontrado em `src/fiscalwrapper/lib/` na
  instalação testada até agora. Diferente de `pos_model`/`posot`/`old_helper`/`helper` (ver
  incidentes "09/09/2026 (2)" e "10/09/2026" acima), `iso8601` é usado de verdade por esse fluxo
  — não dá pra stubar sem risco. Só será confirmado se/quando uma inutilização real chegar até
  esse ponto (depois de resolver os imports de `pos_model` etc.) — se faltar, a instalação
  provavelmente precisa de `pip install iso8601` no Python 2.7 da própria loja.
- **Python 2.7 está fora de suporte desde janeiro/2020 (sem patch de segurança)** — voltar a
  rodar o `main.py` inteiro nele (decisão de 31/08/2026) reintroduz esse risco, especialmente
  para `send_orderpaid_boh.py` (`StandAlone`), que faz chamadas HTTPS ao servidor BOH. Mitigado
  parcialmente porque `StandAlone` não é chamada em nenhum ponto ativo hoje (ver item abaixo) —
  mas se for reativada, vale reavaliar.
- `cstat_539.bat` (criado pelo usuário) chama `fix_protocolo_cupons.py --order-ids` sem números de
  nota depois da flag — precisa ser completado com os orderids antes de rodar.
- `StandAlone` (`send_orderpaid_boh.py`) e `StandAlone_OrderPicture` (`order_picture.py`) não são
  chamadas em nenhum lugar ativo — decisão de negócio pendente sobre reativar o envio ao BOH em
  `time_direction` quando `order_statr == 5`.
- O ramo de inutilização incorreta dentro de `time_direction` (`order_disabled`/
  `xml_fiscal_disabled`) parece inatingível no código atual (as variáveis nunca recebem um valor
  que dispare esse bloco) — revisar se é intencional ou uma lacuna.
- `cElementTree` (alias legado) ainda é usado em vez de `xml.etree.ElementTree` em
  `fix_protocolo_cupons.py`, `order_picture.py`, `send_orderpaid_boh.py` e
  `fiscal_reprocessa_nfeproc.py` — funciona, mas os scripts mais novos já usam o nome direto.
- `fiscal_reprocessa_nfeproc.py` tem nomes de tabela/coluna não confirmados em produção (ver
  aviso no próprio arquivo) — confirmar com `--list-tables`/`--describe-table` antes do primeiro
  uso em cada instalação.
- `key_pattern_fiscallog` (cStat 204, em `fix_protocolo_cupons.py`) ainda busca um padrão de log
  antigo (`FiscalWrapper.log`, não `FiscalWrapperThread.log`) que provavelmente está desatualizado
  pelo mesmo motivo que o padrão de `find_key_pattern` estava — falta um exemplo real desse
  cenário para reescrever com segurança.
- `fix_cupom_protocol.py` ainda existe fisicamente na pasta como um stub de texto (não consigo
  apagar arquivos remotamente) — o usuário pode apagá-lo quando quiser, nada mais importa dele.
- `fix_cstat` grava um `nRec` **fixo/placeholder** (`411002421114061`) no `end_xml` do protocolo
  reconstruído, independente do orderid/nota (ver `fix_cstat`, variável `end_xml`). Desde
  04/09/2026 alguns formatos de log (`RE_PATTERN_LOTE_COLCHETE`) trazem o `nRec` real da SEFAZ
  pra essa nota — hoje ele só é logado, não é usado para substituir o placeholder. Avaliar se vale
  passar esse `nRec` real para `fix_cstat` e montar o `end_xml` com ele, em vez do valor fixo.
- **(pré-existente, achado em 04/09/2026)** `path_orders` e `path_orders_backup`, em `main.py`,
  só são definidos nos ramos `C:\edeployPOS` e `C:\edeploy-pos-structure` da detecção de
  instalação — o ramo `/home/administrador/mwpos_server` (Linux) não define nenhuma das duas.
  `main()` já quebraria com `NameError: name 'path_orders' is not defined` na primeira chamada de
  `find_fiscal_id`, pra qualquer loja detectada como `mwpos_server`. Não é algo introduzido pela
  integração de `restaurar_nota` (essa só adicionou uma segunda variável com a mesma lacuna,
  `path_orders_backup`, e essa já tem uma checagem defensiva — ver `main()`) — parece que o ramo
  Linux desse `if/elif` nunca chegou a ganhar essas duas variáveis quando os outros dois ramos
  ganharam. Avaliar se faz sentido defini-las também lá (mesmo padrão de caminho, ajustado pra
  barra `/`) ou se esse ramo realmente não precisa (ex: se `mwpos_server` nunca roda esse trecho
  do fluxo na prática).
