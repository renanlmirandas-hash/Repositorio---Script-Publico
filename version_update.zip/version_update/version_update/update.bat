cd /d %~dp0
C:\edeploypos\python\python.exe main.py update
pause