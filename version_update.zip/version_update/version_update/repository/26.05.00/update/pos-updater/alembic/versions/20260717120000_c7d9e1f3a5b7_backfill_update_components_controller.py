"""backfill UpdateComponentsController for legacy stores

Revision ID: c7d9e1f3a5b7
Revises: a1b2c3d4e5f6
Create Date: 2026-07-17 12:00:00.000000

"""
from typing import (
    Sequence,
    Union,
)

from alembic import op
from sqlalchemy import (
    Column,
    Integer,
    VARCHAR,
    inspect,
)

revision: str = "c7d9e1f3a5b7"
down_revision: Union[str, None] = "a1b2c3d4e5f6"
branch_labels: Union[str, Sequence[str], None] = None
depends_on: Union[str, Sequence[str], None] = None


def upgrade() -> None:

    inspector = inspect(op.get_bind())

    if not inspector.has_table("UpdateComponentsController"):
        op.create_table(
            "UpdateComponentsController",
            Column("Id", Integer, nullable=False, primary_key=True, autoincrement=True),
            Column("Name", VARCHAR, nullable=False),
            Column("Version", VARCHAR, nullable=False),
            Column("ObtainedDate", VARCHAR, nullable=False),
            Column("DownloadedDate", VARCHAR, nullable=True),
            Column("BackupDate", VARCHAR, nullable=True),
            Column("AppliedDate", VARCHAR, nullable=True),
            Column("NotifiedDate", VARCHAR, nullable=True),
        )
        op.create_index(
            "idx_UpdateComponentsController_name_version",
            "UpdateComponentsController",
            ["Name", "Version"],
            unique=True,
        )


def downgrade() -> None:

    inspector = inspect(op.get_bind())

    if inspector.has_table("UpdateComponentsController"):
        op.drop_table("UpdateComponentsController")