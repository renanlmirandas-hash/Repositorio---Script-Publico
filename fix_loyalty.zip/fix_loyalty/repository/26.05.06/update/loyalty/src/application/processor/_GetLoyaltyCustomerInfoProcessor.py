import json
import logging

from application.interactor.get_loyalty_customer import (
    GetLoyaltyCustomerInfoInteractor,
)
from application.interactor.get_loyalty_customer.dto import (
    GetLoyaltyCustomerInfoRequest,
)
from application.model import (
    AsyncUuidMessageProcessor,
)
from application.model.customexception import (
    NotFound,
    NotFoundError,
)
from messagebus import (
    AckMessage,
    DataType,
    Event,
    InternalErrorMessage,
    Message,
    MessageBus,
)

from .tokens import (
    ResponseToken,
)

logger = logging.getLogger(__name__)


class GetLoyaltyCustomerInfoProcessor(AsyncUuidMessageProcessor):
    def __init__(
        self,
        interactor: GetLoyaltyCustomerInfoInteractor,
    ) -> None:
        super(
            GetLoyaltyCustomerInfoProcessor,
            self,
        ).__init__()
        self.interactor = interactor

    def parse_data(
        self,
        data: bytes,
        event_type: str,
    ) -> GetLoyaltyCustomerInfoRequest:
        request = json.loads(data.decode("utf-8"))

        return GetLoyaltyCustomerInfoRequest(
            pos_id=int(request["posId"]),
            loyalty_id=request["loyaltyId"],
            order_id=request["orderId"] or None,
            table_id=request["tableId"] or None,
            seat=request["seat"],
        )

    def call_business(
        self,
        request: GetLoyaltyCustomerInfoRequest,
    ) -> None:
        return self.interactor.get_loyalty_customer_info(request=request)

    def format_response(
        self,
        message_bus: MessageBus,
        message: Message,
        event: Event,
        request: str,
        response: str,
    ) -> None:
        message_bus.reply_message(
            message=message,
            reply_message=AckMessage(
                data_type=DataType.string,
                data=response,
            ),
        )

    def format_exception(
        self,
        message_bus: MessageBus,
        message: Message,
        event: Event,
        input_obj: str,
        exception: Exception,
    ) -> None:
        if isinstance(
            exception,
            (NotFound, NotFoundError),
        ):
            message_bus.reply_message(
                message=message,
                reply_message=Message(token=ResponseToken.TK_LOYALTY_ID_NOT_FOUND.value),
            )
        else:
            message_bus.reply_message(
                message=message,
                reply_message=InternalErrorMessage(exception),
            )

    def format_parse_exception(
        self,
        message_bus: MessageBus,
        message: Message,
        event: Event,
        data: bytes,
        exception: Exception,
    ) -> None:
        message_bus.reply_message(
            message=message,
            reply_message=InternalErrorMessage(exception),
        )
