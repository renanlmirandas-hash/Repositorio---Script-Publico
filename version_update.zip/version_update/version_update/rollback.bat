C:\edeploypos\python\python.exe main.py rollback
pause