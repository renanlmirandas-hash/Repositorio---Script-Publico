import sqlalchemy as sa
from alembic import op

revision = "002_transmitted_xml_request"
down_revision = "001_initial_schema"
branch_labels = None
depends_on = None


def upgrade():
    # type: () -> None

    # Documento tpEmis=1 transmitido a SEFAZ antes de a conexao cair, em base64. Fica em coluna
    # propria porque XMLRequest guarda o documento de contingencia e e reescrito a cada ciclo do
    # janitor. Nula em toda order que nunca entrou em contingencia.
    op.add_column(
        "FiscalData",
        sa.Column("TransmittedXMLRequest", sa.VARCHAR, nullable=True),
    )


def downgrade():
    # type: () -> None

    # Em lote: o SQLite embarcado nao suporta ALTER TABLE ... DROP COLUMN.
    with op.batch_alter_table("FiscalData") as batch_op:
        batch_op.drop_column("TransmittedXMLRequest")
