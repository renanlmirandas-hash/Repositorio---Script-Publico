#!/usr/bin/env python3
"""Preenche parametros fiscais faltantes em fiscal_params.db usando o FISCAL_XML de uma nota.

fiscal_params.db (tabela FiscalParameter) e o catalogo de classificacao tributaria por produto
(NCM, CFOP, CST_ICMS, CST_PIS, CST_COFINS, CSOSN, CEST). Ele e sincronizado do BOH e nao faz
parte do backup mensal de pedidos - por isso um produto pode ficar sem parametro cadastrado
mesmo que o pedido/nota estejam intactos, e isso quebra qualquer tentativa de reconstruir o XML
da nota (ex: reassinatura pelo Janitor do fiscalwrapper).

Este script NAO inventa classificacao fiscal. Ele le o FISCAL_XML ja gravado na nota (o XML que
ja foi assinado e ACEITO pela SEFAZ), extrai o <det> de cada produto e usa esses valores - que ja
sao oficialmente validados - para preencher SOMENTE os parametros que estiverem faltando em
fiscal_params.db. Nunca sobrescreve um parametro que ja existe.

Uso:
    python backfill_fiscal_params_from_order.py 4637
    python backfill_fiscal_params_from_order.py 4637 --dry-run
    python backfill_fiscal_params_from_order.py 4637 --yes
"""
import argparse
import base64
import os
import re
import shutil
import sqlite3
import sys
from datetime import datetime
from xml.etree import ElementTree as ET

DEFAULT_DB_DIR = r"C:\edeployPOS\data\server\databases"
ORDER_DB_PATTERN = re.compile(r"^order\.db(\d+)$")

ICMSSN_TAGS = {"ICMSSN101", "ICMSSN102", "ICMSSN201", "ICMSSN202", "ICMSSN500", "ICMSSN900"}


def strip_ns(tag):
    return tag.split("}", 1)[-1] if "}" in tag else tag


def find_pos_order_databases(database_dir):
    databases = {}
    for name in os.listdir(database_dir):
        match = ORDER_DB_PATTERN.match(name)
        if match:
            databases[int(match.group(1))] = os.path.join(database_dir, name)
    return databases


def find_order_ids_by_fiscal_id(db_path, fiscal_id):
    conn = sqlite3.connect(db_path)
    try:
        cursor = conn.execute(
            "SELECT OrderId FROM OrderCustomProperties WHERE Key = 'FISCAL_ID' AND Value = ?",
            (fiscal_id,),
        )
        return [row[0] for row in cursor.fetchall()]
    finally:
        conn.close()


def fetch_fiscal_xml(db_path, order_id):
    conn = sqlite3.connect(db_path)
    try:
        cursor = conn.execute(
            "SELECT Value FROM OrderCustomProperties WHERE OrderId = ? AND Key = 'FISCAL_XML'",
            (order_id,),
        )
        row = cursor.fetchone()
        return row[0] if row else None
    finally:
        conn.close()


def decode_fiscal_xml(raw_value):
    padded = raw_value + "=" * (-len(raw_value) % 4)
    return base64.b64decode(padded).decode("utf-8")


def extract_params_from_xml(xml_text):
    root = ET.fromstring(xml_text)

    crt = None
    for elem in root.iter():
        if strip_ns(elem.tag) == "CRT":
            crt = elem.text
            break

    products = {}
    for det in root.iter():
        if strip_ns(det.tag) != "det":
            continue

        prod = next((c for c in det if strip_ns(c.tag) == "prod"), None)
        imposto = next((c for c in det if strip_ns(c.tag) == "imposto"), None)
        if prod is None:
            continue

        c_prod = None
        params = {}
        for field in prod:
            tag = strip_ns(field.tag)
            if tag == "cProd":
                c_prod = field.text
            elif tag in ("NCM", "CEST", "CFOP"):
                params[tag] = field.text

        if imposto is not None:
            _extract_tax_params(imposto, params)

        if c_prod:
            products[c_prod] = params

    return crt, products


def _extract_tax_params(imposto, params):
    for tax_group in imposto:
        group_tag = strip_ns(tax_group.tag)

        if group_tag == "ICMS":
            for variant in tax_group:
                variant_tag = strip_ns(variant.tag)
                variant_fields = {strip_ns(f.tag): f.text for f in variant}
                if variant_tag in ICMSSN_TAGS:
                    if "CSOSN" in variant_fields:
                        params["CSOSN"] = variant_fields["CSOSN"]
                elif "CST" in variant_fields:
                    params["CST_ICMS"] = variant_fields["CST"]
                if "orig" in variant_fields:
                    params["ORIG"] = variant_fields["orig"]
                if "cBenef" in variant_fields:
                    params["cBenef"] = variant_fields["cBenef"]

        elif group_tag == "PIS":
            for variant in tax_group:
                variant_fields = {strip_ns(f.tag): f.text for f in variant}
                if "CST" in variant_fields:
                    params["CST_PIS"] = variant_fields["CST"]

        elif group_tag == "COFINS":
            for variant in tax_group:
                variant_fields = {strip_ns(f.tag): f.text for f in variant}
                if "CST" in variant_fields:
                    params["CST_COFINS"] = variant_fields["CST"]


def existing_param(conn, product_code, param_name):
    cursor = conn.execute(
        "SELECT ParamValue FROM FiscalParameter WHERE ProductCode = ? AND ParamName = ?",
        (product_code, param_name),
    )
    row = cursor.fetchone()
    return row[0] if row else None


def backup_file_before_write(db_path):
    timestamp = datetime.now().strftime("%Y%m%dT%H%M")
    backup_path = "{}_{}.bkp".format(db_path, timestamp)
    shutil.copy2(db_path, backup_path)
    return backup_path


def main():
    parser = argparse.ArgumentParser(
        description=(
            "Le o FISCAL_XML ja aceito pela SEFAZ de uma nota e preenche, em fiscal_params.db, "
            "os parametros fiscais de produtos que ainda nao tem parametro cadastrado. Nunca "
            "sobrescreve um parametro ja existente."
        )
    )
    parser.add_argument("fiscal_id", help="Numero de nota fiscal (FISCAL_ID) de onde extrair os parametros")
    parser.add_argument("--db-dir", default=DEFAULT_DB_DIR, help="Diretorio das bases correntes")
    parser.add_argument("--dry-run", action="store_true", help="Apenas mostra o que seria inserido")
    parser.add_argument("-y", "--yes", action="store_true", help="Nao pede confirmacao antes de gravar")
    args = parser.parse_args()

    pos_databases = find_pos_order_databases(args.db_dir)
    if not pos_databases:
        print("Nenhuma base order.db<N> encontrada em {}".format(args.db_dir))
        sys.exit(1)

    order_id = None
    source_db = None
    for path in pos_databases.values():
        order_ids = find_order_ids_by_fiscal_id(path, args.fiscal_id)
        if order_ids:
            order_id = order_ids[0]
            source_db = path
            break

    if order_id is None:
        print("Nota fiscal {} nao encontrada em nenhuma base order.db<N> corrente.".format(args.fiscal_id))
        sys.exit(1)

    raw_fiscal_xml = fetch_fiscal_xml(source_db, order_id)
    if not raw_fiscal_xml:
        print("Nota {} (OrderId={}) nao tem FISCAL_XML gravado - nada para extrair.".format(
            args.fiscal_id, order_id
        ))
        sys.exit(1)

    xml_text = decode_fiscal_xml(raw_fiscal_xml)
    crt, products = extract_params_from_xml(xml_text)

    print("Nota {} (OrderId={}). Regime (CRT): {}. {} produto(s) no XML.".format(
        args.fiscal_id, order_id, crt, len(products)
    ))

    fiscal_params_path = os.path.join(args.db_dir, "fiscal_params.db")
    if not os.path.isfile(fiscal_params_path):
        print("fiscal_params.db nao encontrado em {}".format(args.db_dir))
        sys.exit(1)

    conn = sqlite3.connect(fiscal_params_path)
    to_insert = []
    for product_code, params in products.items():
        for param_name, param_value in params.items():
            if param_value is None:
                continue
            if existing_param(conn, int(product_code), param_name) is not None:
                continue
            to_insert.append((int(product_code), param_name, param_value))
    conn.close()

    if not to_insert:
        print("Nenhum parametro fiscal faltante - fiscal_params.db ja esta completo para os produtos desta nota.")
        return

    print("\nParametros faltantes encontrados (produto / parametro = valor extraido do XML ja aceito pela SEFAZ):")
    for product_code, param_name, param_value in to_insert:
        print("  {} / {} = {}".format(product_code, param_name, param_value))

    if args.dry_run:
        print("\n[dry-run] Nenhuma alteracao aplicada.")
        return

    if not args.yes:
        answer = input("\nConfirma a insercao desses {} parametro(s) em fiscal_params.db? [s/N] ".format(
            len(to_insert)
        ))
        if answer.strip().lower() not in ("s", "sim", "y", "yes"):
            print("Insercao cancelada pelo usuario.")
            return

    backup_copy = backup_file_before_write(fiscal_params_path)
    print("Backup de seguranca criado: {}".format(backup_copy))

    conn = sqlite3.connect(fiscal_params_path)
    conn.executemany(
        "INSERT INTO FiscalParameter (ProductCode, ParamName, ParamValue) VALUES (?, ?, ?)",
        to_insert,
    )
    conn.commit()
    conn.close()

    print("{} parametro(s) fiscal(is) inserido(s) com sucesso em fiscal_params.db.".format(len(to_insert)))


if __name__ == "__main__":
    main()
